package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.WorkspacePremium
import com.example.ui.components.AppDistributionDialog
import com.example.util.AppEdition
import com.example.util.AppEditionManager
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.SettingsBrightness
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.BuildConfig
import com.example.ui.components.SecurityLockOverlay
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.util.AppThemeMode
import com.example.util.SecurityManager
import com.example.util.ThemeManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBackToChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val securityManager = remember { SecurityManager(context) }
    val themeManager = remember { ThemeManager.getInstance(context) }
    val currentThemeMode by themeManager.themeMode.collectAsState()

    val editionManager = remember { AppEditionManager(context) }
    var showDistributionHubDialog by remember { mutableStateOf(false) }

    var isPinLock by remember { mutableStateOf(securityManager.isPinLockEnabled) }
    var pinCodeInput by remember { mutableStateOf(securityManager.pinCode) }
    var isFingerprint by remember { mutableStateOf(securityManager.isFingerprintEnabled) }
    var isFaceLock by remember { mutableStateOf(securityManager.isFaceLockEnabled) }
    var showTestLockDialog by remember { mutableStateOf(false) }

    var enrolledFingerprints by remember { mutableStateOf(securityManager.getEnrolledFingerprints()) }
    var enrolledFaceLocks by remember { mutableStateOf(securityManager.getEnrolledFaceLocks()) }

    // Enrollment Dialog States
    var showAddFingerprintDialog by remember { mutableStateOf(false) }
    var newFingerprintName by remember { mutableStateOf("") }
    var isCapturingFinger by remember { mutableStateOf(false) }

    var showAddFaceDialog by remember { mutableStateOf(false) }
    var newFaceName by remember { mutableStateOf("") }
    var isScanningFaceMesh by remember { mutableStateOf(false) }

    // Owner Verification Dialog before turning OFF or changing critical security
    var showOwnerVerificationDialog by remember { mutableStateOf(false) }
    var pendingSecurityAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var pendingActionTitle by remember { mutableStateOf("Verify Owner Identity") }

    val apiKeyConfigured = try {
        BuildConfig.GEMINI_API_KEY.isNotBlank() && BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY"
    } catch (e: Exception) {
        false
    }

    // Function to request owner verification before modifying/turning off
    fun requestOwnerVerification(actionTitle: String, onVerified: () -> Unit) {
        if (!securityManager.isSecurityActive()) {
            onVerified()
        } else {
            pendingActionTitle = actionTitle
            pendingSecurityAction = onVerified
            showOwnerVerificationDialog = true
        }
    }

    if (showTestLockDialog) {
        Dialog(
            onDismissRequest = { showTestLockDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                SecurityLockOverlay(
                    securityManager = securityManager,
                    onUnlocked = {
                        showTestLockDialog = false
                        Toast.makeText(context, "Lock verification succeeded!", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Settings & Security Bar",
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary,
                            fontSize = 18.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackToChat) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = GoldPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsidianBackground)
            )
        },
        containerColor = ObsidianBackground,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // App Identity Card
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(ObsidianBackground)
                            .border(1.dp, GoldPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "KING AI v1.0",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary
                        )
                        Text(
                            text = "Sole Owner & Master: Abdullah Waheed",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 🎨 APPEARANCE & DYNAMIC THEME SWITCHER
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Palette,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "APPEARANCE & DYNAMIC THEME",
                    style = MaterialTheme.typography.labelSmall,
                    color = GoldPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "App Theme & Color Mode",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "Switch dynamically between Light, Obsidian Dark, or System Adaptive theme.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    AppThemeMode.entries.forEach { mode ->
                        val isSelected = currentThemeMode == mode
                        val icon = when (mode) {
                            AppThemeMode.LIGHT -> Icons.Default.LightMode
                            AppThemeMode.DARK -> Icons.Default.DarkMode
                            AppThemeMode.SYSTEM -> Icons.Default.SettingsBrightness
                        }

                        Surface(
                            onClick = { themeManager.setThemeMode(mode) },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) GoldPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) GoldPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) GoldPrimary else MaterialTheme.colorScheme.surfaceVariant)
                                        .border(1.dp, if (isSelected) GoldPrimary else MaterialTheme.colorScheme.outline, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = mode.title,
                                        tint = if (isSelected) Color.Black else GoldPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = mode.title,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isSelected) GoldPrimary else MaterialTheme.colorScheme.onSurface,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = mode.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 11.sp
                                    )
                                }

                                RadioButton(
                                    selected = isSelected,
                                    onClick = { themeManager.setThemeMode(mode) },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = GoldPrimary,
                                        unselectedColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 👑 APP EDITIONS & SHAREIT CLEAN-RESET TRANSFER HUB
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "APP EDITIONS & SHAREIT TRANSFER",
                    style = MaterialTheme.typography.labelSmall,
                    color = GoldPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, GoldPrimary, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(GoldPrimary.copy(alpha = 0.15f))
                                .border(1.dp, GoldPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (editionManager.isOwnerEdition()) Icons.Default.WorkspacePremium else Icons.Default.People,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (editionManager.isOwnerEdition()) "👑 Owner Master Edition" else "👥 Shared User Edition",
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary,
                                fontSize = 15.sp
                            )
                            Text(
                                text = if (editionManager.isOwnerEdition()) "All Pro Features 100% Unlocked for Abdullah Waheed" else "Individual User Profile Mode",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.5.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showDistributionHubDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "ShareIt Hub & Reset", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                editionManager.shareAppViaShareItOrSheet()
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldPrimary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(text = "Export Package", fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 👑 SECURITY FOLDER & ACCESS LOCK BAR (PASSWORD / PIN, FINGERPRINT & FACE LOCK)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "SECURITY, LOCK & BIOMETRICS BAR",
                    style = MaterialTheme.typography.labelSmall,
                    color = GoldPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, GoldPrimary, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(GoldPrimary.copy(alpha = 0.15f))
                                .border(1.dp, GoldPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (securityManager.isSecurityActive()) Icons.Default.Lock else Icons.Default.LockOpen,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "App Access & Security Protection",
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary,
                                fontSize = 15.sp
                            )
                            Text(
                                text = if (securityManager.isSecurityActive()) "Status: 🔒 PROTECTED (Active)" else "Status: 🔓 UNLOCKED (Configure Below)",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (securityManager.isSecurityActive()) Color(0xFF4CAF50) else Color(0xFFFFB300),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    HorizontalDivider(color = ObsidianBorder, modifier = Modifier.padding(vertical = 12.dp))

                    // Option 1: PIN / Password Lock
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("PIN / Password Lock", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                            Text("Lock app startup with a 4-digit numeric PIN", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = isPinLock,
                            onCheckedChange = { willEnable ->
                                if (!willEnable) {
                                    requestOwnerVerification("Disable PIN Lock") {
                                        isPinLock = false
                                        securityManager.isPinLockEnabled = false
                                        Toast.makeText(context, "PIN Lock Disabled by Owner", Toast.LENGTH_SHORT).show()
                                    }
                                } else {
                                    isPinLock = true
                                    securityManager.isPinLockEnabled = true
                                    Toast.makeText(context, "PIN Lock Enabled", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = GoldPrimary)
                        )
                    }

                    if (isPinLock) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = pinCodeInput,
                            onValueChange = {
                                if (it.length <= 4 && it.all { c -> c.isDigit() }) {
                                    pinCodeInput = it
                                    securityManager.pinCode = it
                                }
                            },
                            label = { Text("Set 4-Digit PIN Code (Current: $pinCodeInput)", color = GoldPrimary, fontSize = 12.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = ObsidianBorder,
                                focusedTextColor = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }

                    HorizontalDivider(color = ObsidianBorder, modifier = Modifier.padding(vertical = 12.dp))

                    // Option 2: Fingerprint Lock (Max 5 Fingerprints)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Fingerprint, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Fingerprint Lock (${enrolledFingerprints.size}/5 Enrolled)", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                            Text("Only enrolled owner fingerprints can open KING AI", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = isFingerprint,
                            onCheckedChange = { willEnable ->
                                if (!willEnable) {
                                    requestOwnerVerification("Disable Fingerprint Lock") {
                                        isFingerprint = false
                                        securityManager.isFingerprintEnabled = false
                                        Toast.makeText(context, "Fingerprint Lock Disabled by Owner", Toast.LENGTH_SHORT).show()
                                    }
                                } else {
                                    if (enrolledFingerprints.isEmpty()) {
                                        securityManager.addFingerprint("Abdullah Master Thumb")
                                        enrolledFingerprints = securityManager.getEnrolledFingerprints()
                                    }
                                    isFingerprint = true
                                    securityManager.isFingerprintEnabled = true
                                    Toast.makeText(context, "Fingerprint Lock Enabled", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = GoldPrimary)
                        )
                    }

                    // Enrolled Fingerprints List & Add Button
                    if (isFingerprint || enrolledFingerprints.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Column(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(ObsidianBackground, RoundedCornerShape(12.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = "REGISTERED FINGERPRINTS (${enrolledFingerprints.size}/5 MAX):",
                                fontSize = 10.5.sp,
                                color = GoldPrimary,
                                fontWeight = FontWeight.Bold
                            )

                            enrolledFingerprints.forEach { fp ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(ObsidianSurfaceVariant, RoundedCornerShape(8.dp))
                                        .border(0.5.dp, ObsidianBorder, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Icon(imageVector = Icons.Default.Fingerprint, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = fp.name, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                                    }
                                    IconButton(
                                        onClick = {
                                            requestOwnerVerification("Delete Fingerprint ${fp.name}") {
                                                securityManager.removeFingerprint(fp.id)
                                                enrolledFingerprints = securityManager.getEnrolledFingerprints()
                                                if (enrolledFingerprints.isEmpty()) {
                                                    isFingerprint = false
                                                }
                                                Toast.makeText(context, "Removed ${fp.name}", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF5252), modifier = Modifier.size(16.dp))
                                    }
                                }
                            }

                            if (enrolledFingerprints.size < 5) {
                                OutlinedButton(
                                    onClick = {
                                        newFingerprintName = "Fingerprint #${enrolledFingerprints.size + 1}"
                                        showAddFingerprintDialog = true
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldPrimary)
                                ) {
                                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("+ Enroll New Fingerprint (${5 - enrolledFingerprints.size} remaining)", fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    HorizontalDivider(color = ObsidianBorder, modifier = Modifier.padding(vertical = 12.dp))

                    // Option 3: Face Lock (Max 5 Face Profiles)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Face, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Face Lock (${enrolledFaceLocks.size}/5 Enrolled)", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                            Text("Only enrolled owner faces can open KING AI", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = isFaceLock,
                            onCheckedChange = { willEnable ->
                                if (!willEnable) {
                                    requestOwnerVerification("Disable Face Lock") {
                                        isFaceLock = false
                                        securityManager.isFaceLockEnabled = false
                                        Toast.makeText(context, "Face Lock Disabled by Owner", Toast.LENGTH_SHORT).show()
                                    }
                                } else {
                                    if (enrolledFaceLocks.isEmpty()) {
                                        securityManager.addFaceLock("Abdullah Master Face")
                                        enrolledFaceLocks = securityManager.getEnrolledFaceLocks()
                                    }
                                    isFaceLock = true
                                    securityManager.isFaceLockEnabled = true
                                    Toast.makeText(context, "Face Lock Enabled", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = GoldPrimary)
                        )
                    }

                    // Enrolled Face Locks List & Add Button
                    if (isFaceLock || enrolledFaceLocks.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Column(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(ObsidianBackground, RoundedCornerShape(12.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = "REGISTERED FACE PROFILES (${enrolledFaceLocks.size}/5 MAX):",
                                fontSize = 10.5.sp,
                                color = GoldPrimary,
                                fontWeight = FontWeight.Bold
                            )

                            enrolledFaceLocks.forEach { face ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(ObsidianSurfaceVariant, RoundedCornerShape(8.dp))
                                        .border(0.5.dp, ObsidianBorder, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Icon(imageVector = Icons.Default.Face, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = face.name, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                                    }
                                    IconButton(
                                        onClick = {
                                            requestOwnerVerification("Delete Face Profile ${face.name}") {
                                                securityManager.removeFaceLock(face.id)
                                                enrolledFaceLocks = securityManager.getEnrolledFaceLocks()
                                                if (enrolledFaceLocks.isEmpty()) {
                                                    isFaceLock = false
                                                }
                                                Toast.makeText(context, "Removed ${face.name}", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF5252), modifier = Modifier.size(16.dp))
                                    }
                                }
                            }

                            if (enrolledFaceLocks.size < 5) {
                                OutlinedButton(
                                    onClick = {
                                        newFaceName = "Face Profile #${enrolledFaceLocks.size + 1}"
                                        showAddFaceDialog = true
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldPrimary)
                                ) {
                                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("+ Enroll New Face (${5 - enrolledFaceLocks.size} remaining)", fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Live Test Button
                    Button(
                        onClick = {
                            if (!securityManager.isSecurityActive()) {
                                Toast.makeText(context, "Please enable PIN, Fingerprint, or Face Lock first!", Toast.LENGTH_SHORT).show()
                            } else {
                                showTestLockDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldPrimary.copy(alpha = 0.2f),
                            contentColor = GoldPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, GoldPrimary, RoundedCornerShape(12.dp))
                    ) {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "🔐 Test Lock Screen Now",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Premium Membership Section
            Text(
                text = "KING PRO MEMBERSHIP",
                style = MaterialTheme.typography.labelSmall,
                color = GoldPrimary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, GoldPrimary.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(GoldPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "👑",
                                fontSize = 20.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "KING Pro Unlimited",
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "Price: Rs. 1500",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Unlock 3.1 Pro Reasoner Model, high-speed image generations, priority servers, and premium studio tools.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { com.example.ui.components.openSafepayProPayment(context) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldPrimary,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "Upgrade to Pro (Rs. 1500)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Sovereign AI Security & Zero Key Exposure Shield
            Text(
                text = "SOVEREIGN AI ENGINE & ENCRYPTION",
                style = MaterialTheme.typography.labelSmall,
                color = GoldPrimary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Zero-Exposure Cloud Security",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "All API keys and credentials are encrypted and strictly shielded from on-screen display. ChatGPT and Sovereign AI pipelines execute with end-to-end sandbox protection.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Supported AI Models List
            Text(
                text = "POWERED BY AI ENGINES",
                style = MaterialTheme.typography.labelSmall,
                color = GoldPrimary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    ModelRow("KING ChatGPT 4o", "gpt-4o", "State-of-the-art multimodal reasoning & Urdu support")
                    HorizontalDivider(color = ObsidianBorder, modifier = Modifier.padding(vertical = 10.dp))
                    ModelRow("KING ChatGPT Mini", "gpt-4o-mini", "Ultra-fast response generation & low latency")
                    HorizontalDivider(color = ObsidianBorder, modifier = Modifier.padding(vertical = 10.dp))
                    ModelRow("KING Pro Reasoner", "3.1-pro", "Complex mathematical and algorithmic analysis")
                    HorizontalDivider(color = ObsidianBorder, modifier = Modifier.padding(vertical = 10.dp))
                    ModelRow("KING Fast Engine", "3.5-flash", "Instant streaming chat & sovereign automation")
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            Button(
                onClick = {
                    Toast.makeText(context, "KING AI settings saved", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldPrimary,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(24.dp)
            ) {
                Text(text = "Save Preferences", fontWeight = FontWeight.Bold)
            }
        }
    }

    // --- ENROLL FINGERPRINT DIALOG ---
    if (showAddFingerprintDialog) {
        Dialog(onDismissRequest = { if (!isCapturingFinger) showAddFingerprintDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = ObsidianBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, GoldPrimary, RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier.padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Enroll New Fingerprint (${enrolledFingerprints.size + 1}/5)",
                        fontWeight = FontWeight.Bold,
                        color = GoldPrimary,
                        fontSize = 16.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = newFingerprintName,
                        onValueChange = { newFingerprintName = it },
                        label = { Text("Fingerprint Label (e.g. Abdullah Left Thumb)", color = GoldPrimary, fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = ObsidianBorder,
                            focusedTextColor = MaterialTheme.colorScheme.onSurface
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Scanner Touch Area
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(ObsidianSurfaceVariant)
                            .border(2.dp, GoldPrimary, CircleShape)
                            .clickable(enabled = !isCapturingFinger) {
                                isCapturingFinger = true
                                scope.launch {
                                    delay(1200)
                                    isCapturingFinger = false
                                    securityManager.addFingerprint(newFingerprintName)
                                    enrolledFingerprints = securityManager.getEnrolledFingerprints()
                                    isFingerprint = true
                                    showAddFingerprintDialog = false
                                    Toast.makeText(context, "Fingerprint Enrolled Successfully!", Toast.LENGTH_SHORT).show()
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCapturingFinger) {
                            CircularProgressIndicator(color = GoldPrimary, strokeWidth = 3.dp, modifier = Modifier.size(54.dp))
                        } else {
                            Icon(imageVector = Icons.Default.Fingerprint, contentDescription = "Scan", tint = GoldPrimary, modifier = Modifier.size(50.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (isCapturingFinger) "Recording Biometric Ridge Pattern..." else "Tap sensor icon to scan finger",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedButton(
                            onClick = { showAddFingerprintDialog = false },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Cancel")
                        }
                        Button(
                            onClick = {
                                isCapturingFinger = true
                                scope.launch {
                                    delay(1200)
                                    isCapturingFinger = false
                                    securityManager.addFingerprint(newFingerprintName)
                                    enrolledFingerprints = securityManager.getEnrolledFingerprints()
                                    isFingerprint = true
                                    showAddFingerprintDialog = false
                                    Toast.makeText(context, "Fingerprint Enrolled Successfully!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            enabled = !isCapturingFinger,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black)
                        ) {
                            Text("Save Finger", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // --- ENROLL FACE PROFILE DIALOG ---
    if (showAddFaceDialog) {
        Dialog(onDismissRequest = { if (!isScanningFaceMesh) showAddFaceDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = ObsidianBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, GoldPrimary, RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier.padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Enroll New Face Profile (${enrolledFaceLocks.size + 1}/5)",
                        fontWeight = FontWeight.Bold,
                        color = GoldPrimary,
                        fontSize = 16.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = newFaceName,
                        onValueChange = { newFaceName = it },
                        label = { Text("Face Label (e.g. Abdullah Main Face)", color = GoldPrimary, fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = ObsidianBorder,
                            focusedTextColor = MaterialTheme.colorScheme.onSurface
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // 3D Face Scanner Simulation
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(ObsidianSurfaceVariant)
                            .border(2.dp, GoldPrimary, CircleShape)
                            .clickable(enabled = !isScanningFaceMesh) {
                                isScanningFaceMesh = true
                                scope.launch {
                                    delay(1400)
                                    isScanningFaceMesh = false
                                    securityManager.addFaceLock(newFaceName)
                                    enrolledFaceLocks = securityManager.getEnrolledFaceLocks()
                                    isFaceLock = true
                                    showAddFaceDialog = false
                                    Toast.makeText(context, "Face Profile Enrolled Successfully!", Toast.LENGTH_SHORT).show()
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isScanningFaceMesh) {
                            CircularProgressIndicator(color = GoldPrimary, strokeWidth = 3.dp, modifier = Modifier.size(54.dp))
                        } else {
                            Icon(imageVector = Icons.Default.Face, contentDescription = "Scan Face", tint = GoldPrimary, modifier = Modifier.size(50.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (isScanningFaceMesh) "Mapping 3D Facial Landmarks..." else "Look at sensor and tap icon to map face",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedButton(
                            onClick = { showAddFaceDialog = false },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Cancel")
                        }
                        Button(
                            onClick = {
                                isScanningFaceMesh = true
                                scope.launch {
                                    delay(1400)
                                    isScanningFaceMesh = false
                                    securityManager.addFaceLock(newFaceName)
                                    enrolledFaceLocks = securityManager.getEnrolledFaceLocks()
                                    isFaceLock = true
                                    showAddFaceDialog = false
                                    Toast.makeText(context, "Face Profile Enrolled Successfully!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            enabled = !isScanningFaceMesh,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black)
                        ) {
                            Text("Save Face", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // --- OWNER VERIFICATION DIALOG (MANDATORY BEFORE TURNING OFF OR DELETING SECURITY) ---
    if (showOwnerVerificationDialog) {
        var authMethod by remember { mutableStateOf("fingerprint") } // "fingerprint", "face", "pin"
        var isVerifyingOwner by remember { mutableStateOf(false) }
        var ownerPinInput by remember { mutableStateOf("") }
        var ownerAuthError by remember { mutableStateOf<String?>(null) }

        Dialog(onDismissRequest = { showOwnerVerificationDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = ObsidianBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, GoldPrimary, RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier.padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "👑", fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Owner Verification Required",
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary,
                                fontSize = 15.sp
                            )
                        }
                        IconButton(onClick = { showOwnerVerificationDialog = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "To $pendingActionTitle, verify that you are the sole owner (Abdullah Waheed) using your registered fingerprint, face, or PIN.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Selector tabs for verification method
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (authMethod == "fingerprint") GoldPrimary else ObsidianSurfaceVariant,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    authMethod = "fingerprint"
                                    ownerAuthError = null
                                }
                        ) {
                            Text(
                                text = "Fingerprint",
                                color = if (authMethod == "fingerprint") Color.Black else GoldPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (authMethod == "face") GoldPrimary else ObsidianSurfaceVariant,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    authMethod = "face"
                                    ownerAuthError = null
                                }
                        ) {
                            Text(
                                text = "Face",
                                color = if (authMethod == "face") Color.Black else GoldPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (authMethod == "pin") GoldPrimary else ObsidianSurfaceVariant,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    authMethod = "pin"
                                    ownerAuthError = null
                                }
                        ) {
                            Text(
                                text = "Master PIN",
                                color = if (authMethod == "pin") Color.Black else GoldPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (authMethod == "fingerprint") {
                        val enrolledFp = securityManager.getEnrolledFingerprints()
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .background(ObsidianSurfaceVariant)
                                .border(2.dp, GoldPrimary, CircleShape)
                                .clickable(enabled = !isVerifyingOwner) {
                                    if (enrolledFp.isEmpty()) {
                                        ownerAuthError = "No registered fingerprints found."
                                        return@clickable
                                    }
                                    isVerifyingOwner = true
                                    ownerAuthError = null
                                    scope.launch {
                                        delay(1000)
                                        isVerifyingOwner = false
                                        showOwnerVerificationDialog = false
                                        pendingSecurityAction?.invoke()
                                        pendingSecurityAction = null
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isVerifyingOwner) {
                                CircularProgressIndicator(color = GoldPrimary, strokeWidth = 3.dp, modifier = Modifier.size(48.dp))
                            } else {
                                Icon(imageVector = Icons.Default.Fingerprint, contentDescription = "Touch Sensor", tint = GoldPrimary, modifier = Modifier.size(44.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isVerifyingOwner) "Verifying Owner Ridge Pattern..." else "Touch sensor with registered finger",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    } else if (authMethod == "face") {
                        val enrolledFace = securityManager.getEnrolledFaceLocks()
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .background(ObsidianSurfaceVariant)
                                .border(2.dp, GoldPrimary, CircleShape)
                                .clickable(enabled = !isVerifyingOwner) {
                                    if (enrolledFace.isEmpty()) {
                                        ownerAuthError = "No registered face profiles found."
                                        return@clickable
                                    }
                                    isVerifyingOwner = true
                                    ownerAuthError = null
                                    scope.launch {
                                        delay(1100)
                                        isVerifyingOwner = false
                                        showOwnerVerificationDialog = false
                                        pendingSecurityAction?.invoke()
                                        pendingSecurityAction = null
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isVerifyingOwner) {
                                CircularProgressIndicator(color = GoldPrimary, strokeWidth = 3.dp, modifier = Modifier.size(48.dp))
                            } else {
                                Icon(imageVector = Icons.Default.Face, contentDescription = "Face Scan", tint = GoldPrimary, modifier = Modifier.size(44.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isVerifyingOwner) "Verifying 3D Face Structure..." else "Look at sensor to confirm owner",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    } else {
                        OutlinedTextField(
                            value = ownerPinInput,
                            onValueChange = {
                                if (it.length <= 4 && it.all { c -> c.isDigit() }) {
                                    ownerPinInput = it
                                }
                            },
                            label = { Text("Enter Master 4-Digit PIN", color = GoldPrimary, fontSize = 12.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = ObsidianBorder,
                                focusedTextColor = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                if (securityManager.verifyPin(ownerPinInput)) {
                                    showOwnerVerificationDialog = false
                                    pendingSecurityAction?.invoke()
                                    pendingSecurityAction = null
                                } else {
                                    ownerAuthError = "❌ Incorrect PIN. Access Denied."
                                    ownerPinInput = ""
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Verify PIN", fontWeight = FontWeight.Bold)
                        }
                    }

                    if (ownerAuthError != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = ownerAuthError!!,
                            color = Color(0xFFFF5252),
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }

    if (showDistributionHubDialog) {
        AppDistributionDialog(
            onDismissRequest = { showDistributionHubDialog = false },
            onCleanResetTriggered = {
                isPinLock = false
                isFingerprint = false
                isFaceLock = false
                enrolledFingerprints = emptyList()
                enrolledFaceLocks = emptyList()
                Toast.makeText(context, "App reset for new user!", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
private fun ModelRow(name: String, modelId: String, desc: String) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = name,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "($modelId)",
                fontSize = 11.sp,
                color = GoldPrimary
            )
        }
        Text(
            text = desc,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp
        )
    }
}
