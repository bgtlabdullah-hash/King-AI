package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant

import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.example.data.local.KingAiDatabase
import com.example.data.repository.KingAiRepository
import com.example.ui.components.AudioTranscriptionDialog
import com.example.ui.components.FirestoreChatSyncDialog
import com.example.ui.components.GoogleMapsDirectionsDialog
import com.example.ui.components.LiveVoiceDialog
import com.example.ui.components.Veo3VideoDialog

data class ToolPreset(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val samplePrompt: String,
    val featureType: String = "prompt"
)

val ToolPresets = listOf(
    ToolPreset(
        title = "🎬 KING Cinema Studio 4K",
        subtitle = "Motion Dream & Photon 4K Generator with Camera Trajectory Director & Keyframe Animator",
        icon = Icons.Default.Movie,
        samplePrompt = "",
        featureType = "cinema_studio"
    ),
    ToolPreset(
        title = "Live Voice Conversation",
        subtitle = "Real-time voice dialog via gemini-3.1-flash-live-preview",
        icon = Icons.Default.RecordVoiceOver,
        samplePrompt = "",
        featureType = "live_voice"
    ),
    ToolPreset(
        title = "Veo 3 Video Generator",
        subtitle = "Generate videos from text with veo-3.1-fast-generate-preview (16:9 / 9:16)",
        icon = Icons.Default.Movie,
        samplePrompt = "",
        featureType = "veo3_video"
    ),
    ToolPreset(
        title = "Audio Transcription",
        subtitle = "Transcribe microphone audio or speech with gemini-3.5-flash",
        icon = Icons.Default.Subtitles,
        samplePrompt = "",
        featureType = "audio_transcribe"
    ),
    ToolPreset(
        title = "🧭 Google Maps Directions & Navigation",
        subtitle = "Search any place to get live turn-by-turn route, distance & Google Maps navigation",
        icon = Icons.Default.Directions,
        samplePrompt = "",
        featureType = "maps_directions"
    ),
    ToolPreset(
        title = "☁️ Firestore Cloud History Sync",
        subtitle = "Sync and backup your local Room chat conversations to Firebase Cloud Firestore",
        icon = Icons.Default.CloudSync,
        samplePrompt = "",
        featureType = "firestore_sync"
    ),
    ToolPreset(
        title = "Code Architect",
        subtitle = "Write, debug & optimize clean code",
        icon = Icons.Default.Code,
        samplePrompt = "Write a complete, thread-safe Kotlin implementation of a Repository pattern with Room database and Coroutines."
    ),
    ToolPreset(
        title = "Writing Specialist",
        subtitle = "Professional emails, articles & essays",
        icon = Icons.Default.Edit,
        samplePrompt = "Draft an executive pitch email introducing a high-impact AI assistant platform to potential venture partners."
    ),
    ToolPreset(
        title = "Brainstorming Hub",
        subtitle = "Innovative startup ideas & solutions",
        icon = Icons.Default.Lightbulb,
        samplePrompt = "Provide 5 breakthrough AI startup ideas for sustainable energy optimization with revenue models."
    ),
    ToolPreset(
        title = "👑 Monogram Maker Studio",
        subtitle = "Design royal crests, luxury initial emblems with golden wings & crowns",
        icon = Icons.Default.MilitaryTech,
        samplePrompt = "Design a luxury 24K gold royal monogram with initials 'AI', flanked by majestic feathered wings and crowned with a French fleur-de-lis tiara on deep obsidian background."
    ),
    ToolPreset(
        title = "Prompt Architect",
        subtitle = "Craft Midjourney & 4K AI image prompts",
        icon = Icons.Default.Palette,
        samplePrompt = "Design 3 highly detailed 4K prompts for generating royal fantasy castles in KING AI Image Studio."
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsScreen(
    onSelectToolPrompt: (String) -> Unit,
    onBackToChat: () -> Unit,
    onNavigateToCinemaStudio: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val repository = remember {
        val db = KingAiDatabase.getDatabase(context)
        KingAiRepository(db.chatDao(), db.imageCreatorDao())
    }

    var showLiveVoiceDialog by remember { mutableStateOf(false) }
    var showVeo3VideoDialog by remember { mutableStateOf(false) }
    var showAudioTranscribeDialog by remember { mutableStateOf(false) }
    var showGoogleMapsDirectionsDialog by remember { mutableStateOf(false) }
    var showFirestoreSyncDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Widgets,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "KING Studio Tools",
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary,
                            fontSize = 18.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackToChat) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = GoldPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsidianBackground)
            )
        },
        containerColor = ObsidianBackground,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Text(
                text = "SPECIALIZED AI MODELS & TOOLS",
                style = MaterialTheme.typography.labelSmall,
                color = GoldPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Tap any tool to launch Live Voice, Veo 3 Video, Audio Transcribe or Maps Grounding",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(1),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(ToolPresets) { tool ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(16.dp))
                            .clickable {
                                when (tool.featureType) {
                                    "cinema_studio" -> onNavigateToCinemaStudio()
                                    "live_voice" -> showLiveVoiceDialog = true
                                    "veo3_video" -> showVeo3VideoDialog = true
                                    "audio_transcribe" -> showAudioTranscribeDialog = true
                                    "maps_directions" -> showGoogleMapsDirectionsDialog = true
                                    "firestore_sync" -> showFirestoreSyncDialog = true
                                    else -> onSelectToolPrompt(tool.samplePrompt)
                                }
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(ObsidianBackground)
                                    .border(1.dp, GoldPrimary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = tool.icon,
                                    contentDescription = tool.title,
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = tool.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = tool.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showLiveVoiceDialog) {
        LiveVoiceDialog(repository = repository, onDismissRequest = { showLiveVoiceDialog = false })
    }

    if (showVeo3VideoDialog) {
        Veo3VideoDialog(repository = repository, onDismissRequest = { showVeo3VideoDialog = false })
    }

    if (showAudioTranscribeDialog) {
        AudioTranscriptionDialog(repository = repository, onDismissRequest = { showAudioTranscribeDialog = false })
    }

    if (showGoogleMapsDirectionsDialog) {
        GoogleMapsDirectionsDialog(repository = repository, onDismissRequest = { showGoogleMapsDirectionsDialog = false })
    }

    if (showFirestoreSyncDialog) {
        FirestoreChatSyncDialog(repository = repository, onDismissRequest = { showFirestoreSyncDialog = false })
    }
}
