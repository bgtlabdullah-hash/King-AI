package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ChatEntity::class, MessageEntity::class, GeneratedImageEntity::class, GeneratedVideoEntity::class],
    version = 2,
    exportSchema = false
)
abstract class KingAiDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun imageCreatorDao(): ImageCreatorDao
    abstract fun videoCreatorDao(): VideoCreatorDao

    companion object {
        @Volatile
        private var INSTANCE: KingAiDatabase? = null

        fun getDatabase(context: Context): KingAiDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KingAiDatabase::class.java,
                    "king_ai_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
