package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "generated_videos")
data class GeneratedVideoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val prompt: String,
    val consistencyStyle: String = "Cinematic Masterpiece",
    val aspectRatio: String = "16:9",
    val durationSeconds: Int = 5,
    val motionConsistency: String = "Smooth 60 FPS",
    val seedConsistency: String = "Strict Consistency",
    val videoDataOrUrl: String,
    val timestamp: Long = System.currentTimeMillis()
)
