package com.example.data.sync

import android.content.Context
import android.util.Log
import com.example.data.local.ChatDao
import com.example.data.local.ChatEntity
import com.example.data.local.KingAiDatabase
import com.example.data.local.MessageEntity
import com.example.data.local.MessageSender
import com.google.android.gms.tasks.Task
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

sealed class SyncState {
    object Idle : SyncState()
    object Syncing : SyncState()
    data class Success(val message: String, val timestamp: Long = System.currentTimeMillis()) : SyncState()
    data class Error(val errorMessage: String) : SyncState()
}

class FirestoreChatSyncService(
    private val chatDao: ChatDao,
    private val firestore: FirebaseFirestore? = try {
        FirebaseFirestore.getInstance()
    } catch (e: Exception) {
        Log.w("FirestoreChatSync", "FirebaseFirestore initialization failed: ${e.message}")
        null
    }
) {
    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    private val _lastSyncedTime = MutableStateFlow<Long?>(null)
    val lastSyncedTime: StateFlow<Long?> = _lastSyncedTime.asStateFlow()

    /**
     * Synchronize all local Room chats and their messages up to Cloud Firestore.
     */
    suspend fun syncLocalRoomToFirestore(userId: String): Result<Int> = withContext(Dispatchers.IO) {
        if (userId.isBlank()) {
            val err = "Cannot sync without a valid user ID/email"
            _syncState.value = SyncState.Error(err)
            return@withContext Result.failure(IllegalArgumentException(err))
        }

        val db = firestore
        if (db == null) {
            val err = "Firebase Firestore is not initialized or unavailable on this device"
            _syncState.value = SyncState.Error(err)
            return@withContext Result.failure(IllegalStateException(err))
        }

        _syncState.value = SyncState.Syncing

        try {
            val localChats = chatDao.getAllChatsList()
            if (localChats.isEmpty()) {
                _syncState.value = SyncState.Success("No local chats to sync")
                return@withContext Result.success(0)
            }

            var syncedMessagesCount = 0
            val sanitizedUserId = userId.replace(".", "_").replace("#", "_").replace("$", "_").replace("[", "_").replace("]", "_")
            val userDocRef = db.collection("users").document(sanitizedUserId)

            // Update user metadata
            val userMeta = mapOf(
                "userId" to userId,
                "lastSyncTime" to FieldValue.serverTimestamp(),
                "totalChats" to localChats.size
            )
            userDocRef.set(userMeta, SetOptions.merge()).awaitResult()

            for (chat in localChats) {
                val chatData = hashMapOf<String, Any>(
                    "chatId" to chat.id,
                    "title" to chat.title,
                    "createdAt" to chat.createdAt,
                    "updatedAt" to chat.updatedAt,
                    "modelUsed" to chat.modelUsed,
                    "syncedAt" to System.currentTimeMillis()
                )

                val chatDocRef = userDocRef.collection("chats").document(chat.id.toString())
                chatDocRef.set(chatData, SetOptions.merge()).awaitResult()

                val messages = chatDao.getMessagesForChatList(chat.id)
                for (msg in messages) {
                    val msgData = hashMapOf<String, Any?>(
                        "messageId" to msg.id,
                        "chatId" to msg.chatId,
                        "sender" to msg.sender.name,
                        "content" to msg.content,
                        "imageBase64OrUri" to msg.imageBase64OrUri,
                        "timestamp" to msg.timestamp,
                        "modelUsed" to msg.modelUsed
                    )
                    chatDocRef.collection("messages")
                        .document(msg.id.toString())
                        .set(msgData, SetOptions.merge())
                        .awaitResult()

                    syncedMessagesCount++
                }
            }

            val now = System.currentTimeMillis()
            _lastSyncedTime.value = now
            val successMsg = "Successfully synced ${localChats.size} chats and $syncedMessagesCount messages to Firestore"
            _syncState.value = SyncState.Success(successMsg, now)
            Log.d("FirestoreChatSync", successMsg)
            Result.success(syncedMessagesCount)
        } catch (e: Exception) {
            Log.e("FirestoreChatSync", "Error syncing to Firestore: ${e.message}", e)
            val errorMsg = e.localizedMessage ?: "Sync to Firestore failed"
            _syncState.value = SyncState.Error(errorMsg)
            Result.failure(e)
        }
    }

    /**
     * Synchronize and pull user chat history from Cloud Firestore into local Room Database.
     */
    suspend fun syncFirestoreToLocalRoom(userId: String): Result<Int> = withContext(Dispatchers.IO) {
        if (userId.isBlank()) {
            val err = "Cannot pull history without a valid user ID/email"
            _syncState.value = SyncState.Error(err)
            return@withContext Result.failure(IllegalArgumentException(err))
        }

        val db = firestore
        if (db == null) {
            val err = "Firebase Firestore is not initialized or unavailable on this device"
            _syncState.value = SyncState.Error(err)
            return@withContext Result.failure(IllegalStateException(err))
        }

        _syncState.value = SyncState.Syncing

        try {
            val sanitizedUserId = userId.replace(".", "_").replace("#", "_").replace("$", "_").replace("[", "_").replace("]", "_")
            val userDocRef = db.collection("users").document(sanitizedUserId)

            val chatsSnapshot = userDocRef.collection("chats").get().awaitResult()
            var importedMessagesCount = 0

            for (chatDoc in chatsSnapshot.documents) {
                val chatId = chatDoc.getLong("chatId") ?: chatDoc.id.toLongOrNull() ?: System.currentTimeMillis()
                val title = chatDoc.getString("title") ?: "Restored Chat"
                val createdAt = chatDoc.getLong("createdAt") ?: System.currentTimeMillis()
                val updatedAt = chatDoc.getLong("updatedAt") ?: System.currentTimeMillis()
                val modelUsed = chatDoc.getString("modelUsed") ?: "gemini-3.5-flash"

                val chatEntity = ChatEntity(
                    id = chatId,
                    title = title,
                    createdAt = createdAt,
                    updatedAt = updatedAt,
                    modelUsed = modelUsed
                )
                chatDao.insertChat(chatEntity)

                val messagesSnapshot = chatDoc.reference.collection("messages").get().awaitResult()
                val messageEntities = mutableListOf<MessageEntity>()

                for (msgDoc in messagesSnapshot.documents) {
                    val msgId = msgDoc.getLong("messageId") ?: msgDoc.id.toLongOrNull() ?: 0L
                    val senderStr = msgDoc.getString("sender") ?: "USER"
                    val sender = if (senderStr.equals("AI", ignoreCase = true)) MessageSender.AI else MessageSender.USER
                    val content = msgDoc.getString("content") ?: ""
                    val imageUri = msgDoc.getString("imageBase64OrUri")
                    val timestamp = msgDoc.getLong("timestamp") ?: System.currentTimeMillis()
                    val msgModel = msgDoc.getString("modelUsed")

                    messageEntities.add(
                        MessageEntity(
                            id = msgId,
                            chatId = chatId,
                            sender = sender,
                            content = content,
                            imageBase64OrUri = imageUri,
                            timestamp = timestamp,
                            modelUsed = msgModel
                        )
                    )
                }

                if (messageEntities.isNotEmpty()) {
                    chatDao.insertMessages(messageEntities)
                    importedMessagesCount += messageEntities.size
                }
            }

            val now = System.currentTimeMillis()
            _lastSyncedTime.value = now
            val successMsg = "Successfully restored ${chatsSnapshot.size()} chats and $importedMessagesCount messages from Firestore"
            _syncState.value = SyncState.Success(successMsg, now)
            Log.d("FirestoreChatSync", successMsg)
            Result.success(importedMessagesCount)
        } catch (e: Exception) {
            Log.e("FirestoreChatSync", "Error restoring from Firestore: ${e.message}", e)
            val errorMsg = e.localizedMessage ?: "Restore from Firestore failed"
            _syncState.value = SyncState.Error(errorMsg)
            Result.failure(e)
        }
    }

    suspend fun syncSingleChat(chatId: Long, userId: String): Result<Unit> = withContext(Dispatchers.IO) {
        if (userId.isBlank() || firestore == null) return@withContext Result.failure(IllegalStateException("Unavailable"))
        try {
            val chat = chatDao.getChatById(chatId) ?: return@withContext Result.failure(IllegalArgumentException("Chat not found"))
            val sanitizedUserId = userId.replace(".", "_").replace("#", "_").replace("$", "_").replace("[", "_").replace("]", "_")
            val chatDocRef = firestore.collection("users").document(sanitizedUserId).collection("chats").document(chatId.toString())

            val chatData = hashMapOf<String, Any>(
                "chatId" to chat.id,
                "title" to chat.title,
                "createdAt" to chat.createdAt,
                "updatedAt" to chat.updatedAt,
                "modelUsed" to chat.modelUsed,
                "syncedAt" to System.currentTimeMillis()
            )
            chatDocRef.set(chatData, SetOptions.merge()).awaitResult()

            val messages = chatDao.getMessagesForChatList(chatId)
            for (msg in messages) {
                val msgData = hashMapOf<String, Any?>(
                    "messageId" to msg.id,
                    "chatId" to msg.chatId,
                    "sender" to msg.sender.name,
                    "content" to msg.content,
                    "imageBase64OrUri" to msg.imageBase64OrUri,
                    "timestamp" to msg.timestamp,
                    "modelUsed" to msg.modelUsed
                )
                chatDocRef.collection("messages").document(msg.id.toString()).set(msgData, SetOptions.merge()).awaitResult()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: FirestoreChatSyncService? = null

        fun getInstance(context: Context): FirestoreChatSyncService {
            return INSTANCE ?: synchronized(this) {
                val db = KingAiDatabase.getDatabase(context.applicationContext)
                val instance = FirestoreChatSyncService(db.chatDao())
                INSTANCE = instance
                instance
            }
        }
    }
}

/**
 * Coroutine extension function to convert Play Services Tasks to coroutines safely.
 */
private suspend fun <T> Task<T>.awaitResult(): T =
    suspendCancellableCoroutine { continuation ->
        addOnSuccessListener { result ->
            if (continuation.isActive) continuation.resume(result)
        }
        addOnFailureListener { exception ->
            if (continuation.isActive) continuation.resumeWithException(exception)
        }
        addOnCanceledListener {
            if (continuation.isActive) continuation.cancel()
        }
    }
