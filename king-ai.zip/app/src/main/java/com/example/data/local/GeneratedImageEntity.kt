package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "generated_images")
data class GeneratedImageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val prompt: String,
    val stylePreset: String,
    val aspectRatio: String,
    val imageDataBase64OrUrl: String,
    val timestamp: Long = System.currentTimeMillis()
)
