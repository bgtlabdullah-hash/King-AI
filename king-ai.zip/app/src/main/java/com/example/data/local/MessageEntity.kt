package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MessageSender {
    USER, AI
}

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chatId: Long,
    val sender: MessageSender,
    val content: String,
    val imageBase64OrUri: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val modelUsed: String? = null
)
