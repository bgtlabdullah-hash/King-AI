package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sophisticated Dark Theme - Amber & Zinc Deep Obsidian Palette
val GoldPrimary = Color(0xFFF59E0B) // Amber 500
val GoldLight = Color(0xFFFBBF24) // Amber 400
val GoldDark = Color(0xFFD97706) // Amber 600
val GoldContainer = Color(0xFF2E2200)
val OnGoldContainer = Color(0xFFFDE68A)

val ObsidianBackground = Color(0xFF0F0F0F) // #0F0F0F
val ObsidianSurface = Color(0xFF18181B) // Zinc 900
val ObsidianSurfaceVariant = Color(0xFF27272A) // Zinc 800
val ObsidianBorder = Color(0xFF3F3F46) // Zinc 700

val TextPrimary = Color(0xFFE6E1E5)
val TextSecondary = Color(0xFFA1A1AA)
val TextMuted = Color(0xFF71717A)

val RoyalPurple = Color(0xFF8B5CF6)
val AccentCyan = Color(0xFF06B6D4)
val AccentRose = Color(0xFFF43F5E)

val UserBubbleColor = Color(0xFFF59E0B) // Amber 500
val UserBubbleTextColor = Color(0xFF000000)
val AiBubbleColor = Color(0xFF18181B) // Zinc 900
val CodeBgColor = Color(0xFF121214)

