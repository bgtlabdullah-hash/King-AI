package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.fragment.app.FragmentActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.components.KingDrawerContent
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ImageCreatorScreen
import com.example.ui.screens.MediaGalleryScreen
import com.example.ui.screens.MonogramMakerScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ToolsScreen
import com.example.ui.theme.KingAiTheme
import com.example.ui.viewmodel.ImageCreatorViewModel
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.example.ui.components.KingStartingAnimation
import com.example.ui.components.SecurityLockOverlay
import com.example.util.SecurityManager

import com.example.ui.components.AppDistributionDialog
import com.example.ui.components.FirestoreChatSyncDialog
import com.example.ui.components.UserRegistrationDialog
import com.example.util.AppEditionManager

class MainActivity : FragmentActivity() {

    private val mainViewModel: MainViewModel by viewModels()
    private val imageCreatorViewModel: ImageCreatorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val themeManager = remember { com.example.util.ThemeManager.getInstance(this) }
            val currentThemeMode by themeManager.themeMode.collectAsState()

            KingAiTheme(themeMode = currentThemeMode) {
                KingAiApp(
                    mainViewModel = mainViewModel,
                    imageCreatorViewModel = imageCreatorViewModel
                )
            }
        }
    }
}

@Composable
fun KingAiApp(
    mainViewModel: MainViewModel,
    imageCreatorViewModel: ImageCreatorViewModel
) {
    val context = LocalContext.current
    val securityManager = remember { SecurityManager(context) }
    val editionManager = remember { AppEditionManager(context) }

    var showStartingAnimation by remember { mutableStateOf(true) }
    var isAppUnlocked by remember { mutableStateOf(!securityManager.isSecurityActive()) }
    var showRegistrationDialog by remember { mutableStateOf(!editionManager.isUserRegistered) }
    var showDistributionDialog by remember { mutableStateOf(false) }
    var showFirestoreSyncDialog by remember { mutableStateOf(false) }

    if (showStartingAnimation) {
        KingStartingAnimation(
            onAnimationFinished = {
                showStartingAnimation = false
            }
        )
        return
    }

    if (showRegistrationDialog) {
        UserRegistrationDialog(
            onRegistrationCompleted = { name, email ->
                showRegistrationDialog = false
                isAppUnlocked = true
                mainViewModel.login(name, email)
                mainViewModel.startNewChat()
            }
        )
        return
    }

    if (!isAppUnlocked && securityManager.isSecurityActive()) {
        SecurityLockOverlay(
            securityManager = securityManager,
            onUnlocked = { isAppUnlocked = true }
        )
        return
    }

    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    val chatsList by mainViewModel.chatsList.collectAsState()
    val activeChatId by mainViewModel.activeChatId.collectAsState()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                KingDrawerContent(
                    chats = chatsList,
                    activeChatId = activeChatId,
                    onNewChatClicked = {
                        mainViewModel.startNewChat()
                        coroutineScope.launch { drawerState.close() }
                    },
                    onSelectChat = { chatId ->
                        mainViewModel.selectChat(chatId)
                        coroutineScope.launch { drawerState.close() }
                    },
                    onDeleteChat = { chatId ->
                        mainViewModel.deleteChat(chatId)
                    },
                    onNavigateToImageCreator = {
                        coroutineScope.launch { drawerState.close() }
                        navController.navigate("image_creator")
                    },
                    onNavigateToMediaGallery = {
                        coroutineScope.launch { drawerState.close() }
                        navController.navigate("media_gallery")
                    },
                    onNavigateToMonogramMaker = {
                        coroutineScope.launch { drawerState.close() }
                        navController.navigate("monogram_maker")
                    },
                    onNavigateToCinemaStudio = {
                        coroutineScope.launch { drawerState.close() }
                        navController.navigate("cinema_studio")
                    },
                    onNavigateToTools = {
                        coroutineScope.launch { drawerState.close() }
                        navController.navigate("tools")
                    },
                    onNavigateToDashboard = {
                        coroutineScope.launch { drawerState.close() }
                        navController.navigate("dashboard")
                    },
                    onNavigateToSettings = {
                        coroutineScope.launch { drawerState.close() }
                        navController.navigate("settings")
                    },
                    onNavigateToDistributionHub = {
                        coroutineScope.launch { drawerState.close() }
                        showDistributionDialog = true
                    },
                    onOpenCloudSync = {
                        coroutineScope.launch { drawerState.close() }
                        showFirestoreSyncDialog = true
                    }
                )
            }
        }
    ) {
        NavHost(
            navController = navController,
            startDestination = "chat"
        ) {
            composable("chat") {
                ChatScreen(
                    viewModel = mainViewModel,
                    onOpenDrawer = {
                        coroutineScope.launch { drawerState.open() }
                    },
                    onNavigateToSettings = {
                        navController.navigate("settings")
                    }
                )
            }

            composable("image_creator") {
                ImageCreatorScreen(
                    viewModel = imageCreatorViewModel,
                    onBackToChat = { navController.popBackStack() }
                )
            }

            composable("media_gallery") {
                MediaGalleryScreen(
                    viewModel = mainViewModel,
                    onBackToChat = { navController.popBackStack() }
                )
            }

            composable("monogram_maker") {
                MonogramMakerScreen(
                    onBackToChat = { navController.popBackStack() }
                )
            }

            composable("cinema_studio") {
                com.example.ui.screens.KingCinemaStudioScreen(
                    onBackToChat = { navController.popBackStack() },
                    onNavigateToMediaFolder = { navController.navigate("media_gallery") }
                )
            }

            composable("tools") {
                ToolsScreen(
                    onSelectToolPrompt = { prompt ->
                        mainViewModel.sendMessage(prompt)
                        navController.navigate("chat") {
                            popUpTo("chat") { inclusive = true }
                        }
                    },
                    onNavigateToCinemaStudio = { navController.navigate("cinema_studio") },
                    onBackToChat = { navController.popBackStack() }
                )
            }

            composable("dashboard") {
                DashboardScreen(
                    onBackToChat = { navController.popBackStack() }
                )
            }

            composable("settings") {
                SettingsScreen(
                    onBackToChat = { navController.popBackStack() }
                )
            }
        }
    }

    if (showDistributionDialog) {
        AppDistributionDialog(
            onDismissRequest = { showDistributionDialog = false },
            onCleanResetTriggered = {
                showDistributionDialog = false
                showRegistrationDialog = true
                mainViewModel.startNewChat()
            }
        )
    }

    if (showFirestoreSyncDialog) {
        FirestoreChatSyncDialog(
            repository = mainViewModel.repository,
            onDismissRequest = { showFirestoreSyncDialog = false }
        )
    }
}
