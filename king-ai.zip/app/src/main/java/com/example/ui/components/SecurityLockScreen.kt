package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.util.EnrolledFaceLock
import com.example.util.EnrolledFingerprint
import com.example.util.SecurityManager
import com.example.util.BiometricAuthHelper
import com.example.util.BiometricAvailability
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SecurityLockOverlay(
    securityManager: SecurityManager,
    onUnlocked: () -> Unit
) {
    val context = LocalContext.current
    val fragmentActivity = context as? FragmentActivity
    var inputPin by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isVerifying by remember { mutableStateOf(false) }
    var statusText by remember { mutableStateOf("Authenticate to unlock KING AI") }
    var showOpeningAnimation by remember { mutableStateOf(false) }

    var showFingerprintScanDialog by remember { mutableStateOf(false) }
    var showFaceScanDialog by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    fun triggerDeviceBiometrics(isFinger: Boolean) {
        if (fragmentActivity != null) {
            val availability = BiometricAuthHelper.checkBiometricAvailability(context)
            if (availability == BiometricAvailability.AVAILABLE) {
                BiometricAuthHelper.promptBiometricUnlock(
                    activity = fragmentActivity,
                    title = if (isFinger) "Fingerprint Unlock" else "Face Recognition Unlock",
                    subtitle = "Verify your fingerprint or face to open KING AI",
                    negativeButtonText = if (securityManager.isPinLockEnabled) "Use PIN" else "Cancel",
                    onSuccess = {
                        errorMessage = null
                        statusText = "✅ Biometrics Verified! Unlocking..."
                        showOpeningAnimation = true
                    },
                    onError = { code, err ->
                        if (code != androidx.biometric.BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                            code != androidx.biometric.BiometricPrompt.ERROR_USER_CANCELED) {
                            errorMessage = err
                            statusText = "⚠️ Biometric: $err"
                        }
                    },
                    onFailed = {
                        errorMessage = "Fingerprint / Face not recognized"
                        statusText = "❌ Biometric Not Recognized. Try again."
                    }
                )
                return
            }
        }
        // Fallback to on-screen interactive scanner
        if (isFinger) {
            showFingerprintScanDialog = true
        } else {
            showFaceScanDialog = true
        }
    }

    // Auto-prompt real device biometric unlock like phone lock screen
    LaunchedEffect(Unit) {
        if (securityManager.isFingerprintEnabled || securityManager.isFaceLockEnabled) {
            delay(300)
            triggerDeviceBiometrics(isFinger = securityManager.isFingerprintEnabled)
        }
    }

    if (showOpeningAnimation) {
        OpeningMonogramAnimation(
            onAnimationFinished = {
                onUnlocked()
            }
        ) {
            return@OpeningMonogramAnimation
        }
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // KING AI Monogram Badge Header
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(ObsidianSurfaceVariant)
                    .border(2.dp, GoldPrimary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "👑",
                    fontSize = 38.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "KING AI",
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                color = GoldPrimary,
                letterSpacing = 2.sp
            )

            Text(
                text = "App Locked for Security & Privacy",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Active Security Option Badges
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (securityManager.isPinLockEnabled) {
                    SecurityModeBadge(icon = Icons.Default.Lock, label = "PIN")
                }
                if (securityManager.isFingerprintEnabled) {
                    val count = securityManager.getEnrolledFingerprints().size
                    SecurityModeBadge(icon = Icons.Default.Fingerprint, label = "Fingerprint ($count/5)")
                }
                if (securityManager.isFaceLockEnabled) {
                    val count = securityManager.getEnrolledFaceLocks().size
                    SecurityModeBadge(icon = Icons.Default.Face, label = "Face Lock ($count/5)")
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = statusText,
                color = if (errorMessage != null) Color(0xFFFF5252) else GoldPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Direct Unlock options
            if (securityManager.isFingerprintEnabled || securityManager.isFaceLockEnabled) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(bottom = 20.dp)
                ) {
                    if (securityManager.isFingerprintEnabled) {
                        Button(
                            onClick = {
                                triggerDeviceBiometrics(isFinger = true)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ObsidianSurfaceVariant, contentColor = GoldPrimary),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.border(1.dp, GoldPrimary, RoundedCornerShape(16.dp))
                        ) {
                            Icon(imageVector = Icons.Default.Fingerprint, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Scan Fingerprint", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (securityManager.isFaceLockEnabled) {
                        Button(
                            onClick = {
                                triggerDeviceBiometrics(isFinger = false)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ObsidianSurfaceVariant, contentColor = GoldPrimary),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.border(1.dp, GoldPrimary, RoundedCornerShape(16.dp))
                        ) {
                            Icon(imageVector = Icons.Default.Face, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Scan Face", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // PIN Dots Display
            if (securityManager.isPinLockEnabled) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(bottom = 20.dp)
                ) {
                    repeat(4) { index ->
                        val isFilled = index < inputPin.length
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(if (isFilled) GoldPrimary else ObsidianSurfaceVariant)
                                .border(1.dp, GoldPrimary, CircleShape)
                        )
                    }
                }

                // Numeric Keypad
                val keys = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("C", "0", "DEL")
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    keys.forEach { row ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            row.forEach { key ->
                                KeypadButton(
                                    key = key,
                                    onClick = {
                                        when (key) {
                                            "C" -> {
                                                inputPin = ""
                                                errorMessage = null
                                                statusText = "Enter PIN to unlock KING AI"
                                            }
                                            "DEL" -> {
                                                if (inputPin.isNotEmpty()) inputPin = inputPin.dropLast(1)
                                            }
                                            else -> {
                                                if (inputPin.length < 4) {
                                                    inputPin += key
                                                    if (inputPin.length == 4) {
                                                        if (securityManager.verifyPin(inputPin)) {
                                                            errorMessage = null
                                                            statusText = "PIN Verified! Opening KING AI..."
                                                            showOpeningAnimation = true
                                                        } else {
                                                            errorMessage = "Incorrect PIN"
                                                            statusText = "❌ Incorrect PIN. Access Denied."
                                                            inputPin = ""
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // --- BIOMETRIC FINGERPRINT SCANNER DIALOG ---
    if (showFingerprintScanDialog) {
        val enrolledFingerprints = securityManager.getEnrolledFingerprints()
        var isScanningFinger by remember { mutableStateOf(false) }
        var scanError by remember { mutableStateOf<String?>(null) }
        var selectedFinger by remember { mutableStateOf<EnrolledFingerprint?>(enrolledFingerprints.firstOrNull()) }

        Dialog(onDismissRequest = { showFingerprintScanDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = ObsidianBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, GoldPrimary, RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier
                        .padding(22.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "KING Biometric Touch Sensor",
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary,
                            fontSize = 15.sp
                        )
                        IconButton(onClick = { showFingerprintScanDialog = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Scanner Touch Pad
                    Box(
                        modifier = Modifier
                            .size(86.dp)
                            .clip(CircleShape)
                            .background(ObsidianSurfaceVariant)
                            .border(2.dp, if (scanError != null) Color.Red else GoldPrimary, CircleShape)
                            .clickable(enabled = !isScanningFinger) {
                                if (selectedFinger == null) {
                                    scanError = "❌ Unrecognized: Fingerprint not enrolled."
                                    return@clickable
                                }
                                isScanningFinger = true
                                scanError = null
                                scope.launch {
                                    delay(1100)
                                    isScanningFinger = false
                                    if (securityManager.verifyOwnerWithFingerprint(selectedFinger!!.id)) {
                                        showFingerprintScanDialog = false
                                        statusText = "Fingerprint Matched: ${selectedFinger!!.name}"
                                        showOpeningAnimation = true
                                    } else {
                                        scanError = "❌ Access Denied: Unrecognized fingerprint pattern."
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isScanningFinger) {
                            CircularProgressIndicator(modifier = Modifier.size(50.dp), color = GoldPrimary, strokeWidth = 3.dp)
                        } else {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = "Touch Sensor",
                                tint = if (scanError != null) Color.Red else GoldPrimary,
                                modifier = Modifier.size(48.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (isScanningFinger) "Verifying Biometric Ridge Pattern..." else "Place Registered Finger on Sensor",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 13.sp
                    )

                    if (scanError != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = scanError!!,
                            color = Color(0xFFFF5252),
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "ENROLLED FINGERPRINTS (${enrolledFingerprints.size}/5 registered):",
                        fontSize = 10.sp,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        enrolledFingerprints.forEach { fp ->
                            val isSel = selectedFinger?.id == fp.id
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSel) GoldPrimary.copy(alpha = 0.2f) else ObsidianSurfaceVariant,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, if (isSel) GoldPrimary else ObsidianBorder, RoundedCornerShape(12.dp))
                                    .clickable {
                                        selectedFinger = fp
                                        scanError = null
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(imageVector = Icons.Default.Fingerprint, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = fp.name, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                    if (isSel) {
                                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }

                        // Simulation test button for unauthorized finger
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = ObsidianSurfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedFinger = null
                                    scanError = "❌ Access Denied: Unrecognized finger. Only registered owner fingerprints can open KING AI."
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = Color.Red, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = "Try Unenrolled / Other Finger (Will Reject)", fontSize = 11.sp, color = Color.LightGray)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (selectedFinger == null) {
                                scanError = "❌ Access Denied: Unauthorized fingerprint pattern."
                                return@Button
                            }
                            isScanningFinger = true
                            scanError = null
                            scope.launch {
                                delay(1000)
                                isScanningFinger = false
                                if (securityManager.verifyOwnerWithFingerprint(selectedFinger!!.id)) {
                                    showFingerprintScanDialog = false
                                    statusText = "Fingerprint Matched!"
                                    showOpeningAnimation = true
                                } else {
                                    scanError = "❌ Access Denied: Unrecognized fingerprint pattern."
                                }
                            }
                        },
                        enabled = !isScanningFinger,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Authenticate Fingerprint", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // --- BIOMETRIC FACE SCANNER DIALOG ---
    if (showFaceScanDialog) {
        val enrolledFaces = securityManager.getEnrolledFaceLocks()
        var isScanningFace by remember { mutableStateOf(false) }
        var faceError by remember { mutableStateOf<String?>(null) }
        var selectedFace by remember { mutableStateOf<EnrolledFaceLock?>(enrolledFaces.firstOrNull()) }

        Dialog(onDismissRequest = { showFaceScanDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = ObsidianBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, GoldPrimary, RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier
                        .padding(22.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "KING Facial Recognition Scan",
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary,
                            fontSize = 15.sp
                        )
                        IconButton(onClick = { showFaceScanDialog = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Face Mesh Camera View
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(ObsidianSurfaceVariant)
                            .border(2.dp, if (faceError != null) Color.Red else GoldPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isScanningFace) {
                            CircularProgressIndicator(modifier = Modifier.size(54.dp), color = GoldPrimary, strokeWidth = 3.dp)
                        } else {
                            Icon(
                                imageVector = Icons.Default.Face,
                                contentDescription = "Face Sensor",
                                tint = if (faceError != null) Color.Red else GoldPrimary,
                                modifier = Modifier.size(50.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (isScanningFace) "Mapping 3D Facial Mesh Nodes..." else "Look at the Camera Sensor",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 13.sp
                    )

                    if (faceError != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = faceError!!,
                            color = Color(0xFFFF5252),
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "ENROLLED FACE PROFILES (${enrolledFaces.size}/5 registered):",
                        fontSize = 10.sp,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        enrolledFaces.forEach { face ->
                            val isSel = selectedFace?.id == face.id
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSel) GoldPrimary.copy(alpha = 0.2f) else ObsidianSurfaceVariant,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, if (isSel) GoldPrimary else ObsidianBorder, RoundedCornerShape(12.dp))
                                    .clickable {
                                        selectedFace = face
                                        faceError = null
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(imageVector = Icons.Default.Face, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = face.name, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                    if (isSel) {
                                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }

                        // Simulation test button for unknown face
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = ObsidianSurfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedFace = null
                                    faceError = "❌ Access Denied: Face not recognized. Only enrolled faces can open KING AI."
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = Color.Red, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = "Scan Unknown Person (Will Reject)", fontSize = 11.sp, color = Color.LightGray)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (selectedFace == null) {
                                faceError = "❌ Access Denied: Unrecognized Face."
                                return@Button
                            }
                            isScanningFace = true
                            faceError = null
                            scope.launch {
                                delay(1200)
                                isScanningFace = false
                                if (securityManager.verifyOwnerWithFace(selectedFace!!.id)) {
                                    showFaceScanDialog = false
                                    statusText = "Face Matched: ${selectedFace!!.name}"
                                    showOpeningAnimation = true
                                } else {
                                    faceError = "❌ Access Denied: Unrecognized Face Profile."
                                }
                            }
                        },
                        enabled = !isScanningFace,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Verify Facial Biometrics", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun SecurityModeBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = ObsidianSurfaceVariant,
        modifier = Modifier.border(0.5.dp, GoldPrimary, RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = label, color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun KeypadButton(
    key: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(60.dp)
            .clip(CircleShape)
            .background(ObsidianSurfaceVariant)
            .border(1.dp, ObsidianBorder, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (key == "DEL") {
            Icon(
                imageVector = Icons.Default.Backspace,
                contentDescription = "Delete",
                tint = GoldPrimary,
                modifier = Modifier.size(20.dp)
            )
        } else {
            Text(
                text = key,
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// ---------------------------------------------------------------------
// OPENING MONOGRAM ANIMATION SCREEN
// ---------------------------------------------------------------------
@Composable
fun OpeningMonogramAnimation(
    onAnimationFinished: () -> Unit,
    content: @Composable () -> Unit
) {
    val scaleAnim = remember { Animatable(0.4f) }
    val alphaAnim = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        // Pulse and scale up animation
        scopeLaunchAnimation(scaleAnim, alphaAnim)
        delay(1400)
        onAnimationFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.scale(scaleAnim.value)
        ) {
            // Glowing Monogram Badge
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(ObsidianSurfaceVariant)
                    .border(3.dp, GoldPrimary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "👑",
                    fontSize = 58.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "KING AI",
                fontSize = 36.sp,
                fontWeight = FontWeight.Black,
                color = GoldPrimary,
                letterSpacing = 4.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Premier AI Studio Unlocked",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

private suspend fun scopeLaunchAnimation(
    scaleAnim: Animatable<Float, *>,
    alphaAnim: Animatable<Float, *>
) {
    alphaAnim.animateTo(1f, animationSpec = tween(500))
    scaleAnim.animateTo(
        targetValue = 1.15f,
        animationSpec = tween(700, easing = FastOutSlowInEasing)
    )
    scaleAnim.animateTo(
        targetValue = 1.0f,
        animationSpec = tween(300, easing = FastOutSlowInEasing)
    )
}
