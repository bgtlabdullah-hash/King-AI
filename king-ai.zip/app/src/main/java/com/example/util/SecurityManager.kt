package com.example.util

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class EnrolledFingerprint(
    val id: String,
    val name: String,
    val enrolledAt: Long = System.currentTimeMillis(),
    val biometricSecret: String = "FINGER_VERIFIED_${id}"
)

data class EnrolledFaceLock(
    val id: String,
    val name: String,
    val enrolledAt: Long = System.currentTimeMillis(),
    val faceSecret: String = "FACE_VERIFIED_${id}"
)

class SecurityManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("king_ai_security_prefs", Context.MODE_PRIVATE)

    var isPinLockEnabled: Boolean
        get() = prefs.getBoolean("pin_lock_enabled", false)
        set(value) = prefs.edit().putBoolean("pin_lock_enabled", value).apply()

    var pinCode: String
        get() = prefs.getString("pin_code", "1234") ?: "1234"
        set(value) = prefs.edit().putString("pin_code", value).apply()

    var isFingerprintEnabled: Boolean
        get() = prefs.getBoolean("fingerprint_enabled", false)
        set(value) = prefs.edit().putBoolean("fingerprint_enabled", value).apply()

    var isFaceLockEnabled: Boolean
        get() = prefs.getBoolean("face_lock_enabled", false)
        set(value) = prefs.edit().putBoolean("face_lock_enabled", value).apply()

    fun isSecurityActive(): Boolean {
        return isPinLockEnabled || isFingerprintEnabled || isFaceLockEnabled
    }

    fun verifyPin(inputPin: String): Boolean {
        return inputPin == pinCode
    }

    // --- FINGERPRINT ENROLLMENT (MAX 5) ---
    fun getEnrolledFingerprints(): List<EnrolledFingerprint> {
        val raw = prefs.getString("enrolled_fingerprints_json", null)
        if (raw.isNullOrBlank()) {
            // Default 1 enrolled fingerprint if enabled previously
            return if (isFingerprintEnabled) {
                listOf(EnrolledFingerprint("fp_1", "Owner Primary Thumb (Abdullah)"))
            } else {
                emptyList()
            }
        }
        val list = mutableListOf<EnrolledFingerprint>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    EnrolledFingerprint(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        enrolledAt = obj.optLong("enrolledAt", System.currentTimeMillis()),
                        biometricSecret = obj.optString("biometricSecret", "FINGER_${obj.getString("id")}")
                    )
                )
            }
        } catch (e: Exception) {
            // fallback
        }
        return list
    }

    fun saveEnrolledFingerprints(list: List<EnrolledFingerprint>) {
        val arr = JSONArray()
        list.take(5).forEach { fp ->
            val obj = JSONObject()
            obj.put("id", fp.id)
            obj.put("name", fp.name)
            obj.put("enrolledAt", fp.enrolledAt)
            obj.put("biometricSecret", fp.biometricSecret)
            arr.put(obj)
        }
        prefs.edit().putString("enrolled_fingerprints_json", arr.toString()).apply()
        if (list.isEmpty()) {
            isFingerprintEnabled = false
        }
    }

    fun addFingerprint(name: String): Boolean {
        val current = getEnrolledFingerprints().toMutableList()
        if (current.size >= 5) return false
        val newId = "fp_${System.currentTimeMillis()}"
        val finalName = if (name.isBlank()) "Fingerprint #${current.size + 1}" else name
        current.add(EnrolledFingerprint(newId, finalName))
        saveEnrolledFingerprints(current)
        isFingerprintEnabled = true
        return true
    }

    fun removeFingerprint(id: String) {
        val current = getEnrolledFingerprints().filter { it.id != id }
        saveEnrolledFingerprints(current)
    }

    // --- FACE LOCK ENROLLMENT (MAX 5) ---
    fun getEnrolledFaceLocks(): List<EnrolledFaceLock> {
        val raw = prefs.getString("enrolled_facelocks_json", null)
        if (raw.isNullOrBlank()) {
            return if (isFaceLockEnabled) {
                listOf(EnrolledFaceLock("face_1", "Owner Primary Face (Abdullah)"))
            } else {
                emptyList()
            }
        }
        val list = mutableListOf<EnrolledFaceLock>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    EnrolledFaceLock(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        enrolledAt = obj.optLong("enrolledAt", System.currentTimeMillis()),
                        faceSecret = obj.optString("faceSecret", "FACE_${obj.getString("id")}")
                    )
                )
            }
        } catch (e: Exception) {
            // fallback
        }
        return list
    }

    fun saveEnrolledFaceLocks(list: List<EnrolledFaceLock>) {
        val arr = JSONArray()
        list.take(5).forEach { face ->
            val obj = JSONObject()
            obj.put("id", face.id)
            obj.put("name", face.name)
            obj.put("enrolledAt", face.enrolledAt)
            obj.put("faceSecret", face.faceSecret)
            arr.put(obj)
        }
        prefs.edit().putString("enrolled_facelocks_json", arr.toString()).apply()
        if (list.isEmpty()) {
            isFaceLockEnabled = false
        }
    }

    fun addFaceLock(name: String): Boolean {
        val current = getEnrolledFaceLocks().toMutableList()
        if (current.size >= 5) return false
        val newId = "face_${System.currentTimeMillis()}"
        val finalName = if (name.isBlank()) "Face Profile #${current.size + 1}" else name
        current.add(EnrolledFaceLock(newId, finalName))
        saveEnrolledFaceLocks(current)
        isFaceLockEnabled = true
        return true
    }

    fun removeFaceLock(id: String) {
        val current = getEnrolledFaceLocks().filter { it.id != id }
        saveEnrolledFaceLocks(current)
    }

    // Owner Verification check
    fun verifyOwnerWithFingerprint(enrolledId: String): Boolean {
        val list = getEnrolledFingerprints()
        return list.any { it.id == enrolledId }
    }

    fun verifyOwnerWithFace(enrolledId: String): Boolean {
        val list = getEnrolledFaceLocks()
        return list.any { it.id == enrolledId }
    }
}

