package com.example.ui.screens

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.FormatShapes
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.local.KingAiDatabase
import com.example.data.repository.KingAiRepository
import com.example.ui.components.MonogramCrownStyle
import com.example.ui.components.MonogramFiligreeStyle
import com.example.ui.components.MonogramMaterial
import com.example.ui.components.MonogramWingStyle
import com.example.ui.components.drawRoyalMonogramEmblem
import com.example.ui.components.renderMonogramBitmap
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonogramMakerScreen(
    onBackToChat: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repository = remember {
        val db = KingAiDatabase.getDatabase(context)
        KingAiRepository(db.chatDao(), db.imageCreatorDao(), db.videoCreatorDao())
    }

    // Monogram Design States
    var initials by remember { mutableStateOf("AI") }
    var mainTitle by remember { mutableStateOf("King AI") }
    var subTitle by remember { mutableStateOf("HIGH CLASS") }
    var selectedMaterial by remember { mutableStateOf(MonogramMaterial.GOLD_24K) }
    var selectedWingStyle by remember { mutableStateOf(MonogramWingStyle.ROYALE_WINGS) }
    var selectedCrownStyle by remember { mutableStateOf(MonogramCrownStyle.FLEUR_DE_LIS) }
    var selectedFiligreeStyle by remember { mutableStateOf(MonogramFiligreeStyle.BAROQUE_SCROLL) }
    var selectedBackground by remember { mutableStateOf(0) } // 0: Obsidian Dark, 1: Royal Amethyst, 2: Deep Navy, 3: Pure White

    var selectedTab by remember { mutableIntStateOf(0) }
    var isSaving by remember { mutableStateOf(false) }
    var isGeneratingAi3D by remember { mutableStateOf(false) }

    val bgColors = listOf(
        Color(0xFF0F0B18) to "Obsidian Midnight",
        Color(0xFF22133D) to "Royal Amethyst",
        Color(0xFF0B192C) to "Deep Sapphire",
        Color(0xFFFFFFFF) to "Pure White Studio"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "monogram_shimmer")
    val shimmerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer"
    )

    fun getExportBitmap(): Bitmap {
        val bgColor = bgColors[selectedBackground].first
        return renderMonogramBitmap(
            width = 1080,
            height = 1080,
            initials = initials.ifBlank { "AI" },
            mainTitle = mainTitle,
            subTitle = subTitle,
            material = selectedMaterial,
            wingStyle = selectedWingStyle,
            crownStyle = selectedCrownStyle,
            filigreeStyle = selectedFiligreeStyle,
            backgroundColor = bgColor
        )
    }

    fun saveToGallery() {
        isSaving = true
        scope.launch(Dispatchers.IO) {
            val bitmap = getExportBitmap()
            val filename = "KING_AI_Monogram_${System.currentTimeMillis()}.png"
            var success = false

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                        put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/KingAI")
                    }
                    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                    uri?.let {
                        val outputStream: OutputStream? = context.contentResolver.openOutputStream(it)
                        outputStream?.use { stream ->
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                            success = true
                        }
                    }
                } else {
                    val imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString() + "/KingAI"
                    val file = File(imagesDir)
                    if (!file.exists()) file.mkdirs()
                    val imageFile = File(file, filename)
                    val outputStream = FileOutputStream(imageFile)
                    outputStream.use { stream ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                        success = true
                    }
                }
            } catch (e: Exception) {
                success = false
            } finally {
                bitmap.recycle()
            }

            withContext(Dispatchers.Main) {
                isSaving = false
                if (success) {
                    Toast.makeText(context, "👑 Monogram saved to device Gallery!", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, "Saved to device cache.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun saveToInAppFolder() {
        isSaving = true
        scope.launch(Dispatchers.IO) {
            val bitmap = getExportBitmap()
            val baos = ByteArrayOutputStream()
            try {
                bitmap.compress(Bitmap.CompressFormat.PNG, 95, baos)
                val base64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                val dataUri = "data:image/png;base64,$base64"

                repository.saveCustomGeneratedImage(
                    prompt = "Royal Crest Monogram [$initials] • $mainTitle ($subTitle)",
                    stylePreset = "Royale Monogram Studio (${selectedMaterial.title})",
                    aspectRatio = "1:1",
                    imageDataBase64OrUrl = dataUri
                )

                withContext(Dispatchers.Main) {
                    isSaving = false
                    Toast.makeText(context, "👑 Saved to Images & Videos Folder!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    isSaving = false
                    Toast.makeText(context, "Error saving: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            } finally {
                bitmap.recycle()
                baos.close()
            }
        }
    }

    fun shareMonogram() {
        scope.launch(Dispatchers.IO) {
            val bitmap = getExportBitmap()
            try {
                val cachePath = File(context.cacheDir, "images")
                cachePath.mkdirs()
                val file = File(cachePath, "shared_king_monogram.png")
                val stream = FileOutputStream(file)
                stream.use { s ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, s)
                }

                val contentUri: Uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )

                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, contentUri)
                    putExtra(Intent.EXTRA_TEXT, "👑 Royal Monogram crafted with KING AI Studio • $mainTitle ($subTitle)")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }

                withContext(Dispatchers.Main) {
                    context.startActivity(Intent.createChooser(intent, "Share Royal Monogram"))
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Share error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            } finally {
                bitmap.recycle()
            }
        }
    }

    fun generateAi3DMonogram() {
        isGeneratingAi3D = true
        scope.launch {
            val prompt = "Ultra luxurious 3D gold embossed royal emblem monogram with initials '$initials', flanked by ornate majestic golden wings, perched on top by a French fleur-de-lis royal diamond crown, exquisite baroque filigree below with text '$mainTitle' and '$subTitle', 8k resolution, cinematic lighting, black velvet background, photorealistic octane render."
            val res = repository.generateImage(
                prompt = prompt,
                stylePreset = "Royale 3D Gold",
                aspectRatio = "1:1",
                imageSize = "1K"
            )
            isGeneratingAi3D = false
            res.onSuccess {
                Toast.makeText(context, "👑 3D AI Monogram Rendered & Saved to Folder!", Toast.LENGTH_LONG).show()
            }.onFailure { err ->
                Toast.makeText(context, "AI Generation: ${err.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Monogram Maker",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Royale Crest & Luxury Monogram Studio",
                            style = MaterialTheme.typography.labelSmall,
                            color = GoldPrimary,
                            fontSize = 11.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackToChat) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                actions = {
                    IconButton(onClick = {
                        // Reset to exact reference image values
                        initials = "AI"
                        mainTitle = "King AI"
                        subTitle = "HIGH CLASS"
                        selectedMaterial = MonogramMaterial.GOLD_24K
                        selectedWingStyle = MonogramWingStyle.ROYALE_WINGS
                        selectedCrownStyle = MonogramCrownStyle.FLEUR_DE_LIS
                        selectedFiligreeStyle = MonogramFiligreeStyle.BAROQUE_SCROLL
                        selectedBackground = 0
                        Toast.makeText(context, "Reset to Royale Reference Preset", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(Icons.Default.RestartAlt, contentDescription = "Reset", tint = GoldPrimary)
                    }
                    IconButton(onClick = { shareMonogram() }) {
                        Icon(Icons.Default.Share, contentDescription = "Share", tint = GoldPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ObsidianBackground
                )
            )
        },
        containerColor = ObsidianBackground
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            // 1. LIVE INTERACTIVE MONOGRAM CANVAS CARD
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .shadow(12.dp, RoundedCornerShape(24.dp)),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = bgColors[selectedBackground].first
                ),
                border = androidx.compose.foundation.BorderStroke(
                    width = 1.5.dp,
                    color = GoldPrimary.copy(alpha = 0.4f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Canvas View
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(290.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawRoyalMonogramEmblem(
                                initials = initials.ifBlank { "AI" },
                                mainTitle = mainTitle,
                                subTitle = subTitle,
                                material = selectedMaterial,
                                wingStyle = selectedWingStyle,
                                crownStyle = selectedCrownStyle,
                                filigreeStyle = selectedFiligreeStyle,
                                glowAlpha = 0.9f,
                                shimmerProgress = shimmerRotation,
                                isDarkMode = selectedBackground != 3
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Action Buttons Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { saveToGallery() },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = GoldPrimary,
                                contentColor = Color.Black
                            )
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Download", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = { saveToInAppFolder() },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = GoldPrimary
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
                        ) {
                            Icon(Icons.Default.FolderSpecial, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Save to Folder", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // AI 3D Render Button
                    Button(
                        onClick = { generateAi3DMonogram() },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        enabled = !isGeneratingAi3D,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ObsidianSurfaceVariant,
                            contentColor = GoldPrimary
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.5f))
                    ) {
                        if (isGeneratingAi3D) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = GoldPrimary, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Rendering 3D Monogram...", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp), tint = GoldPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("AI Render 3D Gold Monogram (Imagen 3)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }

            // 2. STUDIO CONFIGURATION TABS
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = ObsidianBackground,
                contentColor = GoldPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = GoldPrimary,
                        height = 3.dp
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Text & Brand", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.FormatShapes, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Wings & Crown", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.MilitaryTech, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Metal & Canvas", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.ColorLens, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // TAB 0: TEXT & BRANDING
            if (selectedTab == 0) {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    Text(
                        text = "CENTER MONOGRAM INITIALS",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = initials,
                        onValueChange = { if (it.length <= 4) initials = it },
                        placeholder = { Text("AI / K / AW (1-3 Letters)", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = ObsidianBorder,
                            focusedContainerColor = ObsidianSurfaceVariant,
                            unfocusedContainerColor = ObsidianSurfaceVariant,
                            focusedTextColor = MaterialTheme.colorScheme.onSurface
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "MAIN TITLE (BELOW MONOGRAM)",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = mainTitle,
                        onValueChange = { mainTitle = it },
                        placeholder = { Text("e.g. King AI", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = ObsidianBorder,
                            focusedContainerColor = ObsidianSurfaceVariant,
                            unfocusedContainerColor = ObsidianSurfaceVariant,
                            focusedTextColor = MaterialTheme.colorScheme.onSurface
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "SUBTITLE / SLOGAN",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = subTitle,
                        onValueChange = { subTitle = it },
                        placeholder = { Text("e.g. HIGH CLASS / EST. 2026", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = ObsidianBorder,
                            focusedContainerColor = ObsidianSurfaceVariant,
                            unfocusedContainerColor = ObsidianSurfaceVariant,
                            focusedTextColor = MaterialTheme.colorScheme.onSurface
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Preset Quick Initial Badges
                    Text(
                        text = "QUICK INITIAL TEMPLATES",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("AI", "K", "KA", "AW", "👑", "VIP", "777").forEach { preset ->
                            FilterChip(
                                selected = initials == preset,
                                onClick = { initials = preset },
                                label = { Text(preset, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GoldPrimary,
                                    selectedLabelColor = Color.Black,
                                    containerColor = ObsidianSurfaceVariant,
                                    labelColor = MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }
                }
            }

            // TAB 1: WINGS, CROWN & FLOURISH
            if (selectedTab == 1) {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    Text(
                        text = "WINGS & CREST DESIGN",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        MonogramWingStyle.entries.forEach { wing ->
                            val isSel = selectedWingStyle == wing
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedWingStyle = wing },
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSel) GoldPrimary.copy(alpha = 0.15f) else ObsidianSurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    width = 1.dp,
                                    color = if (isSel) GoldPrimary else ObsidianBorder
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (isSel) Icons.Default.Check else Icons.Default.MilitaryTech,
                                        contentDescription = null,
                                        tint = if (isSel) GoldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = wing.title,
                                        fontSize = 13.sp,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSel) GoldPrimary else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "CROWN & TOP EMBLEM",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MonogramCrownStyle.entries.forEach { crown ->
                            val isSel = selectedCrownStyle == crown
                            FilterChip(
                                selected = isSel,
                                onClick = { selectedCrownStyle = crown },
                                label = { Text(crown.title, fontSize = 11.5.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GoldPrimary,
                                    selectedLabelColor = Color.Black,
                                    containerColor = ObsidianSurfaceVariant,
                                    labelColor = MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "BASE BAROQUE FILIGREE",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MonogramFiligreeStyle.entries.forEach { filigree ->
                            val isSel = selectedFiligreeStyle == filigree
                            FilterChip(
                                selected = isSel,
                                onClick = { selectedFiligreeStyle = filigree },
                                label = { Text(filigree.title, fontSize = 11.5.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GoldPrimary,
                                    selectedLabelColor = Color.Black,
                                    containerColor = ObsidianSurfaceVariant,
                                    labelColor = MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }
                }
            }

            // TAB 2: METAL & CANVAS
            if (selectedTab == 2) {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    Text(
                        text = "METALLIC FINISH & MATERIALS",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        MonogramMaterial.entries.forEach { material ->
                            val isSel = selectedMaterial == material
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedMaterial = material },
                                shape = RoundedCornerShape(14.dp),
                                color = ObsidianSurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isSel) 2.dp else 1.dp,
                                    color = if (isSel) material.primaryColor else ObsidianBorder
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Material Color Preview Dot
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .background(
                                                brush = Brush.linearGradient(material.gradientColors),
                                                shape = CircleShape
                                            )
                                            .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = material.title,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSel) material.primaryColor else MaterialTheme.colorScheme.onSurface,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.weight(1f))
                                    if (isSel) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = material.primaryColor)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Text(
                        text = "BACKGROUND CANVAS PREVIEW",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        bgColors.forEachIndexed { index, (color, title) ->
                            val isSel = selectedBackground == index
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .clickable { selectedBackground = index },
                                shape = RoundedCornerShape(12.dp),
                                color = color,
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isSel) 2.dp else 1.dp,
                                    color = if (isSel) GoldPrimary else ObsidianBorder
                                )
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    if (isSel) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = if (index == 3) Color.Black else GoldPrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(36.dp))
        }
    }
}
