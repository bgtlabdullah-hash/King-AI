package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant

@Composable
fun KingInAppKeyboard(
    isVisible: Boolean,
    textInput: String,
    onTextChanged: (String) -> Unit,
    onSendPrompt: () -> Unit,
    onCloseKeyboard: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isUrduMode by remember { mutableStateOf(true) }

    val urduRows = listOf(
        listOf("ا", "ب", "پ", "ت", "ٹ", "ث", "ج", "چ", "ح", "خ"),
        listOf("د", "ڈ", "ذ", "ر", "ڑ", "ز", "ژ", "س", "ش", "ص"),
        listOf("ض", "ط", "ظ", "ع", "غ", "ف", "ق", "ک", "گ", "ل"),
        listOf("م", "ن", "و", "ہ", "ء", "ی", "ے", "؟", "!", "۔")
    )

    val englishRows = listOf(
        listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"),
        listOf("A", "S", "D", "F", "G", "H", "J", "K", "L"),
        listOf("Z", "X", "C", "V", "B", "N", "M", "?", "!", ".")
    )

    AnimatedVisibility(
        visible = isVisible,
        enter = expandVertically(),
        exit = shrinkVertically()
    ) {
        Surface(
            color = ObsidianSurfaceVariant,
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
            modifier = modifier
                .fillMaxWidth()
                .border(1.dp, GoldPrimary.copy(alpha = 0.5f), RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
        ) {
            Column(
                modifier = Modifier
                    .padding(10.dp)
                    .fillMaxWidth()
            ) {
                // Keyboard Header Control Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Keyboard, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isUrduMode) "KING Urdu Keyboard (اردو)" else "KING English Keyboard",
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary,
                            fontSize = 13.sp
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Language Switch Button
                        Button(
                            onClick = { isUrduMode = !isUrduMode },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Language, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isUrduMode) "Switch to English" else "Switch to اردو", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        IconButton(onClick = onCloseKeyboard, modifier = Modifier.size(32.dp)) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close Keyboard", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Key Rows
                val currentRows = if (isUrduMode) urduRows else englishRows
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    currentRows.forEach { row ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            row.forEach { char ->
                                KeyItem(
                                    label = char,
                                    modifier = Modifier.weight(1f),
                                    onClick = { onTextChanged(textInput + char) }
                                )
                            }
                        }
                    }

                    // Special Action Row: Space, Backspace, Clear, Send
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Clear Key
                        KeyItem(
                            label = "Clear",
                            modifier = Modifier.width(60.dp),
                            bgColor = ObsidianBackground,
                            onClick = { onTextChanged("") }
                        )

                        // Space Key
                        KeyItem(
                            label = if (isUrduMode) "فاصلہ (Space)" else "Space",
                            modifier = Modifier.weight(1f),
                            bgColor = ObsidianBackground,
                            onClick = { onTextChanged("$textInput ") }
                        )

                        // Backspace Key
                        Box(
                            modifier = Modifier
                                .width(50.dp)
                                .height(40.dp)
                                .background(ObsidianBackground, RoundedCornerShape(8.dp))
                                .border(0.5.dp, ObsidianBorder, RoundedCornerShape(8.dp))
                                .clickable {
                                    if (textInput.isNotEmpty()) {
                                        onTextChanged(textInput.dropLast(1))
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Backspace, contentDescription = "Backspace", tint = GoldPrimary, modifier = Modifier.size(18.dp))
                        }

                        // Send Key
                        Box(
                            modifier = Modifier
                                .width(50.dp)
                                .height(40.dp)
                                .background(GoldPrimary, RoundedCornerShape(8.dp))
                                .clickable { onSendPrompt() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Send, contentDescription = "Send", tint = Color.Black, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun KeyItem(
    label: String,
    modifier: Modifier = Modifier,
    bgColor: Color = ObsidianBackground,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(40.dp)
            .background(bgColor, RoundedCornerShape(8.dp))
            .border(0.5.dp, ObsidianBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = GoldPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
