package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoCreatorDao {
    @Query("SELECT * FROM generated_videos ORDER BY timestamp DESC")
    fun getAllGeneratedVideos(): Flow<List<GeneratedVideoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGeneratedVideo(video: GeneratedVideoEntity): Long

    @Query("DELETE FROM generated_videos WHERE id = :id")
    suspend fun deleteVideoById(id: Long)
}
