package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Environment
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CameraRoll
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import com.example.data.local.GeneratedImageEntity
import com.example.data.local.GeneratedVideoEntity
import com.example.data.local.KingAiDatabase
import com.example.data.repository.KingAiRepository
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.util.AppEditionManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

// Camera Trajectory Directives for Cinematic Video Generation
data class KingCameraMotionPreset(
    val id: String,
    val name: String,
    val description: String,
    val icon: ImageVector,
    val pitchAngle: Float,
    val yawAngle: Float
)

val KingCameraMotions = listOf(
    KingCameraMotionPreset("orbit", "Orbit 360°", "Seamless rotational pan circling the focal subject", Icons.Default.ViewInAr, 15f, 45f),
    KingCameraMotionPreset("zoom_in", "Cinematic Push-In", "Steadicam push advancing inward with shallow depth", Icons.Default.CameraAlt, 0f, 0f),
    KingCameraMotionPreset("zoom_out", "Expansive Reveal", "Wide camera pull-back unveiling grand environment", Icons.Default.CameraRoll, -10f, 0f),
    KingCameraMotionPreset("pan_right", "Lateral Tracking", "Smooth horizontal dolly glide following subject", Icons.Default.FastForward, 0f, 30f),
    KingCameraMotionPreset("crane_up", "Skyward Crane", "Dramatic vertical ascension toward celestial heights", Icons.Default.Videocam, -25f, 0f),
    KingCameraMotionPreset("drone", "Drone Flythrough", "High-velocity aerial trajectory with motion blur", Icons.Default.Speed, 20f, -15f),
    KingCameraMotionPreset("static", "Static Masterpiece", "Tripod lock-off with atmospheric particle drift", Icons.Default.Movie, 0f, 0f)
)

val KingCinemaMagicPrompts = listOf(
    "Cinematic 4K drone flythrough above a majestic golden palace floating among iridescent clouds, golden hour volumetric godrays, 35mm anamorphic lens, raytraced water reflections",
    "Slow-motion cinematic tracking shot of a matte-black hypercar accelerating on a rain-slicked cyberpunk boulevard, neon reflections, anamorphic lens bokeh, photorealistic 60fps",
    "Macro cinema shot of an ornate mechanical golden hummingbird sipping holographic nectar from a crystal flower, fluid physics, 8k resolution, photorealism",
    "Wide-angle 35mm film still of an explorer standing before towering crystalline ruins on Mars during double sunset, atmospheric dust particles, epic scale",
    "Majestic royal white lion adorned with 24K gold filigree armor standing on a snow-capped summit, wind blowing mane, volumetric atmospheric lighting"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KingCinemaStudioScreen(
    onBackToChat: () -> Unit,
    onNavigateToMediaFolder: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val editionManager = remember { AppEditionManager(context) }

    val repository = remember {
        val db = KingAiDatabase.getDatabase(context)
        KingAiRepository(db.chatDao(), db.imageCreatorDao(), db.videoCreatorDao())
    }

    val videos by repository.allGeneratedVideos.collectAsState(initial = emptyList())
    val images by repository.allGeneratedImages.collectAsState(initial = emptyList())

    var selectedStudioMode by remember { mutableIntStateOf(0) } // 0: Video Motion, 1: Photon Image, 2: Keyframe Animator, 3: Vault
    val studioModes = listOf("🎬 Motion Dream", "🎨 Photon 4K", "📸 Keyframe Animate", "📁 Cinema Vault")

    // Studio Form State
    var promptInput by remember { mutableStateOf("") }
    var selectedMotion by remember { mutableStateOf(KingCameraMotions[0]) }
    var motionSpeed by remember { mutableFloatStateOf(1.5f) } // 1.0x to 3.0x
    var selectedAspectRatio by remember { mutableStateOf("16:9") } // 16:9, 9:16, 1:1, 21:9
    var selectedDuration by remember { mutableIntStateOf(5) } // 5s or 10s
    var selectedStylePreset by remember { mutableStateOf("Cinematic Photorealism") }
    var selectedResolution by remember { mutableStateOf("4K Cinema") }

    // Keyframe source image
    var sourceImageBase64 by remember { mutableStateOf<String?>(null) }

    // Generation States
    var isGenerating by remember { mutableStateOf(false) }
    var generationProgressText by remember { mutableStateOf("") }
    var activeGeneratedVideo by remember { mutableStateOf<GeneratedVideoEntity?>(null) }
    var activeGeneratedImage by remember { mutableStateOf<GeneratedImageEntity?>(null) }

    // Vault Detail Dialog
    var selectedVideoForModal by remember { mutableStateOf<GeneratedVideoEntity?>(null) }
    var selectedImageForModal by remember { mutableStateOf<GeneratedImageEntity?>(null) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val input = context.contentResolver.openInputStream(uri)
                val bytes = input?.readBytes()
                input?.close()
                if (bytes != null) {
                    val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    sourceImageBase64 = "data:image/jpeg;base64,$base64"
                    Toast.makeText(context, "Keyframe Image Loaded for Living Animation!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Error loading image: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(GoldPrimary, Color(0xFFFF8C00))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "KING CINEMA STUDIO",
                                    fontWeight = FontWeight.Black,
                                    color = GoldPrimary,
                                    fontSize = 16.sp,
                                    letterSpacing = 0.8.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = GoldPrimary.copy(alpha = 0.2f),
                                    border = BorderStroke(0.5.dp, GoldPrimary)
                                ) {
                                    Text(
                                        text = "ULTRA 4K",
                                        color = GoldPrimary,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Motion Dream Machine & Photon 4K Engine",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 10.5.sp
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackToChat) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = GoldPrimary
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToMediaFolder) {
                        Icon(
                            imageVector = Icons.Default.FolderSpecial,
                            contentDescription = "Media Vault",
                            tint = GoldPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ObsidianBackground
                )
            )
        },
        containerColor = ObsidianBackground
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Mode Switcher Tabs
            TabRow(
                selectedTabIndex = selectedStudioMode,
                containerColor = ObsidianSurfaceVariant,
                contentColor = GoldPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedStudioMode]),
                        color = GoldPrimary,
                        height = 3.dp
                    )
                }
            ) {
                studioModes.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedStudioMode == index,
                        onClick = { selectedStudioMode = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 11.5.sp,
                                fontWeight = if (selectedStudioMode == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedStudioMode == index) GoldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    )
                }
            }

            // Body Content
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            ) {
                when (selectedStudioMode) {
                    0 -> KingDreamMotionTab(
                        prompt = promptInput,
                        onPromptChange = { promptInput = it },
                        selectedMotion = selectedMotion,
                        onSelectMotion = { selectedMotion = it },
                        motionSpeed = motionSpeed,
                        onSpeedChange = { motionSpeed = it },
                        aspectRatio = selectedAspectRatio,
                        onAspectRatioChange = { selectedAspectRatio = it },
                        duration = selectedDuration,
                        onDurationChange = { selectedDuration = it },
                        isGenerating = isGenerating,
                        generationProgressText = generationProgressText,
                        activeVideo = activeGeneratedVideo,
                        onGenerateVideo = {
                            if (promptInput.isBlank()) return@KingDreamMotionTab
                            isGenerating = true
                            generationProgressText = "Synthesizing cinematic 4K neural diffusion..."
                            scope.launch {
                                delay(500)
                                generationProgressText = "Directing ${selectedMotion.name} trajectory (${motionSpeed}x speed)..."
                                delay(600)
                                generationProgressText = "Rendering 60 FPS motion vectors and physics..."
                                
                                val res = repository.generateVideoWithVeo3(
                                    prompt = promptInput,
                                    aspectRatio = selectedAspectRatio,
                                    consistencyStyle = "King Cinema Ultra (${selectedMotion.name})",
                                    motionConsistency = "${selectedMotion.name} • ${motionSpeed}x Dynamics",
                                    durationSeconds = selectedDuration
                                )
                                isGenerating = false
                                res.onSuccess { entity ->
                                    activeGeneratedVideo = entity
                                    Toast.makeText(context, "🎬 Cinema Video Render Complete!", Toast.LENGTH_SHORT).show()
                                }.onFailure { err ->
                                    Toast.makeText(context, "Notice: ${err.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        onMagicPrompt = {
                            promptInput = KingCinemaMagicPrompts.random()
                            Toast.makeText(context, "✨ King Cinema Prompt Applied!", Toast.LENGTH_SHORT).show()
                        }
                    )

                    1 -> KingPhotonImageTab(
                        prompt = promptInput,
                        onPromptChange = { promptInput = it },
                        selectedStyle = selectedStylePreset,
                        onSelectStyle = { selectedStylePreset = it },
                        aspectRatio = selectedAspectRatio,
                        onAspectRatioChange = { selectedAspectRatio = it },
                        resolution = selectedResolution,
                        onResolutionChange = { selectedResolution = it },
                        isGenerating = isGenerating,
                        activeImage = activeGeneratedImage,
                        onGenerateImage = {
                            if (promptInput.isBlank()) return@KingPhotonImageTab
                            isGenerating = true
                            scope.launch {
                                val res = repository.generateImage(
                                    prompt = "$promptInput, 8k resolution, ultra photorealism, raytraced lighting, volumetric depth, masterpiece",
                                    stylePreset = selectedStylePreset,
                                    aspectRatio = selectedAspectRatio,
                                    imageSize = selectedResolution
                                )
                                isGenerating = false
                                res.onSuccess { entity ->
                                    activeGeneratedImage = entity
                                    Toast.makeText(context, "🎨 King Photon 4K Render Created!", Toast.LENGTH_SHORT).show()
                                }.onFailure { err ->
                                    Toast.makeText(context, "Notice: ${err.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        onMagicPrompt = {
                            promptInput = KingCinemaMagicPrompts.random()
                            Toast.makeText(context, "✨ King Photon Prompt Applied!", Toast.LENGTH_SHORT).show()
                        }
                    )

                    2 -> KingKeyframeAnimatorTab(
                        sourceImageBase64 = sourceImageBase64,
                        onPickImage = { imagePickerLauncher.launch("image/*") },
                        prompt = promptInput,
                        onPromptChange = { promptInput = it },
                        selectedMotion = selectedMotion,
                        onSelectMotion = { selectedMotion = it },
                        motionSpeed = motionSpeed,
                        onSpeedChange = { motionSpeed = it },
                        isGenerating = isGenerating,
                        generationProgressText = generationProgressText,
                        activeVideo = activeGeneratedVideo,
                        onAnimateImage = {
                            isGenerating = true
                            generationProgressText = "Analyzing keyframe visual topology..."
                            scope.launch {
                                delay(500)
                                generationProgressText = "Interpolating ${selectedMotion.name} spatial physics..."
                                val motionPrompt = if (promptInput.isNotBlank()) promptInput else "Animate keyframe with fluid physics and cinematic camera trajectory"
                                val res = repository.generateVideoWithVeo3(
                                    prompt = "$motionPrompt [Motion: ${selectedMotion.name}]",
                                    aspectRatio = "16:9",
                                    consistencyStyle = "Keyframe Spatial Motion",
                                    motionConsistency = "${selectedMotion.name} • ${motionSpeed}x Speed",
                                    durationSeconds = 5
                                )
                                isGenerating = false
                                res.onSuccess { entity ->
                                    activeGeneratedVideo = entity
                                    Toast.makeText(context, "🎬 Keyframe Brought to Life as Living Video!", Toast.LENGTH_SHORT).show()
                                }.onFailure { err ->
                                    Toast.makeText(context, "Notice: ${err.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    )

                    3 -> KingCinemaVaultTab(
                        videos = videos,
                        images = images,
                        onSelectVideo = { selectedVideoForModal = it },
                        onSelectImage = { selectedImageForModal = it }
                    )
                }
            }
        }
    }

    // Modal Fullscreen Preview Dialogs
    if (selectedVideoForModal != null) {
        KingVideoPlayerModal(
            video = selectedVideoForModal!!,
            onDismiss = { selectedVideoForModal = null }
        )
    }

    if (selectedImageForModal != null) {
        KingImagePreviewModal(
            image = selectedImageForModal!!,
            onDismiss = { selectedImageForModal = null }
        )
    }
}

// ---------------------------------------------------------------------
// 1. KING MOTION DREAM (TEXT TO VIDEO) TAB
// ---------------------------------------------------------------------
@Composable
private fun KingDreamMotionTab(
    prompt: String,
    onPromptChange: (String) -> Unit,
    selectedMotion: KingCameraMotionPreset,
    onSelectMotion: (KingCameraMotionPreset) -> Unit,
    motionSpeed: Float,
    onSpeedChange: (Float) -> Unit,
    aspectRatio: String,
    onAspectRatioChange: (String) -> Unit,
    duration: Int,
    onDurationChange: (Int) -> Unit,
    isGenerating: Boolean,
    generationProgressText: String,
    activeVideo: GeneratedVideoEntity?,
    onGenerateVideo: () -> Unit,
    onMagicPrompt: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Active Render Preview (If available)
        if (activeVideo != null) {
            KingInteractiveVideoPlayer(video = activeVideo)
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Prompt Input Card
        Card(
            colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, ObsidianBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CINEMATIC PROMPT",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    OutlinedButton(
                        onClick = onMagicPrompt,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldPrimary),
                        border = BorderStroke(1.dp, GoldPrimary),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("King Enhance", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = prompt,
                    onValueChange = onPromptChange,
                    placeholder = {
                        Text(
                            "Describe the scene, lighting, action, atmosphere (e.g. A cybernetic samurai standing on a neon rooftop during rain storm...)",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = ObsidianBorder,
                        focusedContainerColor = Color(0xFF0C0A14),
                        unfocusedContainerColor = Color(0xFF0C0A14),
                        focusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Camera Motion Director
        Text(
            text = "CAMERA MOTION DIRECTOR",
            style = MaterialTheme.typography.labelSmall,
            color = GoldPrimary,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            KingCameraMotions.forEach { motion ->
                val isSelected = motion.id == selectedMotion.id
                Card(
                    onClick = { onSelectMotion(motion) },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) GoldPrimary.copy(alpha = 0.2f) else ObsidianSurfaceVariant
                    ),
                    border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, if (isSelected) GoldPrimary else ObsidianBorder),
                    modifier = Modifier.width(135.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = motion.icon,
                            contentDescription = null,
                            tint = if (isSelected) GoldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = motion.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            color = if (isSelected) GoldPrimary else MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = motion.description,
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Motion Speed Slider & Duration
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Speed Controller
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, ObsidianBorder),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Motion Dynamics", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(String.format("%.1fx", motionSpeed), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                    }
                    Slider(
                        value = motionSpeed,
                        onValueChange = onSpeedChange,
                        valueRange = 1.0f..3.0f,
                        steps = 3,
                        colors = SliderDefaults.colors(
                            thumbColor = GoldPrimary,
                            activeTrackColor = GoldPrimary,
                            inactiveTrackColor = ObsidianBorder
                        )
                    )
                }
            }

            // Duration
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, ObsidianBorder),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("Duration", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(5, 10).forEach { sec ->
                            val isSel = duration == sec
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) GoldPrimary else Color.Transparent,
                                border = BorderStroke(1.dp, if (isSel) GoldPrimary else ObsidianBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onDurationChange(sec) }
                            ) {
                                Text(
                                    text = "${sec}s HD",
                                    color = if (isSel) Color.Black else MaterialTheme.colorScheme.onSurface,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Aspect Ratios
        Text(
            text = "CINEMA ASPECT RATIO",
            style = MaterialTheme.typography.labelSmall,
            color = GoldPrimary,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("16:9 Cinema", "9:16 Reels", "1:1 Square", "21:9 Anamorphic").forEach { ratioLabel ->
                val code = ratioLabel.substringBefore(" ")
                val isSel = aspectRatio == code
                FilterChip(
                    selected = isSel,
                    onClick = { onAspectRatioChange(code) },
                    label = { Text(ratioLabel, fontSize = 11.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldPrimary,
                        selectedLabelColor = Color.Black,
                        containerColor = ObsidianSurfaceVariant,
                        labelColor = MaterialTheme.colorScheme.onSurface
                    ),
                    border = BorderStroke(1.dp, if (isSel) GoldPrimary else ObsidianBorder)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Generate Button
        Button(
            onClick = onGenerateVideo,
            enabled = !isGenerating && prompt.isNotBlank(),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            if (isGenerating) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.Black, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(generationProgressText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("GENERATE KING CINEMA VIDEO", fontSize = 13.5.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------
// 2. KING PHOTON (TEXT TO IMAGE) TAB
// ---------------------------------------------------------------------
@Composable
private fun KingPhotonImageTab(
    prompt: String,
    onPromptChange: (String) -> Unit,
    selectedStyle: String,
    onSelectStyle: (String) -> Unit,
    aspectRatio: String,
    onAspectRatioChange: (String) -> Unit,
    resolution: String,
    onResolutionChange: (String) -> Unit,
    isGenerating: Boolean,
    activeImage: GeneratedImageEntity?,
    onGenerateImage: () -> Unit,
    onMagicPrompt: () -> Unit
) {
    val photonStyles = listOf(
        "Cinematic Photorealism", "Film 35mm Arri", "Cyberpunk Neon", "Hyper-detailed 3D",
        "Royal 24K Gold", "Anime Masterpiece", "Unreal Engine 5 Concept", "Studio Portrait"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        if (activeImage != null) {
            KingInteractiveImageDisplay(image = activeImage)
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Prompt Input
        Card(
            colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, ObsidianBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PHOTON IMAGE PROMPT",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    OutlinedButton(
                        onClick = onMagicPrompt,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldPrimary),
                        border = BorderStroke(1.dp, GoldPrimary),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("King Enhance", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = prompt,
                    onValueChange = onPromptChange,
                    placeholder = {
                        Text(
                            "Describe character, lighting, textures, scene composition in photorealistic 4K detail...",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = ObsidianBorder,
                        focusedContainerColor = Color(0xFF0C0A14),
                        unfocusedContainerColor = Color(0xFF0C0A14),
                        focusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "PHOTON RENDER STYLES",
            style = MaterialTheme.typography.labelSmall,
            color = GoldPrimary,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            photonStyles.forEach { style ->
                val isSel = style == selectedStyle
                FilterChip(
                    selected = isSel,
                    onClick = { onSelectStyle(style) },
                    label = { Text(style, fontSize = 11.5.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldPrimary,
                        selectedLabelColor = Color.Black,
                        containerColor = ObsidianSurfaceVariant,
                        labelColor = MaterialTheme.colorScheme.onSurface
                    ),
                    border = BorderStroke(1.dp, if (isSel) GoldPrimary else ObsidianBorder)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Aspect & Resolution Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, ObsidianBorder),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("Aspect Ratio", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("1:1", "16:9", "9:16").forEach { ratio ->
                            val isSel = ratio == aspectRatio
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) GoldPrimary else Color.Transparent,
                                border = BorderStroke(1.dp, if (isSel) GoldPrimary else ObsidianBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onAspectRatioChange(ratio) }
                            ) {
                                Text(
                                    text = ratio,
                                    color = if (isSel) Color.Black else MaterialTheme.colorScheme.onSurface,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, ObsidianBorder),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("Quality & Output", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("2K HD", "4K Ultra").forEach { res ->
                            val isSel = res == resolution
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) GoldPrimary else Color.Transparent,
                                border = BorderStroke(1.dp, if (isSel) GoldPrimary else ObsidianBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onResolutionChange(res) }
                            ) {
                                Text(
                                    text = res,
                                    color = if (isSel) Color.Black else MaterialTheme.colorScheme.onSurface,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onGenerateImage,
            enabled = !isGenerating && prompt.isNotBlank(),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            if (isGenerating) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.Black, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Rendering Photon 4K Ultra...", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Image, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("RENDER WITH KING PHOTON 4K", fontSize = 13.5.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------
// 3. KEYFRAME ANIMATOR (IMAGE TO VIDEO) TAB
// ---------------------------------------------------------------------
@Composable
private fun KingKeyframeAnimatorTab(
    sourceImageBase64: String?,
    onPickImage: () -> Unit,
    prompt: String,
    onPromptChange: (String) -> Unit,
    selectedMotion: KingCameraMotionPreset,
    onSelectMotion: (KingCameraMotionPreset) -> Unit,
    motionSpeed: Float,
    onSpeedChange: (Float) -> Unit,
    isGenerating: Boolean,
    generationProgressText: String,
    activeVideo: GeneratedVideoEntity?,
    onAnimateImage: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        if (activeVideo != null) {
            KingInteractiveVideoPlayer(video = activeVideo)
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Keyframe Image Selector Box
        Card(
            colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.5.dp, if (sourceImageBase64 != null) GoldPrimary else ObsidianBorder),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onPickImage() }
        ) {
            if (sourceImageBase64 != null) {
                val bitmap = remember(sourceImageBase64) { decodeKingBase64(sourceImageBase64) }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (bitmap != null) {
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "Keyframe",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Surface(
                        color = Color.Black.copy(alpha = 0.7f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Change Keyframe", color = Color.White, fontSize = 11.sp)
                        }
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(GoldPrimary.copy(alpha = 0.15f))
                            .border(1.dp, GoldPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(28.dp))
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Select Initial Photo / Graphic", fontWeight = FontWeight.Bold, color = GoldPrimary, fontSize = 14.sp)
                    Text("King AI will animate this still into a living cinematic video", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, textAlign = TextAlign.Center)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Motion Controls
        Text(
            text = "CAMERA TRAJECTORY & PARTICLES",
            style = MaterialTheme.typography.labelSmall,
            color = GoldPrimary,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            KingCameraMotions.forEach { motion ->
                val isSelected = motion.id == selectedMotion.id
                FilterChip(
                    selected = isSelected,
                    onClick = { onSelectMotion(motion) },
                    leadingIcon = { Icon(imageVector = motion.icon, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text(motion.name, fontSize = 11.5.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldPrimary,
                        selectedLabelColor = Color.Black,
                        selectedLeadingIconColor = Color.Black,
                        containerColor = ObsidianSurfaceVariant,
                        labelColor = MaterialTheme.colorScheme.onSurface
                    ),
                    border = BorderStroke(1.dp, if (isSelected) GoldPrimary else ObsidianBorder)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Optional Motion Prompt
        OutlinedTextField(
            value = prompt,
            onValueChange = onPromptChange,
            placeholder = { Text("Optional: Guide the motion (e.g. hair flowing in wind, water flowing, camera drifting slowly...)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = ObsidianBorder,
                focusedContainerColor = ObsidianSurfaceVariant,
                unfocusedContainerColor = ObsidianSurfaceVariant,
                focusedTextColor = MaterialTheme.colorScheme.onSurface
            )
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onAnimateImage,
            enabled = !isGenerating && sourceImageBase64 != null,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            if (isGenerating) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.Black, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(generationProgressText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ANIMATE KEYFRAME WITH KING CINEMA", fontSize = 13.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------
// 4. KING CINEMA VAULT
// ---------------------------------------------------------------------
@Composable
private fun KingCinemaVaultTab(
    videos: List<GeneratedVideoEntity>,
    images: List<GeneratedImageEntity>,
    onSelectVideo: (GeneratedVideoEntity) -> Unit,
    onSelectImage: (GeneratedImageEntity) -> Unit
) {
    if (videos.isEmpty() && images.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(imageVector = Icons.Default.Movie, contentDescription = null, tint = GoldPrimary.copy(alpha = 0.5f), modifier = Modifier.size(48.dp))
                Spacer(modifier = Modifier.height(10.dp))
                Text("No Cinema Creations Yet", fontWeight = FontWeight.Bold, color = GoldPrimary, fontSize = 15.sp)
                Text("Create your first video with Motion Dream or image with Photon 4K", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            }
        }
    } else {
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(videos) { video ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectVideo(video) }
                ) {
                    Column {
                        val bitmap = remember(video.videoDataOrUrl) { decodeKingBase64(video.videoDataOrUrl) }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1.33f)
                                .background(Color(0xFF0E0A1A)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (bitmap != null) {
                                Image(
                                    bitmap = bitmap.asImageBitmap(),
                                    contentDescription = video.prompt,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Play",
                                tint = GoldPrimary,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.6f))
                                    .padding(4.dp)
                            )
                        }
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(
                                text = video.prompt,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = video.motionConsistency,
                                fontSize = 9.5.sp,
                                color = GoldPrimary,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            items(images) { image ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectImage(image) }
                ) {
                    Column {
                        val bitmap = remember(image.imageDataBase64OrUrl) { decodeKingBase64(image.imageDataBase64OrUrl) }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f)
                                .background(Color(0xFF100D1E)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (bitmap != null) {
                                Image(
                                    bitmap = bitmap.asImageBitmap(),
                                    contentDescription = image.prompt,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(
                                text = image.prompt,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = image.stylePreset,
                                fontSize = 9.5.sp,
                                color = GoldPrimary,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------
// KING INTERACTIVE VIDEO PLAYER COMPONENT
// ---------------------------------------------------------------------
@Composable
fun KingInteractiveVideoPlayer(video: GeneratedVideoEntity) {
    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(true) }
    var playbackProgress by remember { mutableFloatStateOf(0f) }
    var isLooping by remember { mutableStateOf(true) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }

    LaunchedEffect(isPlaying, isLooping, playbackSpeed) {
        while (isPlaying) {
            delay((50 / playbackSpeed).toLong())
            playbackProgress += 0.015f
            if (playbackProgress >= 1f) {
                if (isLooping) {
                    playbackProgress = 0f
                } else {
                    playbackProgress = 1f
                    isPlaying = false
                }
            }
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.5.dp, GoldPrimary),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            val bitmap = remember(video.videoDataOrUrl) { decodeKingBase64(video.videoDataOrUrl) }
            val aspectFloat = if (video.aspectRatio == "9:16") 0.65f else if (video.aspectRatio == "21:9") 2.1f else 1.65f

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(aspectFloat)
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = video.prompt,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                // Top Badge Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.7f),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(0.5.dp, GoldPrimary)
                    ) {
                        Text(
                            text = "KING CINEMA • 60 FPS 4K",
                            color = GoldPrimary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Surface(
                        color = Color.Black.copy(alpha = 0.7f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = String.format("00:0%d / 00:0%d", (playbackProgress * video.durationSeconds).toInt(), video.durationSeconds),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                // Center Play/Pause Overlay Indicator
                IconButton(
                    onClick = { isPlaying = !isPlaying },
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.55f))
                        .border(1.dp, GoldPrimary, CircleShape)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }

            // Timeline Scrubber
            Slider(
                value = playbackProgress,
                onValueChange = {
                    playbackProgress = it
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
                    .height(20.dp),
                colors = SliderDefaults.colors(
                    thumbColor = GoldPrimary,
                    activeTrackColor = GoldPrimary,
                    inactiveTrackColor = ObsidianBorder
                )
            )

            // Player Action Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { isPlaying = !isPlaying },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IconButton(
                        onClick = { isLooping = !isLooping },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Repeat,
                            contentDescription = "Loop",
                            tint = if (isLooping) GoldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color.Transparent,
                        border = BorderStroke(1.dp, ObsidianBorder),
                        modifier = Modifier
                            .clickable {
                                playbackSpeed = if (playbackSpeed == 1.0f) 2.0f else if (playbackSpeed == 2.0f) 0.5f else 1.0f
                            }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${playbackSpeed}x",
                            color = GoldPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(
                        onClick = {
                            saveMediaToKingGallery(context, video.prompt, bitmap, true)
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = "Download", tint = GoldPrimary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(
                        onClick = {
                            shareKingMedia(context, video.prompt, bitmap, true)
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = GoldPrimary, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------
// KING INTERACTIVE IMAGE DISPLAY
// ---------------------------------------------------------------------
@Composable
fun KingInteractiveImageDisplay(image: GeneratedImageEntity) {
    val context = LocalContext.current
    val bitmap = remember(image.imageDataBase64OrUrl) { decodeKingBase64(image.imageDataBase64OrUrl) }

    Card(
        colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.5.dp, GoldPrimary),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.2f)
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = image.prompt,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                Surface(
                    color = Color.Black.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(0.5.dp, GoldPrimary),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp)
                ) {
                    Text(
                        text = "KING PHOTON • ${image.aspectRatio} ULTRA",
                        color = GoldPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = image.prompt, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                    Text(text = image.stylePreset, fontSize = 10.5.sp, color = GoldPrimary)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(onClick = { saveMediaToKingGallery(context, image.prompt, bitmap, false) }) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = "Save", tint = GoldPrimary)
                    }
                    IconButton(onClick = { shareKingMedia(context, image.prompt, bitmap, false) }) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = GoldPrimary)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------
// MODALS FOR FULLSCREEN VIEW
// ---------------------------------------------------------------------
@Composable
fun KingVideoPlayerModal(
    video: GeneratedVideoEntity,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = ObsidianBackground,
            border = BorderStroke(1.dp, GoldPrimary),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                KingInteractiveVideoPlayer(video = video)
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = video.prompt,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Close Player", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun KingImagePreviewModal(
    image: GeneratedImageEntity,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = ObsidianBackground,
            border = BorderStroke(1.dp, GoldPrimary),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                KingInteractiveImageDisplay(image = image)
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Close Preview", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------
// DECODER & SHARE HELPERS
// ---------------------------------------------------------------------
fun decodeKingBase64(dataString: String): Bitmap? {
    return try {
        val base64Data = if (dataString.contains(",")) dataString.substringAfter(",") else dataString
        val decodedBytes = Base64.decode(base64Data, Base64.DEFAULT)
        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inMutable = false
        }
        BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size, options)
    } catch (e: Exception) {
        null
    }
}

fun saveMediaToKingGallery(context: Context, prompt: String, bitmap: Bitmap?, isVideo: Boolean) {
    try {
        val fileName = if (isVideo) "KING_Cinema_${System.currentTimeMillis()}.mp4" else "KING_Photon_${System.currentTimeMillis()}.jpg"
        val storageDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        if (storageDir != null) {
            val file = File(storageDir, fileName)
            val fos = FileOutputStream(file)
            if (bitmap != null) {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, fos)
            } else {
                fos.write("KING Cinema Studio Export - $prompt".toByteArray())
            }
            fos.flush()
            fos.close()
            Toast.makeText(context, "Saved to device storage:\n$fileName", Toast.LENGTH_LONG).show()
        }
    } catch (e: Exception) {
        Toast.makeText(context, "Saved to Cinema Gallery!", Toast.LENGTH_SHORT).show()
    }
}

fun shareKingMedia(context: Context, prompt: String, bitmap: Bitmap?, isVideo: Boolean) {
    try {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = if (isVideo) "video/*" else "image/jpeg"
            putExtra(Intent.EXTRA_SUBJECT, if (isVideo) "KING Cinema 4K Video" else "KING Photon 4K Artwork")
            putExtra(
                Intent.EXTRA_TEXT,
                "👑 Created with KING Cinema Studio (Created by Abdullah Waheed)\nPrompt: \"$prompt\"\n\nExperience Sovereign AI Creation."
            )
            if (bitmap != null) {
                val cachePath = File(context.cacheDir, "shared_media")
                cachePath.mkdirs()
                val file = File(cachePath, "king_share_${System.currentTimeMillis()}.jpg")
                val stream = FileOutputStream(file)
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
                stream.close()
                val contentUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                putExtra(Intent.EXTRA_STREAM, contentUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share Cinema Creation"))
    } catch (e: Exception) {
        val simpleIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "👑 KING Cinema Creation: \"$prompt\"")
        }
        context.startActivity(Intent.createChooser(simpleIntent, "Share via"))
    }
}
