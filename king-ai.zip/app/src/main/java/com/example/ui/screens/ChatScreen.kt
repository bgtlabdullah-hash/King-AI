package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.speech.RecognizerIntent
import android.util.Base64
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.util.Locale
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import com.example.ui.viewmodel.MainViewModel
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.ui.window.Dialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MessageEntity
import com.example.data.local.MessageSender
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Translate
import com.example.data.local.KingAiDatabase
import com.example.data.repository.KingAiRepository
import com.example.ui.components.AudioTranscriptionDialog
import com.example.ui.components.GoogleMapsDirectionsDialog
import com.example.ui.components.KingInAppKeyboard
import com.example.ui.components.LiveVoiceDialog
import com.example.ui.components.LoginDialog
import com.example.ui.components.MarkdownText
import com.example.ui.components.Veo3VideoDialog
import com.example.ui.components.ModelSelectorDropdown
import com.example.ui.components.openSafepayProPayment
import com.example.ui.theme.AiBubbleColor
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.UserBubbleColor

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ChatScreen(
    viewModel: MainViewModel,
    onOpenDrawer: () -> Unit,
    onNavigateToSettings: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val messages by viewModel.messages.collectAsState()
    val selectedModel by viewModel.selectedModel.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val attachedImageBase64 by viewModel.attachedImageBase64.collectAsState()
    val speakingMessageId by viewModel.speakingMessageId.collectAsState()

    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val userName by viewModel.userName.collectAsState()
    val userEmail by viewModel.userEmail.collectAsState()

    var showLoginDialog by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showAttachmentDialog by remember { mutableStateOf(false) }

    var showLiveVoiceDialog by remember { mutableStateOf(false) }
    var showVeo3VideoDialog by remember { mutableStateOf(false) }
    var showAudioTranscribeDialog by remember { mutableStateOf(false) }
    var showGoogleMapsDirectionsDialog by remember { mutableStateOf(false) }
    var showCustomKeyboard by remember { mutableStateOf(false) }

    val repository = remember {
        val db = KingAiDatabase.getDatabase(context)
        KingAiRepository(db.chatDao(), db.imageCreatorDao(), db.videoCreatorDao())
    }

    var textInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    val lastMessageId = messages.lastOrNull()?.id
    val lastMessageContent = messages.lastOrNull()?.content

    // Automatically scroll the message list to the bottom whenever a new AI response is received, user sends a message, or typing status changes
    LaunchedEffect(messages.size, lastMessageId, lastMessageContent, isGenerating) {
        val totalItemCount = messages.size + if (isGenerating) 1 else 0
        if (totalItemCount > 0) {
            listState.animateScrollToItem(totalItemCount - 1)
        }
    }

    // Camera launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        bitmap?.let {
            val base64 = bitmapToBase64(it)
            viewModel.setAttachedImage(base64)
            Toast.makeText(context, "Photo captured & attached!", Toast.LENGTH_SHORT).show()
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch(null)
        } else {
            Toast.makeText(context, "Camera permission is required to take photos", Toast.LENGTH_SHORT).show()
        }
    }

    // File / Document Picker launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val mimeType = context.contentResolver.getType(it) ?: ""
            if (mimeType.startsWith("image/")) {
                val base64 = uriToBase64(context, it)
                if (base64 != null) {
                    viewModel.setAttachedImage(base64)
                    Toast.makeText(context, "Image attached!", Toast.LENGTH_SHORT).show()
                }
            } else {
                val fileName = getFileName(context, it) ?: "attached_file.txt"
                val content = readTextFromUri(context, it)
                if (!content.isNull_or_blank()) {
                    textInput = if (textInput.isBlank()) {
                        "[Attached File: $fileName]\n$content"
                    } else {
                        "$textInput\n\n[Attached File: $fileName]\n$content"
                    }
                    Toast.makeText(context, "File attached: $fileName", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "File selected: $fileName", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // Speech-to-Text launcher
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spokenText.isNull_or_blank()) {
                textInput = if (textInput.isBlank()) spokenText!! else "$textInput $spokenText"
                Toast.makeText(context, "Voice captured: \"$spokenText\"", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Helper to start speech recognition
    val launchSpeechIntent = {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your query to KING AI...")
        }
        try {
            speechLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Voice input not supported on this device", Toast.LENGTH_SHORT).show()
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            launchSpeechIntent()
        } else {
            Toast.makeText(context, "Microphone permission is required for voice input", Toast.LENGTH_SHORT).show()
        }
    }

    // Image Picker launcher
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val base64 = uriToBase64(context, it)
            if (base64 != null) {
                viewModel.setAttachedImage(base64)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "KING AI",
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary,
                                fontSize = 17.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            ModelSelectorDropdown(
                                selectedModelId = selectedModel,
                                onModelSelected = { viewModel.setSelectedModel(it) }
                            )
                        }
                        Text(
                            text = "Created by Abdullah Waheed",
                            color = GoldPrimary.copy(alpha = 0.9f),
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onOpenDrawer,
                        modifier = Modifier.testTag("drawer_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Open Drawer",
                            tint = GoldPrimary
                        )
                    }
                },
                actions = {
                    // Login / User Account Chip in Top Right
                    Box(
                        modifier = Modifier
                            .padding(end = 4.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isLoggedIn) GoldPrimary.copy(alpha = 0.2f) else GoldPrimary)
                            .border(1.dp, GoldPrimary, RoundedCornerShape(16.dp))
                            .clickable {
                                if (isLoggedIn) {
                                    showProfileDialog = true
                                } else {
                                    showLoginDialog = true
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("login_account_chip"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = if (isLoggedIn) GoldPrimary else Color.Black,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isLoggedIn) (userName ?: "User") else "Login",
                                fontWeight = FontWeight.Bold,
                                color = if (isLoggedIn) GoldPrimary else Color.Black,
                                fontSize = 11.sp,
                                maxLines = 1
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .padding(end = 4.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(GoldPrimary)
                            .clickable { openSafepayProPayment(context) }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "👑 PRO",
                            fontWeight = FontWeight.Bold,
                            color = Color.Black,
                            fontSize = 11.sp
                        )
                    }

                    IconButton(
                        onClick = onNavigateToSettings,
                        modifier = Modifier.testTag("topbar_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings & Security Lock",
                            tint = GoldPrimary
                        )
                    }

                    IconButton(onClick = { viewModel.startNewChat() }) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "New Chat",
                            tint = GoldPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ObsidianBackground
                )
            )
        },
        containerColor = ObsidianBackground,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (messages.isEmpty()) {
                // Empty Welcome Screen with Quick Starter Prompt Cards
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(ObsidianSurfaceVariant)
                                .border(1.dp, GoldPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Greetings! I am KING AI.",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "How may I empower your thoughts today?",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(28.dp))

                        // Quick Starter Prompt Chips
                        FlowRow(
                            horizontalArrangement = Arrangement.Center,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            StarterPromptChip(
                                label = "⚡ Write a clean Kotlin Coroutines function",
                                onClick = {
                                    textInput = "Write a clean Kotlin Coroutines function for fetching weather data with error handling."
                                }
                            )
                            StarterPromptChip(
                                label = "🎨 Create an AI prompt for Image Studio",
                                onClick = {
                                    textInput = "Give me 3 detailed prompts to generate a breathtaking sci-fi royal kingdom in KING AI Image Studio."
                                }
                            )
                            StarterPromptChip(
                                label = "🧠 Explain Quantum Computing simply",
                                onClick = {
                                    textInput = "Explain quantum computing in simple terms with analogies."
                                }
                            )
                        }
                    }
                }
            } else {
                // Message List
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        ChatMessageItem(
                            message = msg,
                            isSpeaking = speakingMessageId == msg.id,
                            onSpeakClick = { viewModel.speakMessage(msg.id, msg.content) },
                            onTranslateClick = { lang -> viewModel.translateMessage(msg.id, lang) }
                        )
                    }

                    if (isGenerating) {
                        item {
                            TypingIndicator()
                        }
                    }
                }
            }

            // Attached Image Preview Bar
            attachedImageBase64?.let { base64 ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(ObsidianSurfaceVariant)
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val bitmap = base64ToBitmap(base64)
                        if (bitmap != null) {
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "Attached image",
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(8.dp)),
                                contentScale = ContentScale.Crop
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Image attached",
                            style = MaterialTheme.typography.bodySmall,
                            color = GoldPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { viewModel.setAttachedImage(null) }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Remove image",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Quick AI Tools Ribbon (Front page access beside file upload)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Live Voice
                QuickToolChip(
                    icon = Icons.Default.RecordVoiceOver,
                    label = "Live Voice",
                    onClick = { showLiveVoiceDialog = true }
                )
                // Veo 3 Video
                QuickToolChip(
                    icon = Icons.Default.Movie,
                    label = "Veo 3",
                    onClick = { showVeo3VideoDialog = true }
                )
                // Transcribe
                QuickToolChip(
                    icon = Icons.Default.Subtitles,
                    label = "Transcribe",
                    onClick = { showAudioTranscribeDialog = true }
                )
                // Maps Directions
                QuickToolChip(
                    icon = Icons.Default.Directions,
                    label = "Maps Directions",
                    onClick = { showGoogleMapsDirectionsDialog = true }
                )
            }

            // Bottom Input Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Attach Photo / Camera / File Button
                IconButton(
                    onClick = {
                        if (!isLoggedIn) {
                            Toast.makeText(context, "Login required to upload photos or files!", Toast.LENGTH_SHORT).show()
                            showLoginDialog = true
                        } else {
                            showAttachmentDialog = true
                        }
                    },
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("attach_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AttachFile,
                        contentDescription = "Attach photo, camera, or file",
                        tint = GoldPrimary
                    )
                }

                // Keyboard Toggle Button
                IconButton(
                    onClick = { showCustomKeyboard = !showCustomKeyboard },
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Keyboard,
                        contentDescription = "In-App Urdu & English Keyboard",
                        tint = if (showCustomKeyboard) GoldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Voice Mic Button
                IconButton(
                    onClick = {
                        val hasAudioPermission = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED

                        if (hasAudioPermission) {
                            launchSpeechIntent()
                        } else {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("voice_input_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Speak query",
                        tint = GoldPrimary
                    )
                }

                // Input Field
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = { Text("Ask KING AI in English or اردو...", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 2.dp)
                        .testTag("prompt_input_field"),
                    maxLines = 4,
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = ObsidianBorder,
                        focusedContainerColor = ObsidianSurfaceVariant,
                        unfocusedContainerColor = ObsidianSurfaceVariant,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )

                // Send Button
                IconButton(
                    onClick = {
                        if (textInput.isNotBlank() || attachedImageBase64 != null) {
                            val promptToSend = textInput
                            viewModel.sendMessage(promptToSend)
                            textInput = ""
                            coroutineScope.launch {
                                val targetIndex = (messages.size + 1).coerceAtLeast(0)
                                if (targetIndex > 0) {
                                    listState.animateScrollToItem(targetIndex - 1)
                                }
                            }
                        }
                    },
                    enabled = !isGenerating && (textInput.isNotBlank() || attachedImageBase64 != null),
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(if (textInput.isNotBlank() || attachedImageBase64 != null) GoldPrimary else ObsidianSurfaceVariant)
                        .testTag("send_prompt_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send prompt",
                        tint = if (textInput.isNotBlank() || attachedImageBase64 != null) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Custom In-App Urdu & English Keyboard
            KingInAppKeyboard(
                isVisible = showCustomKeyboard,
                textInput = textInput,
                onTextChanged = { textInput = it },
                onSendPrompt = {
                    if (textInput.isNotBlank()) {
                        val promptToSend = textInput
                        viewModel.sendMessage(promptToSend)
                        textInput = ""
                        coroutineScope.launch {
                            val targetIndex = (messages.size + 1).coerceAtLeast(0)
                            if (targetIndex > 0) {
                                listState.animateScrollToItem(targetIndex - 1)
                            }
                        }
                    }
                },
                onCloseKeyboard = { showCustomKeyboard = false }
            )
        }
    }

    if (showLiveVoiceDialog) {
        LiveVoiceDialog(repository = repository, onDismissRequest = { showLiveVoiceDialog = false })
    }

    if (showVeo3VideoDialog) {
        Veo3VideoDialog(repository = repository, onDismissRequest = { showVeo3VideoDialog = false })
    }

    if (showAudioTranscribeDialog) {
        AudioTranscriptionDialog(repository = repository, onDismissRequest = { showAudioTranscribeDialog = false })
    }

    if (showGoogleMapsDirectionsDialog) {
        GoogleMapsDirectionsDialog(repository = repository, onDismissRequest = { showGoogleMapsDirectionsDialog = false })
    }

    if (showLoginDialog) {
        LoginDialog(
            onDismissRequest = { showLoginDialog = false },
            onLoginSuccess = { name, email ->
                viewModel.login(name, email)
                showLoginDialog = false
                Toast.makeText(context, "Welcome, $name! Photo uploads & image creation enabled.", Toast.LENGTH_LONG).show()
            }
        )
    }

    if (showProfileDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showProfileDialog = false },
            confirmButton = {
                androidx.compose.material3.Button(
                    onClick = {
                        viewModel.logout()
                        showProfileDialog = false
                        Toast.makeText(context, "Logged out successfully", Toast.LENGTH_SHORT).show()
                    },
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black)
                ) {
                    Text("Log Out", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                androidx.compose.material3.OutlinedButton(onClick = { showProfileDialog = false }) {
                    Text("Close", color = GoldPrimary)
                }
            },
            title = {
                Text("KING AI Profile", color = GoldPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text("Signed in as: ${userName ?: "User"}", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold)
                    Text("Email: ${userEmail ?: "N/A"}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("✨ Created by Abdullah Waheed", color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = ObsidianSurfaceVariant
        )
    }

    if (showAttachmentDialog) {
        Dialog(onDismissRequest = { showAttachmentDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = ObsidianBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, GoldPrimary.copy(alpha = 0.6f), RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AttachFile,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Attach to KING AI",
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary,
                                fontSize = 17.sp
                            )
                        }
                        IconButton(onClick = { showAttachmentDialog = false }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Option 1: Take Photo from Camera
                    AttachmentOptionItem(
                        icon = Icons.Default.CameraAlt,
                        title = "Take Photo (Camera)",
                        subtitle = "Snap a picture using camera",
                        onClick = {
                            showAttachmentDialog = false
                            val hasCameraPermission = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.CAMERA
                            ) == PackageManager.PERMISSION_GRANTED

                            if (hasCameraPermission) {
                                cameraLauncher.launch(null)
                            } else {
                                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Option 2: Gallery Image
                    AttachmentOptionItem(
                        icon = Icons.Default.PhotoLibrary,
                        title = "Choose Photo (Gallery)",
                        subtitle = "Pick an image from your device photo library",
                        onClick = {
                            showAttachmentDialog = false
                            imagePickerLauncher.launch("image/*")
                        }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Option 3: Document / Any File
                    AttachmentOptionItem(
                        icon = Icons.Default.Description,
                        title = "Upload File or Document",
                        subtitle = "Select PDF, TXT, DOC, code, or data file",
                        onClick = {
                            showAttachmentDialog = false
                            filePickerLauncher.launch("*/*")
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ChatMessageItem(
    message: MessageEntity,
    isSpeaking: Boolean,
    onSpeakClick: () -> Unit,
    onTranslateClick: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val isUser = message.sender == MessageSender.USER
    var showLanguageMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            // KING AI Crown Avatar
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(ObsidianSurfaceVariant)
                    .border(1.dp, GoldPrimary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "KING AI Avatar",
                    tint = GoldPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
            modifier = Modifier.widthIn(max = 330.dp)
        ) {
            // Upside Language Translation Bar for AI answers
            if (!isUser) {
                Row(
                    modifier = Modifier
                        .padding(bottom = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(ObsidianSurfaceVariant)
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Translate,
                        contentDescription = "Translate Answer Language",
                        tint = GoldPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Change Answer Language:",
                        fontSize = 10.sp,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))

                    // Language Quick Chips
                    val languages = listOf("Urdu (اردو)", "English", "Arabic", "French", "Spanish")
                    languages.take(3).forEach { lang ->
                        Box(
                            modifier = Modifier
                                .padding(end = 4.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(GoldPrimary.copy(alpha = 0.2f))
                                .clickable { onTranslateClick(lang) }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = lang,
                                fontSize = 9.sp,
                                color = GoldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isUser) UserBubbleColor else AiBubbleColor
                ),
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isUser) 16.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 16.dp
                ),
                modifier = Modifier.border(
                    width = 0.5.dp,
                    color = if (isUser) ObsidianBorder else ObsidianBorder,
                    shape = RoundedCornerShape(16.dp)
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Attached Image if present
                    if (!message.imageBase64OrUri.isNull_or_blank()) {
                        val bitmap = base64ToBitmap(message.imageBase64OrUri!!)
                        if (bitmap != null) {
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "Attached image",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp)
                                    .clip(RoundedCornerShape(8.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }

                    // Markdown Content
                    MarkdownText(
                        text = message.content,
                        textColor = if (isUser) Color.Black else MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // Message Actions (Copy & Read Aloud)
            if (!isUser) {
                Row(
                    modifier = Modifier.padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("KING AI Message", message.content)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Copied response", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy message",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = onSpeakClick,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Read aloud",
                            tint = if (isSpeaking) GoldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TypingIndicator() {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(ObsidianSurfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = GoldPrimary,
                modifier = Modifier.size(16.dp)
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        CircularProgressIndicator(
            modifier = Modifier.size(18.dp),
            color = GoldPrimary,
            strokeWidth = 2.dp
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "KING AI is thinking...",
            style = MaterialTheme.typography.bodySmall,
            color = GoldPrimary
        )
    }
}

@Composable
fun StarterPromptChip(label: String, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(4.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

@Composable
fun QuickToolChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = ObsidianSurfaceVariant,
        modifier = Modifier
            .clickable(onClick = onClick)
            .border(0.5.dp, GoldPrimary.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = GoldPrimary,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = GoldPrimary
            )
        }
    }
}

private fun String?.isNull_or_blank(): Boolean {
    return this == null || this.isBlank()
}

@Composable
fun AttachmentOptionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = ObsidianSurfaceVariant,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .border(1.dp, ObsidianBorder, RoundedCornerShape(14.dp))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = GoldPrimary.copy(alpha = 0.15f),
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier
                        .padding(8.dp)
                        .size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 14.sp
                )
                Text(
                    text = subtitle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
            }
        }
    }
}

fun bitmapToBase64(bitmap: Bitmap): String {
    val outputStream = ByteArrayOutputStream()
    try {
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    } finally {
        outputStream.close()
    }
}

fun readTextFromUri(context: Context, uri: Uri): String? {
    return try {
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            inputStream.bufferedReader().use { it.readText() }
        }
    } catch (e: Exception) {
        null
    }
}

fun getFileName(context: Context, uri: Uri): String? {
    var fileName: String? = null
    if (uri.scheme == "content") {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val displayNameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (displayNameIndex != -1) {
                    fileName = it.getString(displayNameIndex)
                }
            }
        }
    }
    if (fileName == null) {
        fileName = uri.path?.let { path ->
            val cut = path.lastIndexOf('/')
            if (cut != -1) path.substring(cut + 1) else path
        }
    }
    return fileName
}

fun uriToBase64(context: Context, uri: Uri): String? {
    return try {
        val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri)) { decoder, _, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
        val outputStream = ByteArrayOutputStream()
        try {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
            Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
        } finally {
            bitmap.recycle()
            outputStream.close()
        }
    } catch (e: Exception) {
        null
    }
}

fun base64ToBitmap(base64String: String): Bitmap? {
    return try {
        val cleanBase64 = if (base64String.contains(",")) {
            base64String.substringAfter(",")
        } else {
            base64String
        }
        val decodedBytes = Base64.decode(cleanBase64, Base64.NO_WRAP)
        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inMutable = false
        }
        BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size, options)
    } catch (e: Exception) {
        null
    }
}
