package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Grain
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant

data class DailyUsagePoint(
    val dayLabel: String,
    val queries: Int,
    val tokens: Int, // in Thousands
    val avgLatencyMs: Int
)

data class ModelUsageRatio(
    val modelName: String,
    val percentage: Float,
    val color: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onBackToChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTimeRange by remember { mutableStateOf("7 Days") }
    val timeRanges = listOf("7 Days", "14 Days", "30 Days")

    // Mock/Tracked daily usage data points
    val dailyData = remember(selectedTimeRange) {
        when (selectedTimeRange) {
            "14 Days" -> listOf(
                DailyUsagePoint("Day 1", 45, 12, 320),
                DailyUsagePoint("Day 2", 82, 28, 290),
                DailyUsagePoint("Day 3", 110, 45, 310),
                DailyUsagePoint("Day 4", 95, 38, 280),
                DailyUsagePoint("Day 5", 140, 52, 350),
                DailyUsagePoint("Day 6", 185, 78, 260),
                DailyUsagePoint("Day 7", 210, 89, 270)
            )
            "30 Days" -> listOf(
                DailyUsagePoint("W1", 340, 140, 310),
                DailyUsagePoint("W2", 520, 210, 290),
                DailyUsagePoint("W3", 680, 295, 275),
                DailyUsagePoint("W4", 890, 380, 260)
            )
            else -> listOf(
                DailyUsagePoint("Mon", 120, 42, 340),
                DailyUsagePoint("Tue", 240, 88, 290),
                DailyUsagePoint("Wed", 180, 65, 310),
                DailyUsagePoint("Thu", 310, 115, 270),
                DailyUsagePoint("Fri", 420, 160, 250),
                DailyUsagePoint("Sat", 290, 98, 280),
                DailyUsagePoint("Sun", 380, 145, 260)
            )
        }
    }

    var selectedPointIndex by remember { mutableStateOf<Int?>(4) }

    val modelRatios = listOf(
        ModelUsageRatio("gemini-3.5-flash", 48f, GoldPrimary),
        ModelUsageRatio("gemini-3.1-flash-live", 22f, Color(0xFF4CAF50)),
        ModelUsageRatio("veo-3.1-fast-generate", 18f, Color(0xFF2196F3)),
        ModelUsageRatio("imagen-3.0-generate", 12f, Color(0xFF9C27B0))
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.QueryStats, contentDescription = null, tint = GoldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "API Usage Dashboard",
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary,
                            fontSize = 18.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackToChat) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsidianBackground)
            )
        },
        containerColor = ObsidianBackground,
        modifier = modifier
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Description & Time Range Selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "REAL-TIME API & QUERY ANALYTICS",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Daily metrics, token usage & request volume",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    timeRanges.forEach { range ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selectedTimeRange == range) GoldPrimary else ObsidianSurfaceVariant,
                            modifier = Modifier
                                .clickable { selectedTimeRange = range }
                                .border(0.5.dp, GoldPrimary, RoundedCornerShape(12.dp))
                        ) {
                            Text(
                                text = range,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedTimeRange == range) Color.Black else GoldPrimary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Key KPI Metric Cards Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiCard(
                    title = "Total Queries",
                    value = "${dailyData.sumOf { it.queries }}",
                    subtext = "+24% vs last week",
                    icon = Icons.Default.BarChart,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "Avg Latency",
                    value = "${(dailyData.map { it.avgLatencyMs }.average()).toInt()} ms",
                    subtext = "Ultra-Fast 3.5 Flash",
                    icon = Icons.Default.Speed,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "Total Tokens",
                    value = "${dailyData.sumOf { it.tokens }}K",
                    subtext = "Input + Output",
                    icon = Icons.Default.Grain,
                    modifier = Modifier.weight(1f)
                )
            }

            // Main Interactive Daily Usage Bar & Line Visualizer Chart
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, GoldPrimary.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Timeline, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Daily API Query History",
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary,
                                fontSize = 15.sp
                            )
                        }

                        // Selected Point Data Badge
                        selectedPointIndex?.let { index ->
                            val pt = dailyData.getOrNull(index)
                            if (pt != null) {
                                Text(
                                    text = "${pt.dayLabel}: ${pt.queries} queries (${pt.tokens}K tokens)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldPrimary,
                                    modifier = Modifier
                                        .background(GoldPrimary.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Native Canvas Daily Usage Chart with Bars + Curved Area Gradient
                    val maxQuery = remember(dailyData) { (dailyData.maxOfOrNull { it.queries } ?: 500) * 1.2f }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    ) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(dailyData) {
                                    detectTapGestures { offset ->
                                        val barWidth = size.width / dailyData.size
                                        val tappedIndex = (offset.x / barWidth).toInt().coerceIn(0, dailyData.size - 1)
                                        selectedPointIndex = tappedIndex
                                    }
                                }
                        ) {
                            val canvasWidth = size.width
                            val canvasHeight = size.height
                            val barWidth = canvasWidth / dailyData.size
                            val cornerRadius = CornerRadius(12f, 12f)

                            // Draw Horizontal Gridlines
                            repeat(4) { idx ->
                                val y = canvasHeight * (1f - idx / 3f)
                                drawLine(
                                    color = ObsidianBorder,
                                    start = Offset(0f, y),
                                    end = Offset(canvasWidth, y),
                                    strokeWidth = 1f
                                )
                            }

                            val linePath = Path()
                            val areaPath = Path()

                            dailyData.forEachIndexed { index, pt ->
                                val barX = index * barWidth + barWidth * 0.2f
                                val actualBarWidth = barWidth * 0.6f
                                val barHeight = (pt.queries / maxQuery) * canvasHeight
                                val barY = canvasHeight - barHeight

                                val isSelected = index == selectedPointIndex

                                // Draw Bar
                                drawRoundRect(
                                    color = if (isSelected) GoldPrimary else GoldPrimary.copy(alpha = 0.35f),
                                    topLeft = Offset(barX, barY),
                                    size = Size(actualBarWidth, barHeight),
                                    cornerRadius = cornerRadius
                                )

                                // Build Curve Points
                                val centerX = barX + actualBarWidth / 2f
                                val lineY = barY

                                if (index == 0) {
                                    linePath.moveTo(centerX, lineY)
                                    areaPath.moveTo(centerX, canvasHeight)
                                    areaPath.lineTo(centerX, lineY)
                                } else {
                                    val prevX = (index - 1) * barWidth + barWidth * 0.5f
                                    val prevY = canvasHeight - (dailyData[index - 1].queries / maxQuery) * canvasHeight
                                    val controlX1 = prevX + (centerX - prevX) / 2f
                                    linePath.cubicTo(controlX1, prevY, controlX1, lineY, centerX, lineY)
                                    areaPath.cubicTo(controlX1, prevY, controlX1, lineY, centerX, lineY)
                                }

                                if (index == dailyData.size - 1) {
                                    areaPath.lineTo(centerX, canvasHeight)
                                    areaPath.close()
                                }

                                // Highlight Circle on Selected Node
                                if (isSelected) {
                                    drawCircle(
                                        color = Color.White,
                                        radius = 10f,
                                        center = Offset(centerX, lineY)
                                    )
                                    drawCircle(
                                        color = GoldPrimary,
                                        radius = 6f,
                                        center = Offset(centerX, lineY)
                                    )
                                }
                            }

                            // Draw Gradient Area under Curve
                            drawPath(
                                path = areaPath,
                                brush = Brush.verticalGradient(
                                    colors = listOf(GoldPrimary.copy(alpha = 0.3f), Color.Transparent),
                                    startY = 0f,
                                    endY = canvasHeight
                                )
                            )

                            // Draw Line Curve
                            drawPath(
                                path = linePath,
                                color = GoldPrimary,
                                style = Stroke(width = 4f, cap = StrokeCap.Round)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // X-Axis Day Labels
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        dailyData.forEachIndexed { idx, pt ->
                            val isSelected = idx == selectedPointIndex
                            Text(
                                text = pt.dayLabel,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Normal,
                                color = if (isSelected) GoldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Model Distribution Donut & Token Usage Breakdown Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Donut Chart Card for Model Distribution
                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .weight(1.1f)
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(20.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Model Distribution",
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Donut Canvas
                            Box(
                                modifier = Modifier.size(75.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    var startAngle = -90f
                                    modelRatios.forEach { item ->
                                        val sweepAngle = (item.percentage / 100f) * 360f
                                        drawArc(
                                            color = item.color,
                                            startAngle = startAngle,
                                            sweepAngle = sweepAngle,
                                            useCenter = false,
                                            style = Stroke(width = 18f, cap = StrokeCap.Round)
                                        )
                                        startAngle += sweepAngle
                                    }
                                }
                                Text("AI", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                            }

                            // Model Legend List
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                modelRatios.forEach { item ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(item.color)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "${item.modelName.take(12)}... (${item.percentage.toInt()}%)",
                                            fontSize = 9.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Hourly Peak Usage Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .weight(0.9f)
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(20.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Peak Activity Hours",
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        // Peak Hours Heat Indicator Bars
                        val hourlySpikes = listOf(15, 30, 85, 95, 60, 40)
                        val hourLabels = listOf("8AM", "12PM", "4PM", "8PM", "12AM", "4AM")

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            hourlySpikes.forEach { spike ->
                                Box(
                                    modifier = Modifier
                                        .width(12.dp)
                                        .height((spike * 0.5f).dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (spike > 70) GoldPrimary else GoldPrimary.copy(alpha = 0.4f))
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            hourLabels.forEach { label ->
                                Text(label, fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            // Summary Footer Note
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, ObsidianBorder, RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "All API queries logged in local Room database with zero latency overhead.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun KpiCard(
    title: String,
    value: String,
    subtext: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier.border(0.5.dp, GoldPrimary.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                Icon(imageVector = icon, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(14.dp))
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = GoldPrimary)
            Text(text = subtext, fontSize = 9.sp, color = GoldPrimary.copy(alpha = 0.8f))
        }
    }
}
