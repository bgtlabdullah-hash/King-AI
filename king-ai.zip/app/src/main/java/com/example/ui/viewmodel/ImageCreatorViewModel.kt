package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.GeneratedImageEntity
import com.example.data.local.KingAiDatabase
import com.example.data.repository.KingAiRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ImageCreatorViewModel(application: Application) : AndroidViewModel(application) {

    private val db = KingAiDatabase.getDatabase(application)
    private val repository = KingAiRepository(db.chatDao(), db.imageCreatorDao())

    val authManager = com.example.data.local.UserAuthManager.getInstance(application)
    val isLoggedIn: StateFlow<Boolean> = authManager.isLoggedIn
    val userName: StateFlow<String?> = authManager.userName

    fun login(name: String, email: String) {
        authManager.login(name, email)
    }

    fun logout() {
        authManager.logout()
    }

    val galleryImages: StateFlow<List<GeneratedImageEntity>> = repository.allGeneratedImages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _prompt = MutableStateFlow("")
    val prompt: StateFlow<String> = _prompt.asStateFlow()

    private val _selectedStyle = MutableStateFlow("Royal Fantasy")
    val selectedStyle: StateFlow<String> = _selectedStyle.asStateFlow()

    private val _selectedAspectRatio = MutableStateFlow("1:1")
    val selectedAspectRatio: StateFlow<String> = _selectedAspectRatio.asStateFlow()

    private val _selectedImageSize = MutableStateFlow("2K")
    val selectedImageSize: StateFlow<String> = _selectedImageSize.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _currentGeneratedImage = MutableStateFlow<GeneratedImageEntity?>(null)
    val currentGeneratedImage: StateFlow<GeneratedImageEntity?> = _currentGeneratedImage.asStateFlow()

    val stylePresets = listOf(
        "Royal Fantasy", "Photorealistic", "Digital Art",
        "Cyberpunk", "3D Render", "Cinematic", "Anime", "Oil Painting"
    )

    val aspectRatios = listOf("1:1", "16:9", "9:16", "4:3")
    val imageSizes = listOf("1K", "2K", "4K")

    val samplePrompts = listOf(
        "A majestic golden crown floating above an ancient marble palace at sunset",
        "A cyberpunk futuristic city skyline bathed in golden neon lights and rain",
        "An intricate 3D render of a mechanical royal cyber lion with glowing eyes",
        "A serene fantasy landscape with floating crystal islands and golden waterfalls"
    )

    fun setPrompt(text: String) {
        _prompt.value = text
    }

    fun setSelectedStyle(style: String) {
        _selectedStyle.value = style
    }

    fun setSelectedAspectRatio(ratio: String) {
        _selectedAspectRatio.value = ratio
    }

    fun setSelectedImageSize(size: String) {
        _selectedImageSize.value = size
    }

    fun setRandomSamplePrompt() {
        _prompt.value = samplePrompts.random()
    }

    fun generateImage() {
        val currentPrompt = _prompt.value.trim()
        if (currentPrompt.isBlank()) return

        _isGenerating.value = true
        viewModelScope.launch {
            val result = repository.generateImage(
                prompt = currentPrompt,
                stylePreset = _selectedStyle.value,
                aspectRatio = _selectedAspectRatio.value,
                imageSize = _selectedImageSize.value
            )
            _isGenerating.value = false
            result.onSuccess { entity ->
                _currentGeneratedImage.value = entity
            }
        }
    }

    fun deleteImage(id: Long) {
        viewModelScope.launch {
            repository.deleteGeneratedImage(id)
            if (_currentGeneratedImage.value?.id == id) {
                _currentGeneratedImage.value = galleryImages.value.firstOrNull { it.id != id }
            }
        }
    }
}
