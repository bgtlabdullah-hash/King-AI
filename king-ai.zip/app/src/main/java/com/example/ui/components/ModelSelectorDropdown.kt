package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant

import com.example.util.AppEditionManager

const val SAFEPAY_PRO_LINK = "https://sandbox.api.getsafepay.com/io/quick-link?ql=link_4be624f5-369c-43b5-9e69-082072b78c79"

fun openSafepayProPayment(context: Context) {
    val editionManager = AppEditionManager(context)
    if (editionManager.isAllFeaturesUnlocked()) {
        Toast.makeText(context, "👑 Master Edition: All Pro Features Unlocked 100% Free!", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(SAFEPAY_PRO_LINK))
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Opening payment link...", Toast.LENGTH_SHORT).show()
    }
}

data class ModelOption(
    val id: String,
    val name: String,
    val tag: String,
    val isPro: Boolean
)

val AvailableModels = listOf(
    ModelOption("gpt-4o", "KING ChatGPT 4o", "🧠 GPT-4o", false),
    ModelOption("gpt-4o-mini", "KING ChatGPT Mini", "⚡ GPT Mini", false),
    ModelOption("gemini-3.5-flash", "KING Fast", "⚡ 3.5 Flash", false),
    ModelOption("gemini-3.1-pro-preview", "KING Pro Reasoner", "👑 3.1 Pro", true),
    ModelOption("gemini-3.1-flash-live-preview", "KING Live Voice", "🎙️ Live API", false),
    ModelOption("gemini-3-pro-image-preview", "KING Pro Image", "🎨 Pro Image", false),
    ModelOption("veo-3.1-fast-generate-preview", "KING Veo 3 Video", "🎬 Veo 3 Video", false)
)

@Composable
fun ModelSelectorDropdown(
    selectedModelId: String,
    onModelSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val editionManager = remember { AppEditionManager(context) }
    var expanded by remember { mutableStateOf(false) }
    val current = AvailableModels.find { it.id == selectedModelId } ?: AvailableModels[0]

    Box(modifier = modifier) {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(ObsidianSurfaceVariant)
                .clickable { expanded = true }
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (current.isPro) Icons.Default.AutoAwesome else Icons.Default.Bolt,
                contentDescription = null,
                tint = GoldPrimary,
                modifier = Modifier.padding(end = 4.dp)
            )
            Text(
                text = current.name,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.width(2.dp))
            Icon(
                imageVector = Icons.Default.ArrowDropDown,
                contentDescription = "Change model",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(ObsidianSurfaceVariant)
        ) {
            AvailableModels.forEach { option ->
                DropdownMenuItem(
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = option.name,
                                color = if (option.id == selectedModelId) GoldPrimary else MaterialTheme.colorScheme.onSurface,
                                fontWeight = if (option.id == selectedModelId) FontWeight.Bold else FontWeight.Normal
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (option.isPro && editionManager.isAllFeaturesUnlocked()) "👑 UNLOCKED" else option.tag,
                                fontSize = 11.sp,
                                color = if (option.isPro && editionManager.isAllFeaturesUnlocked()) GoldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    onClick = {
                        onModelSelected(option.id)
                        expanded = false
                        if (option.isPro && !editionManager.isAllFeaturesUnlocked()) {
                            openSafepayProPayment(context)
                        }
                    }
                )
            }

            HorizontalDivider(color = ObsidianBorder, modifier = Modifier.padding(vertical = 4.dp))

            // Special Premium Upgrade Option
            DropdownMenuItem(
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = GoldPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (editionManager.isAllFeaturesUnlocked()) "👑 Master Privileges (100% Unlocked)" else "Upgrade to Pro (Rs. 1500)",
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                },
                onClick = {
                    expanded = false
                    openSafepayProPayment(context)
                }
            )
        }
    }
}

