package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ChatEntity
import com.example.data.local.KingAiDatabase
import com.example.data.local.MessageEntity
import com.example.data.local.MessageSender
import com.example.data.repository.KingAiRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = KingAiDatabase.getDatabase(application)
    val repository = KingAiRepository(db.chatDao(), db.imageCreatorDao(), db.videoCreatorDao())

    val authManager = com.example.data.local.UserAuthManager.getInstance(application)
    val isLoggedIn: StateFlow<Boolean> = authManager.isLoggedIn
    val userName: StateFlow<String?> = authManager.userName
    val userEmail: StateFlow<String?> = authManager.userEmail

    val allGeneratedImages = repository.allGeneratedImages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allGeneratedVideos = repository.allGeneratedVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun login(name: String, email: String) {
        authManager.login(name, email)
    }

    fun logout() {
        authManager.logout()
    }

    val chatsList: StateFlow<List<ChatEntity>> = repository.allChats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeChatId = MutableStateFlow<Long?>(null)
    val activeChatId: StateFlow<Long?> = _activeChatId.asStateFlow()

    private val _messages = MutableStateFlow<List<MessageEntity>>(emptyList())
    val messages: StateFlow<List<MessageEntity>> = _messages.asStateFlow()

    private val _selectedModel = MutableStateFlow("gemini-3.5-flash")
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _attachedImageBase64 = MutableStateFlow<String?>(null)
    val attachedImageBase64: StateFlow<String?> = _attachedImageBase64.asStateFlow()

    private var textToSpeech: TextToSpeech? = null
    private val _speakingMessageId = MutableStateFlow<Long?>(null)
    val speakingMessageId: StateFlow<Long?> = _speakingMessageId.asStateFlow()

    init {
        // Initialize TTS
        textToSpeech = TextToSpeech(application) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.language = Locale.US
            }
        }

        // Initialize active chat
        viewModelScope.launch {
            val chats = repository.allChats.first()
            if (chats.isNotEmpty()) {
                selectChat(chats.first().id)
            } else {
                startNewChat()
            }
        }
    }

    fun selectChat(chatId: Long) {
        _activeChatId.value = chatId
        viewModelScope.launch {
            repository.getMessagesForChat(chatId).collect { msgList ->
                _messages.value = msgList
            }
        }
    }

    fun startNewChat() {
        viewModelScope.launch {
            val newId = repository.createNewChat("New Conversation", selectedModel.value)
            selectChat(newId)
        }
    }

    fun deleteChat(chatId: Long) {
        viewModelScope.launch {
            repository.deleteChat(chatId)
            val remaining = chatsList.value.filter { it.id != chatId }
            if (remaining.isNotEmpty()) {
                selectChat(remaining.first().id)
            } else {
                startNewChat()
            }
        }
    }

    fun setSelectedModel(modelId: String) {
        _selectedModel.value = modelId
    }

    fun setAttachedImage(base64: String?) {
        _attachedImageBase64.value = base64
    }

    private fun isImageGenerationRequest(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        val keywords = listOf(
            "make an image", "make image", "generate image", "generate an image",
            "create image", "create an image", "draw ", "draw a ", "draw an ",
            "paint ", "paint a ", "paint an ", "image of ", "photo of ", "picture of ",
            "tasveer banao", "tasveer bana do", "picture banao", "tasveer banayein",
            "make a wallpaper", "generate wallpaper", "create wallpaper"
        )
        return keywords.any { lower.startsWith(it) || lower.contains(it) }
    }

    private fun isVideoGenerationRequest(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        val keywords = listOf(
            "make a video", "make video", "generate video", "generate a video",
            "create video", "create a video", "video of ", "cinematic video",
            "video banao", "video bana do", "video banayein", "render video"
        )
        return keywords.any { lower.startsWith(it) || lower.contains(it) }
    }

    private fun cleanMediaPrompt(rawPrompt: String): String {
        var clean = rawPrompt.trim()
        val prefixes = listOf(
            "make an image of", "make image of", "generate image of", "generate an image of",
            "create image of", "create an image of", "make an image", "make image",
            "generate image", "generate an image", "create image", "create an image",
            "draw an image of", "draw a picture of", "draw a", "draw an", "draw",
            "paint an image of", "paint a picture of", "paint a", "paint",
            "make a video of", "make video of", "generate a video of", "generate video of",
            "create video of", "create a video of", "make video", "generate video", "create video",
            "video of", "photo of", "picture of", "image of", "tasveer banao", "video banao"
        )
        for (prefix in prefixes) {
            if (clean.startsWith(prefix, ignoreCase = true)) {
                clean = clean.substring(prefix.length).trim(' ', ':', '-', ',')
                break
            }
        }
        return if (clean.isNotBlank()) clean else rawPrompt
    }

    fun sendMessage(promptText: String) {
        val trimmed = promptText.trim()
        if (trimmed.isBlank() && attachedImageBase64.value == null) return

        val chatId = activeChatId.value ?: return
        val currentImg = attachedImageBase64.value
        val currentModel = selectedModel.value
        val history = messages.value

        viewModelScope.launch {
            // Save User message
            repository.saveMessage(
                chatId = chatId,
                sender = MessageSender.USER,
                content = trimmed,
                imageBase64OrUri = currentImg,
                modelUsed = currentModel
            )

            // Clear input attachment
            _attachedImageBase64.value = null
            _isGenerating.value = true

            // 1. Direct Image Generation Check
            if (isImageGenerationRequest(trimmed) && currentImg == null) {
                val cleanSubject = cleanMediaPrompt(trimmed)
                val imgResult = repository.generateImage(
                    prompt = cleanSubject,
                    stylePreset = "Cinematic / Realistic",
                    aspectRatio = "1:1",
                    imageSize = "1K"
                )
                _isGenerating.value = false
                imgResult.onSuccess { generatedEntity ->
                    repository.saveMessage(
                        chatId = chatId,
                        sender = MessageSender.AI,
                        content = "🎨 **KING Image Created**\n\nGenerated high-resolution artwork for: **\"$cleanSubject\"**\n\n*Saved directly to your Images & Videos folder.*",
                        imageBase64OrUri = generatedEntity.imageDataBase64OrUrl,
                        modelUsed = "gemini-3-pro-image-preview"
                    )
                }.onFailure { err ->
                    repository.saveMessage(
                        chatId = chatId,
                        sender = MessageSender.AI,
                        content = "👑 **KING AI Studio Notification**\n\nCould not create image: ${err.message}",
                        modelUsed = currentModel
                    )
                }
                return@launch
            }

            // 2. Direct Video Generation Check
            if (isVideoGenerationRequest(trimmed) && currentImg == null) {
                val cleanSubject = cleanMediaPrompt(trimmed)
                val videoResult = repository.generateVideoWithVeo3(
                    prompt = cleanSubject,
                    aspectRatio = "16:9",
                    consistencyStyle = "Cinematic Masterpiece",
                    motionConsistency = "Smooth 60 FPS",
                    durationSeconds = 5
                )
                _isGenerating.value = false
                videoResult.onSuccess { videoEntity ->
                    repository.saveMessage(
                        chatId = chatId,
                        sender = MessageSender.AI,
                        content = "🎬 **KING Veo Video Rendered**\n\nGenerated high-consistency cinematic video for: **\"$cleanSubject\"**\n\n- **Style**: ${videoEntity.consistencyStyle}\n- **Aspect Ratio**: ${videoEntity.aspectRatio}\n- **Motion**: ${videoEntity.motionConsistency}\n\n*Saved to your Images & Videos folder.*",
                        imageBase64OrUri = videoEntity.videoDataOrUrl,
                        modelUsed = "veo-3.1-fast-generate-preview"
                    )
                }.onFailure { err ->
                    repository.saveMessage(
                        chatId = chatId,
                        sender = MessageSender.AI,
                        content = "👑 **KING AI Studio Notification**\n\nCould not generate video: ${err.message}",
                        modelUsed = currentModel
                    )
                }
                return@launch
            }

            // 3. Regular Multimodal / Text Generation
            val result = repository.sendChatMessage(
                chatId = chatId,
                userPrompt = trimmed,
                selectedModel = currentModel,
                attachedImageBase64 = currentImg,
                previousMessages = history
            )

            _isGenerating.value = false

            result.onSuccess { aiResponseText ->
                repository.saveMessage(
                    chatId = chatId,
                    sender = MessageSender.AI,
                    content = aiResponseText,
                    modelUsed = currentModel
                )
            }.onFailure { error ->
                repository.saveMessage(
                    chatId = chatId,
                    sender = MessageSender.AI,
                    content = "👑 **KING AI Notification**\n\n${error.message ?: "An unexpected error occurred while generating a response."}",
                    modelUsed = currentModel
                )
            }
        }
    }

    fun translateMessage(messageId: Long, targetLanguage: String) {
        val targetMsg = _messages.value.find { it.id == messageId } ?: return
        if (targetMsg.sender != MessageSender.AI) return

        viewModelScope.launch {
            val translationPrompt = "Translate the following AI response precisely into $targetLanguage while preserving markdown formatting and tone:\n\n${targetMsg.content}"
            val result = repository.sendChatMessage(
                chatId = targetMsg.chatId,
                userPrompt = translationPrompt,
                selectedModel = "gemini-3.5-flash"
            )
            result.onSuccess { translatedText ->
                repository.saveMessage(
                    chatId = targetMsg.chatId,
                    sender = MessageSender.AI,
                    content = "🌐 **[Translated to $targetLanguage]**\n\n$translatedText",
                    modelUsed = targetMsg.modelUsed
                )
            }
        }
    }

    fun speakMessage(messageId: Long, text: String) {
        if (_speakingMessageId.value == messageId) {
            textToSpeech?.stop()
            _speakingMessageId.value = null
        } else {
            textToSpeech?.stop()
            _speakingMessageId.value = messageId
            textToSpeech?.speak(text.replace("*", ""), TextToSpeech.QUEUE_FLUSH, null, "KING_AI_TTS_$messageId")
        }
    }

    override fun onCleared() {
        super.onCleared()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
    }
}
