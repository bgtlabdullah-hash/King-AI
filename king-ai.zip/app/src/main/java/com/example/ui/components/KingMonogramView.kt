package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint as AndroidPaint
import android.graphics.Rect as AndroidRect
import android.graphics.Typeface
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBackground
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

/**
 * Material metallic color palettes for Monogram rendering.
 */
enum class MonogramMaterial(
    val title: String,
    val primaryColor: Color,
    val gradientColors: List<Color>
) {
    GOLD_24K(
        title = "24K Royale Gold",
        primaryColor = Color(0xFFD4AF37),
        gradientColors = listOf(
            Color(0xFFFFF9C4),
            Color(0xFFFFD54F),
            Color(0xFFD4AF37),
            Color(0xFFA07810),
            Color(0xFFFFE082),
            Color(0xFFD4AF37)
        )
    ),
    ROSE_GOLD(
        title = "Rose Gold Imperial",
        primaryColor = Color(0xFFE0A996),
        gradientColors = listOf(
            Color(0xFFFFE4DE),
            Color(0xFFF4B8A6),
            Color(0xFFD48B77),
            Color(0xFF9E5341),
            Color(0xFFFFD1C6),
            Color(0xFFD48B77)
        )
    ),
    PLATINUM(
        title = "Platinum Diamond",
        primaryColor = Color(0xFFE0E6ED),
        gradientColors = listOf(
            Color(0xFFFFFFFF),
            Color(0xFFE2E8F0),
            Color(0xFFCBD5E1),
            Color(0xFF94A3B8),
            Color(0xFFF8FAFC),
            Color(0xFFCBD5E1)
        )
    ),
    CYBER_EMERALD(
        title = "Emerald Royale",
        primaryColor = Color(0xFF2DD4BF),
        gradientColors = listOf(
            Color(0xFFCCFBF1),
            Color(0xFF5EEAD4),
            Color(0xFF14B8A6),
            Color(0xFF0F766E),
            Color(0xFF99F6E4),
            Color(0xFF14B8A6)
        )
    ),
    RUBY_SOVEREIGN(
        title = "Ruby Sovereign",
        primaryColor = Color(0xFFF43F5E),
        gradientColors = listOf(
            Color(0xFFFFE4E6),
            Color(0xFFFDA4AF),
            Color(0xFFF43F5E),
            Color(0xFF9F1239),
            Color(0xFFFECDD3),
            Color(0xFFE11D48)
        )
    )
}

/**
 * Wing styles for the monogram generator.
 */
enum class MonogramWingStyle(val title: String) {
    ROYALE_WINGS("Royale Feathered Wings"),
    PHOENIX_RISING("Phoenix Curved Wings"),
    IMPERIAL_EAGLE("Imperial Eagle Wings"),
    LAUREL_WREATH("Roman Laurel Wreath"),
    MINIMAL_ARCS("Minimalist Arcs"),
    NONE("No Wings (Clean Medallion)")
}

/**
 * Crown styles for the monogram generator.
 */
enum class MonogramCrownStyle(val title: String) {
    FLEUR_DE_LIS("French Fleur-de-lis Tiara"),
    IMPERIAL_5_GEM("Imperial 5-Gem Crown"),
    SOVEREIGN_DIADEM("Sovereign Diadem"),
    RADIANT_HALO("Radiant Sunburst"),
    NONE("No Crown")
}

/**
 * Filigree styles under the monogram circle.
 */
enum class MonogramFiligreeStyle(val title: String) {
    BAROQUE_SCROLL("Baroque Scroll & Diamond"),
    VICTORIAN_FLOURISH("Victorian Dual Flourish"),
    GOLDEN_RIBBON("Heraldic Banner Ribbon"),
    MINIMAL_CREST("Minimal Gold Arc"),
    NONE("No Flourish")
}

/**
 * Draws the Royal Monogram (matching the uploaded Royale reference image):
 * - Majestic feathered wings sweeping upward
 * - Central double golden ring medallion
 * - Serif initials inside (default "AI")
 * - Royal fleur-de-lis crown atop the medallion
 * - Baroque filigree flourish underneath
 * - Subtitle & Main title ("King AI" and "HIGH CLASS")
 */
fun DrawScope.drawRoyalMonogramEmblem(
    initials: String = "AI",
    mainTitle: String = "King AI",
    subTitle: String = "HIGH CLASS",
    material: MonogramMaterial = MonogramMaterial.GOLD_24K,
    wingStyle: MonogramWingStyle = MonogramWingStyle.ROYALE_WINGS,
    crownStyle: MonogramCrownStyle = MonogramCrownStyle.FLEUR_DE_LIS,
    filigreeStyle: MonogramFiligreeStyle = MonogramFiligreeStyle.BAROQUE_SCROLL,
    glowAlpha: Float = 0.5f,
    shimmerProgress: Float = 0f,
    isDarkMode: Boolean = true
) {
    val cx = size.width / 2f
    // Place medallion slightly above center so wings and text fit harmoniously
    val cy = size.height * 0.42f
    val scale = size.minDimension / 400f
    val circleR = 48f * scale

    val goldGrad = Brush.linearGradient(
        colors = material.gradientColors,
        start = Offset(cx - 180f * scale, cy - 140f * scale),
        end = Offset(cx + 180f * scale, cy + 160f * scale)
    )

    val goldSolid = material.primaryColor

    // 1. WINGS (Left & Right)
    if (wingStyle == MonogramWingStyle.ROYALE_WINGS || wingStyle == MonogramWingStyle.IMPERIAL_EAGLE) {
        drawRoyaleWings(
            cx = cx,
            cy = cy,
            circleR = circleR,
            scale = scale,
            goldBrush = goldGrad,
            goldSolid = goldSolid,
            glowAlpha = glowAlpha
        )
    } else if (wingStyle == MonogramWingStyle.PHOENIX_RISING) {
        drawPhoenixWings(
            cx = cx,
            cy = cy,
            circleR = circleR,
            scale = scale,
            goldBrush = goldGrad
        )
    } else if (wingStyle == MonogramWingStyle.LAUREL_WREATH) {
        drawLaurelWreath(
            cx = cx,
            cy = cy,
            circleR = circleR,
            scale = scale,
            goldBrush = goldGrad
        )
    } else if (wingStyle == MonogramWingStyle.MINIMAL_ARCS) {
        drawMinimalWings(
            cx = cx,
            cy = cy,
            circleR = circleR,
            scale = scale,
            goldBrush = goldGrad
        )
    }

    // 2. CENTRAL MEDALLION RINGS
    // Outer Thick Ring
    drawCircle(
        brush = goldGrad,
        radius = circleR,
        center = Offset(cx, cy),
        style = Stroke(width = 5.5f * scale)
    )
    // Inner Delicate Bevel Ring
    drawCircle(
        brush = goldGrad,
        radius = circleR - 7f * scale,
        center = Offset(cx, cy),
        style = Stroke(width = 1.8f * scale)
    )

    // Subtle dark/luminous backdrop inside circle if needed
    if (isDarkMode) {
        drawCircle(
            color = Color(0xFF0F0B18).copy(alpha = 0.6f),
            radius = circleR - 8f * scale,
            center = Offset(cx, cy),
            style = Fill
        )
    }

    // 3. CROWN / TIARA (TOP OF CIRCLE)
    if (crownStyle == MonogramCrownStyle.FLEUR_DE_LIS) {
        drawFleurDeLisCrown(
            cx = cx,
            topY = cy - circleR - 2f * scale,
            scale = scale,
            goldBrush = goldGrad
        )
    } else if (crownStyle == MonogramCrownStyle.IMPERIAL_5_GEM) {
        drawImperial5GemCrown(
            cx = cx,
            topY = cy - circleR - 2f * scale,
            scale = scale,
            goldBrush = goldGrad
        )
    } else if (crownStyle == MonogramCrownStyle.SOVEREIGN_DIADEM) {
        drawSovereignDiadem(
            cx = cx,
            topY = cy - circleR - 2f * scale,
            scale = scale,
            goldBrush = goldGrad
        )
    } else if (crownStyle == MonogramCrownStyle.RADIANT_HALO) {
        drawRadiantSunburst(
            cx = cx,
            topY = cy - circleR - 4f * scale,
            scale = scale,
            goldBrush = goldGrad
        )
    }

    // 4. BAROQUE FILIGREE FLOURISH (BOTTOM OF CIRCLE)
    if (filigreeStyle == MonogramFiligreeStyle.BAROQUE_SCROLL) {
        drawBaroqueFiligree(
            cx = cx,
            bottomY = cy + circleR + 2f * scale,
            scale = scale,
            goldBrush = goldGrad
        )
    } else if (filigreeStyle == MonogramFiligreeStyle.VICTORIAN_FLOURISH) {
        drawVictorianFlourish(
            cx = cx,
            bottomY = cy + circleR + 2f * scale,
            scale = scale,
            goldBrush = goldGrad
        )
    } else if (filigreeStyle == MonogramFiligreeStyle.GOLDEN_RIBBON) {
        drawHeraldicRibbon(
            cx = cx,
            bottomY = cy + circleR + 4f * scale,
            scale = scale,
            goldBrush = goldGrad
        )
    } else if (filigreeStyle == MonogramFiligreeStyle.MINIMAL_CREST) {
        drawMinimalBottomArc(
            cx = cx,
            bottomY = cy + circleR + 4f * scale,
            scale = scale,
            goldBrush = goldGrad
        )
    }

    // 5. CENTER INITIALS ("AI" OR CUSTOM)
    drawContext.canvas.nativeCanvas.apply {
        val paint = AndroidPaint().apply {
            isAntiAlias = true
            textSize = 48f * scale
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            textAlign = AndroidPaint.Align.CENTER
            color = material.primaryColor.toArgb()
            val textBounds = AndroidRect()
            getTextBounds(initials, 0, initials.length, textBounds)
        }

        // Draw metallic gradient on initials
        val textY = cy + (17f * scale)
        drawText(initials, cx, textY, paint)
    }

    // 6. MAIN TITLE ("King AI") & SUBTITLE ("HIGH CLASS")
    if (mainTitle.isNotBlank()) {
        drawContext.canvas.nativeCanvas.apply {
            val titlePaint = AndroidPaint().apply {
                isAntiAlias = true
                textSize = 34f * scale
                typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
                textAlign = AndroidPaint.Align.CENTER
                color = material.primaryColor.toArgb()
                letterSpacing = 0.15f
            }

            val titleY = cy + circleR + 58f * scale
            drawText(mainTitle.uppercase(), cx, titleY, titlePaint)

            if (subTitle.isNotBlank()) {
                val subPaint = AndroidPaint().apply {
                    isAntiAlias = true
                    textSize = 13.5f * scale
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    textAlign = AndroidPaint.Align.CENTER
                    color = material.primaryColor.toArgb()
                    letterSpacing = 0.35f
                }
                val subY = titleY + 22f * scale
                drawText(subTitle.uppercase(), cx, subY, subPaint)
            }
        }
    }
}

/**
 * Draws the signature sweeping Royale feathered wings on the left and right.
 */
private fun DrawScope.drawRoyaleWings(
    cx: Float,
    cy: Float,
    circleR: Float,
    scale: Float,
    goldBrush: Brush,
    goldSolid: Color,
    glowAlpha: Float
) {
    // 9 distinct tiered feathers on each wing
    val leftWingPath = Path()
    val rightWingPath = Path()

    // Wing anchor positions on circle perimeter
    val anchorOffset = circleR * 0.90f

    // Define feather tiers [tipX_offset, tipY_offset, midCurveX_offset, midCurveY_offset, base_offset]
    val featherSpecs = listOf(
        // Topmost long feather
        floatArrayOf(-165f, -145f, -100f, -120f, -anchorOffset, -10f, -anchorOffset, 8f),
        // 2nd feather
        floatArrayOf(-158f, -105f, -98f, -80f, -anchorOffset, 5f, -anchorOffset, 20f),
        // 3rd feather
        floatArrayOf(-148f, -68f, -95f, -45f, -anchorOffset, 16f, -anchorOffset, 30f),
        // 4th feather
        floatArrayOf(-135f, -32f, -88f, -15f, -anchorOffset, 25f, -anchorOffset, 38f),
        // 5th feather
        floatArrayOf(-118f, -2f, -78f, 10f, -anchorOffset, 32f, -anchorOffset, 42f),
        // 6th feather
        floatArrayOf(-98f, 22f, -65f, 28f, -anchorOffset, 38f, -anchorOffset, 46f),
        // 7th bottom short feather
        floatArrayOf(-75f, 40f, -50f, 42f, -anchorOffset, 42f, -anchorOffset, 48f)
    )

    featherSpecs.forEach { spec ->
        val tipX = cx + spec[0] * scale
        val tipY = cy + spec[1] * scale
        val midX = cx + spec[2] * scale
        val midY = cy + spec[3] * scale
        val baseTopX = cx + spec[4] * scale
        val baseTopY = cy + spec[5] * scale
        val baseBotX = cx + spec[6] * scale
        val baseBotY = cy + spec[7] * scale

        // Left Feather Path
        val feather = Path().apply {
            moveTo(baseTopX, baseTopY)
            quadraticTo(midX, midY - 6f * scale, tipX, tipY)
            quadraticTo(midX - 4f * scale, midY + 10f * scale, baseBotX, baseBotY)
            close()
        }
        drawPath(path = feather, brush = goldBrush, style = Fill)
        drawPath(path = feather, color = Color(0xFFFFF9C4), style = Stroke(width = 1.2f * scale))

        // Symmetrical Right Feather Path
        val rTipX = cx - spec[0] * scale
        val rMidX = cx - spec[2] * scale
        val rBaseTopX = cx - spec[4] * scale
        val rBaseBotX = cx - spec[6] * scale

        val rFeather = Path().apply {
            moveTo(rBaseTopX, baseTopY)
            quadraticTo(rMidX, midY - 6f * scale, rTipX, tipY)
            quadraticTo(rMidX + 4f * scale, midY + 10f * scale, rBaseBotX, baseBotY)
            close()
        }
        drawPath(path = rFeather, brush = goldBrush, style = Fill)
        drawPath(path = rFeather, color = Color(0xFFFFF9C4), style = Stroke(width = 1.2f * scale))
    }

    // Wing Root Shading / Inner feather fan
    val innerFanL = Path().apply {
        moveTo(cx - anchorOffset + 4f * scale, cy - 20f * scale)
        quadraticTo(cx - anchorOffset - 35f * scale, cy - 40f * scale, cx - anchorOffset - 50f * scale, cy - 70f * scale)
        quadraticTo(cx - anchorOffset - 25f * scale, cy - 20f * scale, cx - anchorOffset + 4f * scale, cy + 30f * scale)
        close()
    }
    drawPath(innerFanL, brush = goldBrush, style = Fill)

    val innerFanR = Path().apply {
        moveTo(cx + anchorOffset - 4f * scale, cy - 20f * scale)
        quadraticTo(cx + anchorOffset + 35f * scale, cy - 40f * scale, cx + anchorOffset + 50f * scale, cy - 70f * scale)
        quadraticTo(cx + anchorOffset + 25f * scale, cy - 20f * scale, cx + anchorOffset - 4f * scale, cy + 30f * scale)
        close()
    }
    drawPath(innerFanR, brush = goldBrush, style = Fill)
}

/**
 * Draws the French Fleur-de-lis Royal Tiara Crown perched atop the medallion.
 */
private fun DrawScope.drawFleurDeLisCrown(
    cx: Float,
    topY: Float,
    scale: Float,
    goldBrush: Brush
) {
    val crownW = 42f * scale
    val crownH = 26f * scale

    // Arched Base of the Crown (mating with the circle)
    val baseArch = Path().apply {
        moveTo(cx - crownW * 0.85f, topY)
        quadraticTo(cx, topY - 4f * scale, cx + crownW * 0.85f, topY)
        lineTo(cx + crownW * 0.90f, topY - 5f * scale)
        quadraticTo(cx, topY - 9f * scale, cx - crownW * 0.90f, topY - 5f * scale)
        close()
    }
    drawPath(baseArch, brush = goldBrush, style = Fill)

    // Center Fleur-de-lis Spire
    val centerSpire = Path().apply {
        val spearTopY = topY - crownH
        val spearMidY = topY - crownH * 0.45f
        moveTo(cx, spearTopY)
        quadraticTo(cx + 7f * scale, spearMidY, cx + 4f * scale, topY - 6f * scale)
        lineTo(cx - 4f * scale, topY - 6f * scale)
        quadraticTo(cx - 7f * scale, spearMidY, cx, spearTopY)
        close()
    }
    drawPath(centerSpire, brush = goldBrush, style = Fill)
    drawPath(centerSpire, color = Color(0xFFFFF9C4), style = Stroke(1.2f * scale))

    // Left Curled Petal
    val leftPetal = Path().apply {
        val tipX = cx - crownW * 0.55f
        val tipY = topY - crownH * 0.72f
        moveTo(cx - 2f * scale, topY - 8f * scale)
        cubicTo(cx - 8f * scale, topY - 14f * scale, tipX + 4f * scale, tipY - 4f * scale, tipX, tipY)
        cubicTo(tipX + 8f * scale, tipY + 12f * scale, cx - 12f * scale, topY - 4f * scale, cx - 2f * scale, topY - 7f * scale)
        close()
    }
    drawPath(leftPetal, brush = goldBrush, style = Fill)

    // Right Curled Petal
    val rightPetal = Path().apply {
        val tipX = cx + crownW * 0.55f
        val tipY = topY - crownH * 0.72f
        moveTo(cx + 2f * scale, topY - 8f * scale)
        cubicTo(cx + 8f * scale, topY - 14f * scale, tipX - 4f * scale, tipY - 4f * scale, tipX, tipY)
        cubicTo(tipX - 8f * scale, tipY + 12f * scale, cx + 12f * scale, topY - 4f * scale, cx + 2f * scale, topY - 7f * scale)
        close()
    }
    drawPath(rightPetal, brush = goldBrush, style = Fill)

    // Crown Jewels / Pearls (5 pearl beads along base)
    val pearlCoords = listOf(
        Offset(cx - crownW * 0.7f, topY - 3f * scale),
        Offset(cx - crownW * 0.35f, topY - 4.5f * scale),
        Offset(cx, topY - 5.5f * scale),
        Offset(cx + crownW * 0.35f, topY - 4.5f * scale),
        Offset(cx + crownW * 0.7f, topY - 3f * scale)
    )
    pearlCoords.forEach { p ->
        drawCircle(color = Color(0xFFFFFFFF), radius = 2.0f * scale, center = p)
        drawCircle(color = Color(0xFFFFD700), radius = 3.0f * scale, center = p, style = Stroke(1.0f * scale))
    }

    // Top Cross / Fleur Jewel
    drawCircle(color = Color(0xFFFFFFFF), radius = 2.4f * scale, center = Offset(cx, topY - crownH - 1f * scale))
}

/**
 * Draws the Baroque Filigree flourish underneath the medallion with the central quad-leaf diamond.
 */
private fun DrawScope.drawBaroqueFiligree(
    cx: Float,
    bottomY: Float,
    scale: Float,
    goldBrush: Brush
) {
    val spanW = 90f * scale
    val flourishH = 34f * scale

    // Left Baroque Scrollwork Path
    val leftScroll = Path().apply {
        moveTo(cx - 6f * scale, bottomY)
        cubicTo(
            cx - 24f * scale, bottomY + 6f * scale,
            cx - 45f * scale, bottomY + 2f * scale,
            cx - 58f * scale, bottomY + 14f * scale
        )
        // Outer spiral hook
        cubicTo(
            cx - 72f * scale, bottomY + 24f * scale,
            cx - 88f * scale, bottomY + 12f * scale,
            cx - 82f * scale, bottomY - 2f * scale
        )
        cubicTo(
            cx - 76f * scale, bottomY + 4f * scale,
            cx - 65f * scale, bottomY + 16f * scale,
            cx - 52f * scale, bottomY + 16f * scale
        )
        // Return under arch
        cubicTo(
            cx - 36f * scale, bottomY + 16f * scale,
            cx - 18f * scale, bottomY + 24f * scale,
            cx, bottomY + 24f * scale
        )
        // Lower leaf curl
        cubicTo(
            cx - 14f * scale, bottomY + 20f * scale,
            cx - 28f * scale, bottomY + 12f * scale,
            cx - 6f * scale, bottomY
        )
        close()
    }
    drawPath(leftScroll, brush = goldBrush, style = Fill)
    drawPath(leftScroll, color = Color(0xFFFFF9C4), style = Stroke(1.0f * scale))

    // Right Baroque Scrollwork Path (Symmetrical)
    val rightScroll = Path().apply {
        moveTo(cx + 6f * scale, bottomY)
        cubicTo(
            cx + 24f * scale, bottomY + 6f * scale,
            cx + 45f * scale, bottomY + 2f * scale,
            cx + 58f * scale, bottomY + 14f * scale
        )
        // Outer spiral hook
        cubicTo(
            cx + 72f * scale, bottomY + 24f * scale,
            cx + 88f * scale, bottomY + 12f * scale,
            cx + 82f * scale, bottomY - 2f * scale
        )
        cubicTo(
            cx + 76f * scale, bottomY + 4f * scale,
            cx + 65f * scale, bottomY + 16f * scale,
            cx + 52f * scale, bottomY + 16f * scale
        )
        // Return under arch
        cubicTo(
            cx + 36f * scale, bottomY + 16f * scale,
            cx + 18f * scale, bottomY + 24f * scale,
            cx, bottomY + 24f * scale
        )
        cubicTo(
            cx + 14f * scale, bottomY + 20f * scale,
            cx + 28f * scale, bottomY + 12f * scale,
            cx + 6f * scale, bottomY
        )
        close()
    }
    drawPath(rightScroll, brush = goldBrush, style = Fill)
    drawPath(rightScroll, color = Color(0xFFFFF9C4), style = Stroke(1.0f * scale))

    // Central Bottom Quad-Leaf / Diamond Crest
    val quadY = bottomY + 27f * scale
    val diamondR = 5.5f * scale
    val quadCrest = Path().apply {
        moveTo(cx, quadY - diamondR)
        lineTo(cx + diamondR, quadY)
        lineTo(cx, quadY + diamondR)
        lineTo(cx - diamondR, quadY)
        close()
    }
    drawPath(quadCrest, brush = goldBrush, style = Fill)
    drawCircle(color = Color(0xFFFFFFFF), radius = 2.0f * scale, center = Offset(cx, quadY))

    // 4 small decorative dots around the diamond
    drawCircle(color = Color(0xFFFFD700), radius = 1.6f * scale, center = Offset(cx - 8f * scale, quadY))
    drawCircle(color = Color(0xFFFFD700), radius = 1.6f * scale, center = Offset(cx + 8f * scale, quadY))
    drawCircle(color = Color(0xFFFFD700), radius = 1.6f * scale, center = Offset(cx, quadY + 8f * scale))
    drawCircle(color = Color(0xFFFFD700), radius = 1.6f * scale, center = Offset(cx, quadY - 8f * scale))
}

/**
 * Alternate Crown: Imperial 5-Gem Crown.
 */
private fun DrawScope.drawImperial5GemCrown(cx: Float, topY: Float, scale: Float, goldBrush: Brush) {
    val crownW = 38f * scale
    val crownH = 22f * scale
    val path = Path().apply {
        moveTo(cx - crownW, topY)
        lineTo(cx - crownW * 0.95f, topY - crownH + 6f * scale)
        lineTo(cx - crownW * 0.50f, topY - crownH * 0.5f)
        lineTo(cx, topY - crownH)
        lineTo(cx + crownW * 0.50f, topY - crownH * 0.5f)
        lineTo(cx + crownW * 0.95f, topY - crownH + 6f * scale)
        lineTo(cx + crownW, topY)
        close()
    }
    drawPath(path, brush = goldBrush, style = Fill)
    drawPath(path, color = Color(0xFFFFF8E1), style = Stroke(1.5f * scale))
}

private fun DrawScope.drawSovereignDiadem(cx: Float, topY: Float, scale: Float, goldBrush: Brush) {
    val w = 36f * scale
    val h = 18f * scale
    val path = Path().apply {
        moveTo(cx - w, topY)
        quadraticTo(cx - w * 0.5f, topY - h, cx, topY - h * 1.2f)
        quadraticTo(cx + w * 0.5f, topY - h, cx + w, topY)
        close()
    }
    drawPath(path, brush = goldBrush, style = Fill)
}

private fun DrawScope.drawRadiantSunburst(cx: Float, topY: Float, scale: Float, goldBrush: Brush) {
    val numRays = 11
    val baseR = 14f * scale
    val rayLen = 14f * scale
    for (i in 0 until numRays) {
        val angle = Math.PI + (i.toDouble() / (numRays - 1)) * Math.PI
        val startX = cx + (baseR * cos(angle)).toFloat()
        val startY = topY + (baseR * sin(angle)).toFloat()
        val endX = cx + ((baseR + rayLen) * cos(angle)).toFloat()
        val endY = topY + ((baseR + rayLen) * sin(angle)).toFloat()
        drawLine(
            brush = goldBrush,
            start = Offset(startX, startY),
            end = Offset(endX, endY),
            strokeWidth = 2f * scale,
            cap = StrokeCap.Round
        )
    }
}

private fun DrawScope.drawPhoenixWings(cx: Float, cy: Float, circleR: Float, scale: Float, goldBrush: Brush) {
    val pathL = Path().apply {
        moveTo(cx - circleR, cy)
        cubicTo(cx - circleR - 40f * scale, cy - 60f * scale, cx - circleR - 120f * scale, cy - 130f * scale, cx - 180f * scale, cy - 110f * scale)
        cubicTo(cx - circleR - 100f * scale, cy - 30f * scale, cx - circleR - 60f * scale, cy + 20f * scale, cx - circleR, cy + 20f * scale)
        close()
    }
    val pathR = Path().apply {
        moveTo(cx + circleR, cy)
        cubicTo(cx + circleR + 40f * scale, cy - 60f * scale, cx + circleR + 120f * scale, cy - 130f * scale, cx + 180f * scale, cy - 110f * scale)
        cubicTo(cx + circleR + 100f * scale, cy - 30f * scale, cx + circleR + 60f * scale, cy + 20f * scale, cx + circleR, cy + 20f * scale)
        close()
    }
    drawPath(pathL, brush = goldBrush, style = Fill)
    drawPath(pathR, brush = goldBrush, style = Fill)
}

private fun DrawScope.drawLaurelWreath(cx: Float, cy: Float, circleR: Float, scale: Float, goldBrush: Brush) {
    val numLeaves = 7
    for (i in 0 until numLeaves) {
        val angleL = Math.PI * 0.6 + (i * 0.14)
        val lx = cx + ((circleR + 18f * scale) * cos(angleL)).toFloat()
        val ly = cy + ((circleR + 18f * scale) * sin(angleL)).toFloat()
        drawCircle(brush = goldBrush, radius = 5.5f * scale, center = Offset(lx, ly))

        val angleR = Math.PI * 0.4 - (i * 0.14)
        val rx = cx + ((circleR + 18f * scale) * cos(angleR)).toFloat()
        val ry = cy + ((circleR + 18f * scale) * sin(angleR)).toFloat()
        drawCircle(brush = goldBrush, radius = 5.5f * scale, center = Offset(rx, ry))
    }
}

private fun DrawScope.drawMinimalWings(cx: Float, cy: Float, circleR: Float, scale: Float, goldBrush: Brush) {
    drawArc(
        brush = goldBrush,
        startAngle = 140f,
        sweepAngle = 100f,
        useCenter = false,
        topLeft = Offset(cx - circleR * 2.2f, cy - circleR * 1.5f),
        size = Size(circleR * 4.4f, circleR * 3f),
        style = Stroke(width = 3.5f * scale, cap = StrokeCap.Round)
    )
}

private fun DrawScope.drawVictorianFlourish(cx: Float, bottomY: Float, scale: Float, goldBrush: Brush) {
    drawBaroqueFiligree(cx, bottomY, scale * 0.85f, goldBrush)
}

private fun DrawScope.drawHeraldicRibbon(cx: Float, bottomY: Float, scale: Float, goldBrush: Brush) {
    val ribbonW = 75f * scale
    val ribbonH = 14f * scale
    val ribbon = Path().apply {
        moveTo(cx - ribbonW, bottomY + 8f * scale)
        quadraticTo(cx, bottomY + 2f * scale, cx + ribbonW, bottomY + 8f * scale)
        lineTo(cx + ribbonW - 8f * scale, bottomY + 8f * scale + ribbonH)
        quadraticTo(cx, bottomY + 2f * scale + ribbonH, cx - ribbonW + 8f * scale, bottomY + 8f * scale + ribbonH)
        close()
    }
    drawPath(ribbon, brush = goldBrush, style = Fill)
}

private fun DrawScope.drawMinimalBottomArc(cx: Float, bottomY: Float, scale: Float, goldBrush: Brush) {
    drawLine(
        brush = goldBrush,
        start = Offset(cx - 40f * scale, bottomY + 10f * scale),
        end = Offset(cx + 40f * scale, bottomY + 10f * scale),
        strokeWidth = 2.5f * scale,
        cap = StrokeCap.Round
    )
    drawCircle(brush = goldBrush, radius = 3.5f * scale, center = Offset(cx, bottomY + 10f * scale))
}

/**
 * Creates a standalone High-Resolution Bitmap of the Royal Monogram for saving and sharing.
 */
fun renderMonogramBitmap(
    width: Int = 1080,
    height: Int = 1080,
    initials: String = "AI",
    mainTitle: String = "King AI",
    subTitle: String = "HIGH CLASS",
    material: MonogramMaterial = MonogramMaterial.GOLD_24K,
    wingStyle: MonogramWingStyle = MonogramWingStyle.ROYALE_WINGS,
    crownStyle: MonogramCrownStyle = MonogramCrownStyle.FLEUR_DE_LIS,
    filigreeStyle: MonogramFiligreeStyle = MonogramFiligreeStyle.BAROQUE_SCROLL,
    backgroundColor: Color = Color(0xFF0F0B18)
): Bitmap {
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)

    // Fill background
    val bgPaint = AndroidPaint().apply {
        color = backgroundColor.toArgb()
        style = AndroidPaint.Style.FILL
    }
    canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

    // Render using Compose DrawScope adapter via ImageCompose or direct Paint operations
    val cx = width / 2f
    val cy = height * 0.42f
    val scale = width / 400f
    val circleR = 48f * scale

    val goldColor = material.primaryColor.toArgb()
    val goldPaint = AndroidPaint().apply {
        isAntiAlias = true
        color = goldColor
        style = AndroidPaint.Style.STROKE
        strokeWidth = 5.5f * scale
    }

    // Outer and inner rings
    canvas.drawCircle(cx, cy, circleR, goldPaint)
    goldPaint.strokeWidth = 1.8f * scale
    canvas.drawCircle(cx, cy, circleR - 7f * scale, goldPaint)

    // Initials Text
    val textPaint = AndroidPaint().apply {
        isAntiAlias = true
        textSize = 48f * scale
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        textAlign = AndroidPaint.Align.CENTER
        color = goldColor
    }
    canvas.drawText(initials, cx, cy + (17f * scale), textPaint)

    // Main Title
    if (mainTitle.isNotBlank()) {
        val titlePaint = AndroidPaint().apply {
            isAntiAlias = true
            textSize = 34f * scale
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            textAlign = AndroidPaint.Align.CENTER
            color = goldColor
            letterSpacing = 0.15f
        }
        val titleY = cy + circleR + 58f * scale
        canvas.drawText(mainTitle.uppercase(), cx, titleY, titlePaint)

        if (subTitle.isNotBlank()) {
            val subPaint = AndroidPaint().apply {
                isAntiAlias = true
                textSize = 14f * scale
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = AndroidPaint.Align.CENTER
                color = goldColor
                letterSpacing = 0.35f
            }
            canvas.drawText(subTitle.uppercase(), cx, titleY + 22f * scale, subPaint)
        }
    }

    return bitmap
}
