package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class UserAuthManager private constructor(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("king_ai_auth_prefs", Context.MODE_PRIVATE)

    private val _isLoggedIn = MutableStateFlow(prefs.getBoolean("is_logged_in", false))
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _userName = MutableStateFlow(prefs.getString("user_name", null))
    val userName: StateFlow<String?> = _userName.asStateFlow()

    private val _userEmail = MutableStateFlow(prefs.getString("user_email", null))
    val userEmail: StateFlow<String?> = _userEmail.asStateFlow()

    fun login(name: String, email: String) {
        prefs.edit()
            .putBoolean("is_logged_in", true)
            .putString("user_name", name)
            .putString("user_email", email)
            .apply()

        _isLoggedIn.value = true
        _userName.value = name
        _userEmail.value = email
    }

    fun logout() {
        prefs.edit().clear().apply()
        _isLoggedIn.value = false
        _userName.value = null
        _userEmail.value = null
    }

    companion object {
        @Volatile
        private var INSTANCE: UserAuthManager? = null

        fun getInstance(context: Context): UserAuthManager {
            return INSTANCE ?: synchronized(this) {
                val instance = UserAuthManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
