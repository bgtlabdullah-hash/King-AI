package com.example.util

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AppThemeMode(val key: String, val title: String, val description: String) {
    LIGHT("light", "Light", "Clean bright theme with crisp gold accents"),
    DARK("dark", "Dark (Obsidian)", "Sleek obsidian black & gold royal contrast"),
    SYSTEM("system", "System Default", "Follows your Android device dark/light setting")
}

class ThemeManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("king_ai_theme_prefs", Context.MODE_PRIVATE)
    
    private val _themeMode = MutableStateFlow(loadThemeMode())
    val themeMode: StateFlow<AppThemeMode> = _themeMode.asStateFlow()

    private fun loadThemeMode(): AppThemeMode {
        val saved = prefs.getString(KEY_THEME_MODE, AppThemeMode.DARK.key)
        return when (saved) {
            AppThemeMode.LIGHT.key -> AppThemeMode.LIGHT
            AppThemeMode.DARK.key -> AppThemeMode.DARK
            AppThemeMode.SYSTEM.key -> AppThemeMode.SYSTEM
            else -> AppThemeMode.DARK
        }
    }

    fun setThemeMode(mode: AppThemeMode) {
        prefs.edit().putString(KEY_THEME_MODE, mode.key).apply()
        _themeMode.value = mode
    }

    companion object {
        private const val KEY_THEME_MODE = "app_theme_mode"

        @Volatile
        private var INSTANCE: ThemeManager? = null

        fun getInstance(context: Context): ThemeManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ThemeManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
