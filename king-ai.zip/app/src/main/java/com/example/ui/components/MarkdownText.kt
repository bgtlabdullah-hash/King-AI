package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GoldPrimary

@Composable
fun MarkdownText(
    text: String,
    textColor: Color = MaterialTheme.colorScheme.onSurface,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        val parts = parseMarkdown(text)

        parts.forEach { part ->
            when (part) {
                is MarkdownPart.CodeBlock -> {
                    Spacer(modifier = Modifier.height(8.dp))
                    CodeBlockView(
                        language = part.language,
                        codeText = part.code
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
                is MarkdownPart.Header -> {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = part.text,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = GoldPrimary,
                        fontSize = 17.sp,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
                is MarkdownPart.Paragraph -> {
                    val annotated = buildAnnotatedString {
                        val str = part.text
                        var idx = 0
                        while (idx < str.length) {
                            val boldStart = str.indexOf("**", idx)
                            if (boldStart != -1) {
                                append(str.substring(idx, boldStart))
                                val boldEnd = str.indexOf("**", boldStart + 2)
                                if (boldEnd != -1) {
                                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = GoldPrimary)) {
                                        append(str.substring(boldStart + 2, boldEnd))
                                    }
                                    idx = boldEnd + 2
                                } else {
                                    append(str.substring(boldStart))
                                    break
                                }
                            } else {
                                append(str.substring(idx))
                                break
                            }
                        }
                    }

                    Text(
                        text = annotated,
                        style = MaterialTheme.typography.bodyMedium,
                        color = textColor,
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }
    }
}

sealed class MarkdownPart {
    data class Paragraph(val text: String) : MarkdownPart()
    data class CodeBlock(val language: String, val code: String) : MarkdownPart()
    data class Header(val text: String) : MarkdownPart()
}

fun parseMarkdown(text: String): List<MarkdownPart> {
    val result = mutableListOf<MarkdownPart>()
    val codeBlockRegex = Regex("```(\\w*)\\n?([\\s\\S]*?)```")

    var lastIndex = 0
    for (match in codeBlockRegex.findAll(text)) {
        val range = match.range
        if (range.first > lastIndex) {
            val normalText = text.substring(lastIndex, range.first).trim()
            if (normalText.isNotEmpty()) {
                parseNormalParagraphs(normalText, result)
            }
        }

        val lang = match.groupValues.getOrNull(1)?.trim() ?: ""
        val code = match.groupValues.getOrNull(2)?.trim() ?: ""
        result.add(MarkdownPart.CodeBlock(lang, code))

        lastIndex = range.last + 1
    }

    if (lastIndex < text.length) {
        val remainingText = text.substring(lastIndex).trim()
        if (remainingText.isNotEmpty()) {
            parseNormalParagraphs(remainingText, result)
        }
    }

    return if (result.isEmpty()) listOf(MarkdownPart.Paragraph(text)) else result
}

private fun parseNormalParagraphs(text: String, result: MutableList<MarkdownPart>) {
    val lines = text.split("\n")
    var currentParagraph = StringBuilder()

    lines.forEach { line ->
        val trimmed = line.trim()
        if (trimmed.startsWith("#")) {
            if (currentParagraph.isNotEmpty()) {
                result.add(MarkdownPart.Paragraph(currentParagraph.toString().trim()))
                currentParagraph = StringBuilder()
            }
            val headerText = trimmed.removePrefix("#").removePrefix("#").removePrefix("#").trim()
            result.add(MarkdownPart.Header(headerText))
        } else {
            if (currentParagraph.isNotEmpty()) {
                currentParagraph.append("\n")
            }
            currentParagraph.append(line)
        }
    }

    if (currentParagraph.isNotEmpty()) {
        result.add(MarkdownPart.Paragraph(currentParagraph.toString().trim()))
    }
}
