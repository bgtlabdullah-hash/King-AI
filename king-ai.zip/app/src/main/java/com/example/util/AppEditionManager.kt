package com.example.util

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.widget.Toast

enum class AppEdition(val displayName: String, val description: String) {
    OWNER_MASTER(
        "👑 King AI - Owner Master Edition",
        "Full Master Privileges for Abdullah Waheed • All 3.1 Pro Models & Studios 100% Unlocked"
    ),
    SHARED_PUBLIC(
        "👥 King AI - Shared User Edition",
        "Public Distribution Mode • Clean User Account Setup & Individual Biometrics on Transfer"
    )
}

data class UserProfile(
    val fullName: String,
    val emailOrPhone: String,
    val isOwner: Boolean,
    val isRegistered: Boolean,
    val edition: AppEdition,
    val isProActive: Boolean
)

class AppEditionManager(private val context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("king_ai_edition_prefs", Context.MODE_PRIVATE)

    companion object {
        const val MASTER_OWNER_NAME = "Abdullah Waheed"
        const val MASTER_OWNER_EMAIL = "abdullah.waheed@kingai.royal"
    }

    var currentEdition: AppEdition
        get() {
            val name = prefs.getString("active_edition", AppEdition.OWNER_MASTER.name)
            return try {
                AppEdition.valueOf(name ?: AppEdition.OWNER_MASTER.name)
            } catch (e: Exception) {
                AppEdition.OWNER_MASTER
            }
        }
        set(value) {
            prefs.edit().putString("active_edition", value.name).apply()
        }

    var isUserRegistered: Boolean
        get() = prefs.getBoolean("user_registered", true)
        set(value) = prefs.edit().putBoolean("user_registered", value).apply()

    var userName: String
        get() = prefs.getString("user_full_name", if (isOwnerEdition()) MASTER_OWNER_NAME else "King AI User") ?: "King AI User"
        set(value) = prefs.edit().putString("user_full_name", value).apply()

    var userEmail: String
        get() = prefs.getString("user_email", if (isOwnerEdition()) MASTER_OWNER_EMAIL else "user@kingai.app") ?: "user@kingai.app"
        set(value) = prefs.edit().putString("user_email", value).apply()

    fun isOwnerEdition(): Boolean {
        return currentEdition == AppEdition.OWNER_MASTER
    }

    fun isAllFeaturesUnlocked(): Boolean {
        // Master edition has all features unlocked completely free
        return isOwnerEdition() || prefs.getBoolean("pro_unlocked_shared", false)
    }

    fun setProUnlockedForShared(unlocked: Boolean) {
        prefs.edit().putBoolean("pro_unlocked_shared", unlocked).apply()
    }

    fun getUserProfile(): UserProfile {
        return UserProfile(
            fullName = userName,
            emailOrPhone = userEmail,
            isOwner = isOwnerEdition(),
            isRegistered = isUserRegistered,
            edition = currentEdition,
            isProActive = isAllFeaturesUnlocked()
        )
    }

    fun registerNewRecipientAccount(name: String, emailOrPhone: String, pin: String) {
        prefs.edit()
            .putString("user_full_name", name.ifBlank { "User" })
            .putString("user_email", emailOrPhone.ifBlank { "user@kingai.app" })
            .putBoolean("user_registered", true)
            .putString("active_edition", AppEdition.SHARED_PUBLIC.name)
            .apply()

        // Set personal PIN for this user
        val sec = SecurityManager(context)
        if (pin.length == 4 && pin.all { it.isDigit() }) {
            sec.pinCode = pin
            sec.isPinLockEnabled = true
        }
    }

    /**
     * CLEAN RESET FOR SHAREIT / PUBLIC TRANSFER
     * When sending via ShareIt or sharing app with others:
     * 1. Resets active edition to SHARED_PUBLIC
     * 2. Clears owner profile and sets isUserRegistered = false
     * 3. Resets security manager so the recipient must register their own account & PIN/biometrics
     */
    fun performCleanResetForSharing() {
        val sec = SecurityManager(context)
        // Reset security so new user sets their own credentials
        sec.isPinLockEnabled = false
        sec.isFingerprintEnabled = false
        sec.isFaceLockEnabled = false
        sec.saveEnrolledFingerprints(emptyList())
        sec.saveEnrolledFaceLocks(emptyList())
        sec.pinCode = "1234"

        // Reset edition prefs
        prefs.edit()
            .putString("active_edition", AppEdition.SHARED_PUBLIC.name)
            .putBoolean("user_registered", false)
            .putString("user_full_name", "")
            .putString("user_email", "")
            .putBoolean("pro_unlocked_shared", false)
            .apply()
    }

    fun switchToOwnerMasterEdition() {
        currentEdition = AppEdition.OWNER_MASTER
        isUserRegistered = true
        userName = MASTER_OWNER_NAME
        userEmail = MASTER_OWNER_EMAIL
    }

    fun shareAppViaShareItOrSheet() {
        // Prepare share intent
        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "KING AI - Sovereign AI Assistant (Clean Distribution Package)")
                putExtra(
                    Intent.EXTRA_TEXT,
                    "👑 *KING AI - Elite Artificial Intelligence App*\n\n" +
                            "Engineered & Mastered by: Abdullah Waheed\n\n" +
                            "Features: 3.1 Pro Multimodal Chat, 4K Image & Video Studio, Monogram Maker, Voice Recognition, and High-Security Biometrics.\n\n" +
                            "📲 *For ShareIt / Direct Transfer Recipients:*\n" +
                            "When you install and open KING AI on your device, you will be prompted to create your own personal account, set your unique 4-digit PIN, and enroll your biometric fingerprint/face.\n\n" +
                            "Download APK / Shared Package: KING_AI_v1.0_Release.apk"
                )
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share KING AI via ShareIt, Bluetooth, or Files").apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open share menu: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
