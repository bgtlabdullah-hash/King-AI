package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBackground
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun KingStartingAnimation(
    onAnimationFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scale = remember { Animatable(0.4f) }
    val alpha = remember { Animatable(0f) }
    val wingSpread = remember { Animatable(0.5f) }
    val textAlpha = remember { Animatable(0f) }
    val textSlide = remember { Animatable(25f) }
    val ringPulse = remember { Animatable(0.5f) }
    val ringAlpha = remember { Animatable(0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "monogram_shimmer")
    val shimmerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_rotation"
    )

    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.90f,
        targetValue = 1.10f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_pulse"
    )

    LaunchedEffect(Unit) {
        // Step 1: Smooth fade and royal entrance scale
        alpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing)
        )
        scale.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing)
        )

        // Step 2: Spread wings outward majestically
        wingSpread.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing)
        )

        // Step 3: Radiate golden celestial energy rings
        ringAlpha.animateTo(0.85f, tween(350))
        ringPulse.animateTo(1.4f, tween(950, easing = FastOutSlowInEasing))
        ringAlpha.animateTo(0.25f, tween(400))

        // Step 4: Reveal typography: "King AI" and "HIGH CLASS"
        delay(150)
        textSlide.animateTo(
            targetValue = 0f,
            animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing)
        )
        textAlpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing)
        )

        // Wait to display the completed majestic monogram and brand
        delay(1600)

        // Step 5: Smooth exit fade
        alpha.animateTo(
            targetValue = 0f,
            animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing)
        )
        onAnimationFinished()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF281A48), // Rich imperial royal amethyst glow
                        Color(0xFF160E2A),
                        ObsidianBackground,
                        Color(0xFF07050E)
                    ),
                    radius = 950f
                )
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onAnimationFinished // Allow quick skip on tap
            ),
        contentAlignment = Alignment.Center
    ) {
        // Floating Starlight Sparkle Field
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawSparkleField(shimmerRotation)
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            // MONOGRAM CONTAINER (Exact reference emblem: Wings, Crown, AI Medallion, Baroque Filigree)
            Box(
                modifier = Modifier
                    .size(310.dp)
                    .scale(scale.value * glowPulse)
                    .alpha(alpha.value),
                contentAlignment = Alignment.Center
            ) {
                // Expanding Radiant Golden Halo
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2f, size.height * 0.42f)
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                GoldPrimary.copy(alpha = 0.35f * ringAlpha.value),
                                Color(0xFFFFB300).copy(alpha = 0.15f * ringAlpha.value),
                                Color.Transparent
                            ),
                            center = center,
                            radius = (size.minDimension / 2f) * ringPulse.value
                        ),
                        radius = (size.minDimension / 2f) * ringPulse.value,
                        center = center
                    )

                    // Draw the Exact Royal Monogram (Crown, Wings, AI Medallion, Filigree, "King AI", "HIGH CLASS")
                    drawRoyalMonogramEmblem(
                        initials = "AI",
                        mainTitle = "King AI",
                        subTitle = "HIGH CLASS",
                        material = MonogramMaterial.GOLD_24K,
                        wingStyle = MonogramWingStyle.ROYALE_WINGS,
                        crownStyle = MonogramCrownStyle.FLEUR_DE_LIS,
                        filigreeStyle = MonogramFiligreeStyle.BAROQUE_SCROLL,
                        glowAlpha = glowPulse,
                        shimmerProgress = shimmerRotation,
                        isDarkMode = true
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Subtitle Tagline & Attribution under the Monogram
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .alpha(textAlpha.value)
                    .scale(if (textSlide.value == 0f) 1f else 0.95f)
            ) {
                // Golden Accent Separator Line
                Box(
                    modifier = Modifier
                        .width(64.dp)
                        .height(2.dp)
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    GoldPrimary,
                                    Color(0xFFFFF8E1),
                                    GoldPrimary,
                                    Color.Transparent
                                )
                            )
                        )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "THE SOVEREIGN AI STUDIO",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 3.sp,
                    color = GoldPrimary.copy(alpha = 0.9f)
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Created by Abdullah Waheed",
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 1.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
    }
}

/**
 * Draws floating golden starlight particles for royal atmosphere.
 */
private fun DrawScope.drawSparkleField(rotationDeg: Float) {
    val cx = size.width / 2f
    val cy = size.height / 2f

    val particleCoords = listOf(
        Offset(cx - 140f, cy - 190f) to 2.5f,
        Offset(cx + 150f, cy - 170f) to 3.0f,
        Offset(cx - 160f, cy + 140f) to 2.0f,
        Offset(cx + 140f, cy + 150f) to 3.5f,
        Offset(cx - 90f, cy - 240f) to 1.8f,
        Offset(cx + 100f, cy - 250f) to 2.2f,
        Offset(cx - 70f, cy + 250f) to 2.8f,
        Offset(cx + 80f, cy + 260f) to 2.0f,
        Offset(cx, cy - 270f) to 4.0f
    )

    particleCoords.forEachIndexed { index, (pos, r) ->
        val rad = (rotationDeg * 0.02f * (index + 1))
        val dynamicPos = Offset(
            pos.x + sin(rad) * 12f,
            pos.y + cos(rad) * 8f
        )
        drawCircle(
            color = GoldPrimary.copy(alpha = 0.5f + 0.4f * sin(rad)),
            radius = r,
            center = dynamicPos
        )
    }
}
